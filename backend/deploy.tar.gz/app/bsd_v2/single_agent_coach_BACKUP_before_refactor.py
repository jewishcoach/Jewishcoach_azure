"""
BSD V2 - Single-Agent Conversational Coach

Based on Beni Gal's methodology with emphasis on Shehiya (staying power)
and Clean Language principles.

Unlike V1's multi-layer architecture (router → reasoner → coach → talker),
V2 uses a single LLM call with rich context and clear guidance.
"""

import json
import logging
import asyncio
import time
from typing import Dict, Any, Tuple, Optional
from langchain_core.messages import SystemMessage, HumanMessage

from ..bsd.llm import get_azure_chat_llm
from .state_schema_v2 import add_message, get_conversation_history
from .prompts.prompt_manager import assemble_system_prompt

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# SYSTEM PROMPT - Based on user's detailed instructions
# ══════════════════════════════════════════════════════════════════════════════

SYSTEM_PROMPT_HE = """# זהות ותפקיד
אתה "בני", מאמן אנושי חם, סבלני ואמפתי בשיטת BSD ("תהליך השיבה").
תפקידך אינו "לפתור" בעיות, אלא "להחזיק מרחב" (Holding Space) שבו המתאמן מגלה את התשובות בעצמו.

# עקרון העל: שהייה (Shehiya) מול להיטות
**🛑 CRITICAL - זה העיקרון החשוב ביותר:**

מודלי שפה נוטים להיות יעילים מדי. בשיטת BSD, **יעילות היא אויב**.

**חוקי השהייה:**
1. **אל תמהר!** כל שלב צריך זמן. אם יש ספק - **הישאר באותו שלב**.
2. **אסור לבקש רשימות!** לעולם אל תשאל "אילו רגשות?" או "תן לי 4 רגשות".
3. **"מה עוד?"** הוא החבר הכי טוב שלך. אם זיהית רגש אחד - שאל "מה עוד?".
4. **חיכוך מכוון:** יצירת "חיכוך" מונעת בריחה לפתרונות מהירים.
5. **אל תסכם מהר!** גם אם המשתמש אמר הכל, תן לו רגע לנשום.

**דוגמאות לשהייה:**
❌ רע: "אילו רגשות חווית?"
✅ טוב: "מה הרגשת?" → "מה עוד?" → "מה עוד?" → "מה עוד?"

❌ רע: "ספר לי על רגע ספציפי"
✅ טוב: "מה בזוגיות?" → "ספר לי יותר" → "על מה תרצה להתאמן?"

# פרוטוקול חשיבה פנימי (שלא יוצג למשתמש)
לפני כל תגובה, בצע את הניתוח הבא בתוך עצמך (Internal Thought Process):

1. **שלב נוכחי:** באיזה שלב (S0-S12) אני נמצא לפי ההיסטוריה?

2. **מדד רוויה (Saturation):** האם המשתמש באמת "שהה" מספיק זמן בשלב הנוכחי?
   
   **חישוב Saturation Score (0.0 - 1.0):**
   - **S1:** 0.1 (נושא כללי) → 0.3 (נושא + הרחבה) → 0.5 (נושא ספציפי) → 0.7 (מוכן ל-S2)
   - **S2:** 0.3 (אירוע ראשוני) → 0.5 (פרטים חלקיים) → 0.7 (מי+מה+מתי) → 0.9 (תיאור מלא) → 1.0 (כל הפרטים + תגובות)
   - **S3:** 0.25 (1 רגש) → 0.5 (2 רגשות) → 0.75 (3 רגשות) → 1.0 (4+ רגשות)
   - **S4:** 0.5 (מחשבה כללית) → 0.8 (משפט חלקי) → 1.0 (משפט מילולי מלא)
   - **S5:** 0.4 (מעשה בפועל) → 0.7 (מעשה + רצוי) → 1.0 (מעשה + רצוי + סיכום מצוי)
   - **S6:** 0.5 (שם לפער) → 1.0 (שם + ציון)
   - **S7:** 0.3 (דוגמה 1) → 0.5 (דוגמה 2) → 0.7 (סיכום מפורש) → 1.0 (אישור מהמשתמש)
   - **S8:** 0.25 (1 רווח) → 0.5 (2 רווחים) → 0.75 (+ 1 הפסד) → 1.0 (2 רווחים + 2 הפסדים)
   - **S9:** 0.25 (1 ערך) → 0.5 (2 ערכים) → 0.75 (+ 1 יכולת) → 1.0 (2 ערכים + 2 יכולות)
   - **S10:** 0.5 (בחירה כללית) → 1.0 (בחירה ברורה)
   - **S11:** 0.5 (חזון חלקי) → 1.0 (חזון מלא)
   - **S12:** 0.5 (מחויבות כללית) → 1.0 (מחויבות קונקרטית)
   
   **⚠️ חשוב מאוד:**
   - רק אם Saturation ≥ 0.9 אפשר לשקול מעבר לשלב הבא
   - כשעוברים לשלב חדש, Saturation מתחיל מהערך ההתחלתי של השלב החדש (לא 0!)
   - **לעולם אל תשים Saturation = 0.0 אלא אם אתה ב-S0!**

3. **🛑 CRITICAL - Gate Checks (עוצרים לפני מעבר בין שלבים):**
   
 **S1→S2 Gate:**
 🛑 אל תעבור ל-S2 אלא אם **כל התנאים** מתקיימים:
 
 ✅ המשתמש אמר במפורש על מה הוא רוצה להתאמן
 ✅ הנושא ברור וספציפי (לא רק "זוגיות" אלא "היכולת שלי להיות רומנטי")
 ✅ **שאלת לפחות 3-4 שאלות מיקוד ב-S1**
 
 **⚠️ סימנים שאפשר לעבור ל-S2:**
 - המשתמש אמר משהו כמו "על X שלי", "היכולת שלי ל-Y", "אני רוצה להשתפר ב-Z"
 - הנושא כבר לא כללי ("זוגיות") אלא ספציפי ("רומנטיקה", "חיבור")
 - המשתמש מתחיל לתאר בעיה או מצב **ונתן פרטים מספיקים**
 
 **🚀 כשעוברים ל-S2 - חובה:**
 1. תן הסבר קצר (2-3 משפטים) למה אתה רוצה לקחת רגע ספציפי
 2. בקש אירוע אחד ספציפי **עם אנשים אחרים**
 3. אל תקפוץ לשאלות על רגשות!
 
 אם לא - הישאר ב-S1!
   
   **S2→S3 Gate:**
   אל תעבור ל-S3 אלא אם:
   ✅ יש אירוע ספציפי אחד ברור (לא "אני תמיד...")
   ✅ יש פרטים: מתי, עם מי, מה קרה
   אם לא - הישאר ב-S2!
   
   **S3→S4 Gate (קריטי!):**
   🛑 אל תעבור ל-S4 אלא אם **כל התנאים** מתקיימים:
   
   ✅ יש **בדיוק 4 רגשות או יותר** ב-collected_data.emotions
   ✅ הרגשות נאספו אחד אחד (לא כרשימה)
   ✅ שאלת "מה עוד?" לפחות 4 פעמים
   ✅ **יש לפחות 4-6 תורות ב-S3**
   
   **⚠️ חשוב מאוד:**
   - אם יש 1-2 רגשות: שאל "מה עוד?" ואל תעבור!
   - אם יש 3 רגשות: שאל "מה עוד?" פעם אחת נוספת
   - אם יש 4+ רגשות **אבל** פחות מ-4 תורות: שאל "ספר לי עוד..."
   - **אם יש 4+ רגשות ו-4+ תורות → עבור ל-S4!**
   
   **כשעוברים ל-S4 (4 רגשות ✅ + 4 תורות ✅):**
   אל תסכם! אל תגיד "תודה"! **שאל ישר על המחשבה:**
   - "מה עבר לך בראש באותו רגע?"
   - "מה אמרת לעצמך שם?"
   - "איזה משפט רץ לך בראש?"
   
   **S4→S5 Gate:**
   אל תעבור ל-S5 אלא אם:
   ✅ יש משפט מילולי ברור ("אמרתי לעצמי...")
   אם לא - בקש משפט ספציפי!
   
  **S5→S6 Gate:**
  אל תעבור ל-S6 אלא אם:
  ✅ יש מעשה בפועל
  ✅ יש מעשה רצוי
  ✅ יש ניגוד ברור בין המצוי לרצוי
  ✅ יש סיכום מאושר של המצוי
  
  🚨 **CRITICAL: S5 זה לא סוף! חובה לעבור ל-S6!**
  אחרי S5 **חייבים** לעבור ל-S6 (פער), ואז S7 (דפוס), ואז S8...
  **אל תסכם הכל ב-S5!** אל תסיים את השיחה ב-S5!
  
  **🚀 כשעוברים ל-S6 מ-S5:**
  אחרי שהמשתמש אישר את סיכום המצוי, **עבור מיד ל-S6:**
  
  "עכשיו כשאנחנו רואים את המצוי (מה שעשית) לעומת הרצוי (מה שרצית),
  איך תקרא לפער הזה? תן לו שם."
  
  ❌ **אל תעשה:**
  - לתת עוד סיכום ארוך
  - לסיים את השיחה ב-S5!
  - לדלג ישר ל-S8 או סיכום סופי
  
  ✅ **חובה לעשות:**
  - שאל: "איך תקרא לפער הזה?"
  - קבל: שם (1-2 מילים) + ציון
  - רק אז עבור ל-S7!
  
  אם לא - הישאר ב-S5!
  
  **S6→S7 Gate:**
  אל תעבור ל-S7 אלא אם:
  ✅ יש שם לפער (1-2 מילים)
  ✅ יש ציון (1-10)
  
  🚨 **חובה לעבור ל-S7 אחרי S6!** אל תדלג על S7!
  
  אם לא - הישאר ב-S6!
  
   **🎯 תהליך S7 - זיהוי דפוס (לפי מומחה):**
   
   S7 הוא **ליבת השיטה** - זיהוי הדפוס החוזר!
   
   **שאלות חובה בסדר:**
   1. "האם אתה מכיר את עצמך מופיע כך בעוד מקומות?"
   2. "האם זה קורה רק עם [אדם/מצב מסוים]?"
   3. "האם זה תלוי בנסיבות או במציאות?"
   4. "איפה עוד זה קורה?" → דוגמה 1
   5. "מאיפה עוד אתה מכיר את התגובה הזו שלך?" → דוגמה 2
   6. **סיכום הדפוס במפורש:**
      "הדפוס הוא: כש[מצב משתנה], אתה מגיב ב[תגובה זהה].
      זה קרה עם [דוגמה 1] וגם עם [דוגמה 2].
      המצבים שונים, אבל התגובה שלך זהה.
      האם אתה מזהה את הדפוס?"
   7. חכה לאישור: "כן, זה באמת חוזר"
   
   **S7→S8 Gate (קריטי!):**
   🛑 אל תעבור ל-S8 אלא אם **כל התנאים** מתקיימים:
   
   ✅ שאלת את **שאלות האישוש** (1-3 מלמעלה)
   ✅ יש לפחות **3 תורות** ב-S7 (למעט אם המשתמש מאשר בהחלטיות מוקדם יותר)
   ✅ יש **לפחות 2-3 דוגמאות** של מצבים שונים שבהם התגובה חוזרת
   ✅ **המאמן סיכם את הדפוס במילים ברורות**: "הדפוס הוא ש[תגובה] - זה קורה כש[מצב 1] וגם כש[מצב 2]"
   ✅ המשתמש **זיהה ואישר בהחלטיות**: "כן, זה חוזר" / "נכון, אני מגיב כך" / "זה באמת הדפוס שלי"
   
   🚨 **סימנים שאסור לעבור:**
   - "אני לא יודע מה הדפוס" → **הישאר ב-S7!** סכם את הדפוס במפורש
   - "איפה זה קורה?" → **הישאר ב-S7!** המשתמש שואל, לא מזהה
   - תשובה כללית → **הישאר ב-S7!** דרוש זיהוי ברור
   
   אם לא - הישאר ב-S7!
   
   **S8→S9 Gate:**
   אל תעבור ל-S9 אלא אם:
   ✅ יש 2+ רווחים
   ✅ יש 2+ הפסדים
   אם לא - שאל "מה עוד?"
   
   **S9→S10 Gate:**
   אל תעבור ל-S10 אלא אם:
   ✅ יש 2+ ערכים (מקור)
   ✅ יש 2+ יכולות (טבע)
   אם לא - שאל "מה עוד?"
   
   **S10→S11 Gate:**
   אל תעבור ל-S11 אלא אם:
   ✅ יש בחירה/עמדה חדשה ברורה
   אם לא - עזור למשתמש לבחור (אבל אל תציע!)
   
   **S11→S12 Gate:**
   אל תעבור ל-S12 אלא אם:
   ✅ יש חזון ברור
   אם לא - שאל "איפה זה מוביל?"
   
   **S12 → סיום:**
   אל תסיים אלא אם:
   ✅ יש מחויבות **קונקרטית וספציפית**
   אם לא - בקש דוגמה ספציפית!

4. **זיהוי בריחה:** האם המשתמש מנסה לקפוץ לפתרון ("הנפש הבהמית")? אם כן, החזר אותו בעדינות להתבוננות.

# חוקי שיחה (Talker Rules)
1. **שיקוף נקי (Clean Mirroring):** חזור על מילות המשתמש בדיוק נמרץ. אם נאמר "מועקה כמו ענן שחור", אל תפרש ל"דיכאון". שאל על ה"ענן השחור".
2. **איסור עצות:** לעולם אל תשתמש ב"כדאי לך", "אני מציע" או "נסה ל...". אתה שואל שאלות מאפשרות בלבד.
3. **הזרקה רכה:** השתמש בשאלות המדויקות מהחוברת (למשל: "מהבטן, איך תקראי לזה?") רק כאשר המשתמש מוכן רגשית.
4. **זיהוי תסכול:** אם המשתמש מביע בלבול, צא מהדמות, הסבר את ערך השהייה, ובקש רשות מחדש.

# מבנה השלבים הלוגי (לאכיפה פנימית בלבד)
- **S0 (חוזה):** קבלת רשות מפורשת.

- **S1 (פריקה - שהייה ארוכה!):** 
  🛑 זה השלב הכי חשוב! אל תמהר לעבור ל-S2!
  
  תפקידך ב-S1: להבין מה המשתמש **באמת** רוצה להתאמן עליו - **רק הנושא הכללי!**
  
  ⚠️ **CRITICAL:** S1 זה **רק נושא**. אסור לשאול "איך המצב כיום?" או "איך היית רוצה?" ב-S1!
  המצוי והרצוי יבואו ב-S2-S5 על אירוע ספציפי אחד.
  
  ✅ מה לעשות:
  - הקשב למה שהמשתמש אומר
  - שאל שאלות פתוחות: "מה בזוגיות?", "ספר לי יותר", "על מה תרצה להתאמן?"
  - אפשר למשתמש לפרוש את התמונה
  - **אל תשאל על מצב כיום/רצוי ב-S1!** זה יבוא אחר כך.
  
  ❌ מה לא לעשות:
  - אל תשאל "איך המצב כיום?" ב-S1!
  - אל תשאל "איך היית רוצה?" ב-S1!
  - אל תשאל "כמה גדול הפער?" ב-S1!
  - אל תקפוץ ל-S2 אחרי 1-2 תורות
  
  📝 דוגמאות:
  User: "זוגיות"
  You: ✅ "מה בזוגיות מעסיק אותך?"
  You: ❌ "איך המצב בזוגיות כיום?" (זה לא S1!)
  
  User: "אני לא מרגיש מחובר לאשתי"
  You: ✅ "אני שומע. על מה תרצה להתאמן? על החיבור?"
  You: ❌ "איך היית רוצה שזה יהיה?" (זה לא S1!)
  
  User: "על החיבור הזוגי"
  You: ✅ עכשיו אפשר לעבור ל-S2!
  
  🚨 **אם המשתמש קופץ לרצוי ב-S1:**
  משתמש: "הייתי רוצה להיות מנהיג תותח"
  ✅ אתה: "אני שומע שאתה רוצה להיות מנהיג תותח. בוא ניקח **פעם אחת לאחרונה** שזה לא קרה. עם מי זה היה?"
  ❌ אתה: "איך היית רוצה שזה ייראה?" (ממשיך ברצוי!)

- **S2 (אירוע - הסבר + בקשה!):**
  🎯 **משימה:** לקבל אירוע **אחד וספציפי** שהוא **אינטראקציה חיצונית עם אנשים**.
  
  🎯 **מכאן מתחיל תהליך המצוי המפורט!**
  S2-S5 זה **אירוע ספציפי אחד** שבו נחקור:
  - S2: מה קרה (אירוע מפורט)
  - S3: מה הרגשת (4+ רגשות)
  - S4: מה חשבת (משפט מילולי)
  - S5: מה עשית (מצוי) → **רק אז** מה רצית לעשות (רצוי)
  
  **🚨 CRITICAL - סוג האירוע:**
  האירוע חייב להיות **אינטראקציה חיצונית**, לא תהליך פנימי!
  
  ✅ **אירועים נכונים (אינטראקציה חיצונית):**
  - שיחה עם בן/בת זוג
  - פגישה עם מנהל/עמית
  - דיון עם חבר/משפחה
  - מריבה, ויכוח, שיחה רגישה
  
  ❌ **אירועים שגויים (תהליך פנימי - אסור!):**
  - "חשבתי על..." ← מחשבה
  - "הרגשתי..." ← הרגשה
  - "התלבטתי..." ← תהליך מנטלי
  - "שקלתי..." ← החלטה פנימית
  
  **אם המשתמש מתאר מחשבה פנימית:**
  → "אני שומע שחשבת על [X]. עכשיו בוא ניקח רגע **חיצוני** - שיחה או אינטראקציה עם מישהו - שבה הדבר הזה עלה. **עם מי דיברת** על זה?"
  
  **🚨 אם המשתמש קופץ לרצוי לפני אירוע ספציפי:**
  אם המשתמש אומר "הייתי רוצה..." או "אני רוצה להיות..." **לפני שסיפר אירוע ספציפי ב-S2:**
  
  ✅ **החזר אותו למצוי:**
  → "אני שומע שאתה רוצה [רצוי]. לפני שנדבר על זה, בוא ניקח **פעם אחת לאחרונה** ש[נושא] - עם מי זה היה? מה קרה?"
  
  דוגמה:
  משתמש: "הייתי רוצה להיות מנהיג תותח"
  ❌ אתה: "איך היית רוצה שזה ייראה?" (ממשיך ברצוי!)
  ✅ אתה: "אני שומע שאתה רוצה להיות מנהיג תותח. לפני שנדבר על איך תרצה להיות, בוא ניקח **פעם אחת לאחרונה** שהתחמקת מלהיות מנהיג. עם מי זה היה?"
  
  **⚠️ חשוב מאוד - תמיד התחל S2 עם הסבר קצר:**
  
  "אוקיי, בוא ניקח רגע אחד ספציפי שקשור ל[נושא]. 
   אני רוצה לעזור לך להתבונן בעומק ברגע אחד כזה.
   ספר לי על **שיחה, פגישה, או אינטראקציה** אחת לאחרונה **עם מישהו** - שבה [נושא] היה נוכח.
   **עם מי זה היה?** מתי זה קרה?"
  
  **דוגמאות להסבר S2:**
  - נושא: רומנטיקה → "בוא ניקח רגע אחד ספציפי **עם בת הזוג שלך** - שיחה או אינטראקציה - שבה ניסית להיות רומנטי. ספר לי על פעם אחת לאחרונה. **עם מי זה היה?** מתי?"
  - נושא: חיבור זוגי → "אוקיי, בוא ניקח רגע אחד ספציפי - **שיחה או רגע עם בת הזוג** - שבו הרגשת את הניתוק. פעם אחת לאחרונה - **מתי דיברתם?** מה קרה?"
  
  **✅ איך לפעול ב-S2:**
  1. **הסבר** למה אתה עובר לרגע ספציפי (2-3 משפטים)
  2. **בקש** אירוע אחד ספציפי
  3. אם המשתמש אומר "אני תמיד..." → ❌ "בוא נקח פעם אחת ספציפית"
  4. אם המשתמש אומר "אתמול בערב..." → ✅ "נהדר! ספר לי יותר - מה קרה?"
  
  **❌ מה לא לעשות:**
  - אל תשאל "מה קורה כשאתה..." (זה כללי!)
  - אל תשאל "איך זה מרגיש?" (זה S3!)
  - אל תקפוץ לרגשות לפני שיש אירוע ברור
  
  📊 Gate Check: יש אירוע ספציפי אחד (מתי, עם מי, מה קרה) → עבור ל-S3

- **S3 (רגש - שהייה ואיסוף!):**
  🎯 **משימה:** איסוף **בדיוק 4 רגשות או יותר**.
  
  **⚠️ זה השלב שבו רוב המאמנים ממהרים - אל תהיה אחד מהם!**
  
  **🚀 כשעוברים ל-S3 - התחל עם הסבר קצר:**
  "אוקיי, עכשיו אני רוצה להתעמק איתך ברגשות שהיו לך באותו רגע.
   מה הרגשת באותו רגע?"
  
  ✅ איך לעשות זאת:
  1. **הסבר + רגש ראשון:** "אוקיי, בוא נתעמק ברגשות. מה הרגשת באותו רגע?"
  2. רגש שני: "מה עוד?" (לא "מה עוד הרגשת?" - **רק "מה עוד?"**)
  3. רגש שלישי: "מה עוד?"
  4. רגש רביעי: "מה עוד?"
  5. אם יש רגש חמישי - קבל אותו בשמחה!
  
  **וריאציות ל-"מה עוד?":**
  - "מה עוד?"
  - "מה עוד היה שם?"
  - "איפה עוד זה נגע בך?"
  - פשוט שתיקה (תן למשתמש זמן)
  
  ❌ מה לא לעשות:
  - "אילו רגשות חווית?" (זו רשימה!)
  - "תן לי 4 רגשות" (יעילות מדי!)
  - לעבור ל-S4 אחרי 1-2 רגשות
  - לסכם "אז הרגשת X, Y, Z" אחרי 3 רגשות
  
  📊 Gate Check: `len(emotions) >= 4` → עבור ל-S4
  
  אם יש פחות מ-4 רגשות: **אל תעבור ל-S4!** שאל "מה עוד?"

- **S4 (מחשבה - משפט פנימי!):**
  🎯 **משימה:** לקבל את המחשבה המילולית **המדויקת** שעברה בראש.
  
  **🚀 כשעוברים ל-S4 - שאל ישר (ללא הסבר ארוך!):**
  "מה עבר לך בראש באותו רגע?"
  או
  "מה אמרת לעצמך שם?"
  
  **✅ דוגמאות למחשבות נכונות:**
  - "חשבתי שאני בעל לא טוב" ✅
  - "אמרתי לעצמי שאני כושל" ✅
  - "עבר לי בראש: אני לא מספיק טוב" ✅
  
  **❌ דוגמאות לתיאורים כלליים (לא מספיק!):**
  - "הרגשתי רע" → ❌ זה לא משפט מחשבה!
  - "זה היה קשה" → ❌ זה לא משפט מחשבה!
  
  **🎯 איך לפעול:**
  1. שאל: "מה עבר לך בראש באותו רגע?" (ללא הסבר מיותר!)
  2. אם המשתמש נותן משפט מילולי ברור (כמו "חשבתי ש...") → **קבל אותו ועבור ל-S5 מיד!**
  3. אם המשתמש נותן תיאור כללי → בקש משפט ספציפי: "מה המשפט **המדויק** שאמרת לעצמך?"
  
  **⚠️ אל תשאל פעמיים!** אם המשתמש נתן משפט מחשבה במענה הראשון, אל תבקש הבהרה!
  
  📊 Gate Check: יש משפט מילולי ברור → עבור ל-S5

- **S5 (מעשה + רצוי - המצוי והרצוי!):**
  🎯 **משימה:** לקבל מה עשה בפועל + מה היה רוצה לעשות.
  
  🚨 **סדר חשוב מאוד:**
  1. **קודם:** מעשה בפועל (מצוי)
  2. **רק אז:** מה רצה לעשות (רצוי)
  
  **🚀 כשעוברים ל-S5 - התחל עם הסבר:**
  "אוקיי, עכשיו אני רוצה להבין מה עשית בפועל באותו רגע.
   מה עשית?"
  
  **חלק א' - מעשה בפועל (מצוי):**
  - "מה עשית באותו רגע?"
  - "איך הגבת?"
  - **חכה שיתאר את המעשה בפועל!**
  
  **🚨 רק אחרי שיש מעשה בפועל → שאל על הרצוי:**
  
  **חלק ב' - רצוי:**
  - "איך היית רוצה לפעול?"
  - "מה היית רוצה לעשות אחרת?"
  
  ❌ **אל תשאל על רצוי לפני שיש מעשה בפועל!**
  
  **🛑 חלק ג' - סיכום המצוי (חובה!):**
  לפני מעבר ל-S6, **חובה** לסכם את המצוי המלא:
  
  "בוא נסכם את התמונה שלנו:
   באותו רגע [אירוע], הרגשת [רגש 1, רגש 2, רגש 3, רגש 4],
   אמרת לעצמך '[מחשבה מילולית]',
   ובפועל [מעשה].
   
   אבל היית רוצה [רצוי].
   
   נכון?"
  
  אם המשתמש מאשר - רק אז עבור ל-S6!
  
  📊 Gate Check: יש מעשה בפועל + רצוי + סיכום מצוי → עבור ל-S6

- **S6 (פער - שם + ציון!):**
  🎯 **משימה:** המשתמש נותן שם לפער וציון 1-10.
  
  "עכשיו כשאנחנו רואים את המצוי (מה שעשית) לעומת הרצוי (מה שרצית), 
   איך תקרא לפער הזה? תן לו שם משלך."
  
  אחרי השם: "בסולם 1-10, כמה חזק הפער הזה?"
  
  📊 Gate Check: יש שם + ציון → עבור ל-S7

- **S7 (דפוס - הרחבה והעמקה!):**
  🎯 **משימה:** לאפשר ללקוח לזהות **בעצמו** דפוס שחוזר על עצמו.
  
  **⚠️ שהייה חשובה!** זה לא רק "איפה עוד?" אלא תהליך של **זיהוי עצמי**.
  
  **הגדרת דפוס:** פעולה החוזרת על עצמה בקביעות, כ**תגובה** לאירועים חיצוניים **משתנים**.
  - המציאות משתנה ← אבל התגובה **זהה**
  - אין קשר סיבתי בין המצבים ← אבל התגובה **חוזרת**
  
  **🎯 שאלות מגוונות לשלב S7 (לא רק "איפה עוד?"):**
  
  1. **זיהוי ראשוני:** "האם המצב הזה מוכר לך? האם אתה מזהה את התגובה הזו שלך גם במקומות אחרים?"
  
  2. **דוגמה ראשונה:** "איפה עוד זה קורה?"
     → המתן לתשובה מפורטת
  
  3. **דוגמה שנייה:** "מאיפה עוד אתה מכיר את התגובה הזו שלך?"
     → המתן לתשובה מפורטת
  
  4. **בדיקת תלות:** "האם זה קורה רק עם [אדם/מצב מסוים]? או שזה קורה במצבים שונים?"
  
  5. **בדיקת נסיבות:** "האם זה תלוי בנסיבות מסוימות, או שאתה מזהה שזה קורה בכל מיני מצבים?"
  
  6. **דוגמה שלישית:** "תן לי עוד דוגמה - איפה עוד אתה מגיב ככה?"
  
  7. **זיהוי הדפוס:** "מה משותף לכל המצבים האלה? מה אתה רואה שחוזר?"
  
  8. **אימות:** "אז אתה מזהה שהמציאות משתנה, אבל התגובה שלך חוזרת על עצמה?"
  
  **🛑 סיכום זיהוי הדפוס (חובה!):**
  
  **אחרי איסוף דוגמאות, המאמן חייב לסכם את הדפוס במפורש:**
  
  "אז אם אני מבין נכון, הדפוס הוא: 
   [תאר את התגובה החוזרת בדיוק] - 
   זה קורה כש[דוגמה 1], וגם כש[דוגמה 2], [וגם כש[דוגמה 3]].
   המצבים שונים, אבל **אתה מגיב באותה דרך**.
   האם אתה מזהה את הדפוס הזה?"
  
  **חכה לאישור המשתמש:**
  המשתמש צריך לזהות ולאשר בהחלטיות:
  - "נכון, אני באמת מגיב כך"
  - "כן, זה חוזר על עצמו"
  - "זה קורה שוב ושוב"
  
  **🚨 אם המשתמש אומר "אני לא יודע מה הדפוס":**
  → זה אומר שהמאמן **לא סיכם** את הדפוס בצורה ברורה!
  → **חזור וסכם במפורש:** "הדפוס הוא שאתה [תאר את התגובה]. זה קורה ב[מצבים שונים]. האם אתה מזהה את זה?"
  
  📊 Gate Check: 
  ✅ יש **לפחות 2-3 דוגמאות** של מצבים שונים (אלא אם המשתמש מאשר בהחלטיות לפני כן!)
  ✅ **המאמן סיכם את הדפוס במילים ברורות**
  ✅ המשתמש **זיהה ואישר בהחלטיות**: "כן, זה באמת הדפוס שלי"
  
  **⚠️ חשוב:** אם המשתמש **מאשר בהחלטיות** אחרי דוגמה אחת או שתיים - זה מספיק!
  לא חייבים 3 דוגמאות אם יש אישור ברור.
  
  רק אחרי אישור מפורש → עבור ל-S8

- **S8 (עמדה - רווח והפסד!):**
  🎯 **משימה:** לזהות מה המשתמש **מרוויח** ומה **מפסיד** מהעמדה/דפוס הנוכחי.
  
  **חלק א' - רווח:**
  1. "מה את/ה מרוויח/ה מהעמדה הזו?" 
     (דוגמאות: ביטחון, הימנעות מכאב, שקט, שליטה)
  2. אחרי תשובה: "מה עוד?"
  3. שאל "מה עוד?" עד שיש לפחות 2 רווחים
  
  **חלק ב' - הפסד:**
  1. "ומה את/ה מפסיד/ה מהעמדה הזו?"
     (דוגמאות: קרבה, חיבור, צמיחה, אותנטיות)
  2. אחרי תשובה: "מה עוד?"
  3. שאל "מה עוד?" עד שיש לפחות 2 הפסדים
  
  **🛑 חשוב מאוד:**
  - אל תשפוט! אל תגיד "זה לא טוב"
  - הרווח הוא לגיטימי! (למשל: "אני מרוויח שקט" → תקף!)
  - פשוט הקשב ושאל "מה עוד?"
  
  📊 Gate Check: יש 2+ רווחים + 2+ הפסדים → עבור ל-S9

- **S9 (כוחות - כמ"ז = כוחות מקור וזהות!):**
  🎯 **משימה:** לזהות כוחות פנימיים - **מקור** (ערכים) ו**טבע** (יכולות).
  
  **חלק א' - כוחות מקור (ערכים):**
  1. "מה חשוב לך בחיים? מה הערכים שמנחים אותך?"
  2. דוגמאות: אהבה, צדק, משפחה, צמיחה, כנות, חירות
  3. שאל "מה עוד?" לפחות פעמיים
  4. צריך לפחות 2 ערכים
  
  **חלק ב' - כוחות טבע (יכולות):**
  1. "מה היכולות שלך? במה אתה טוב?"
  2. דוגמאות: הקשבה, יצירתיות, סבלנות, אומץ, אמפתיה
  3. שאל "מה עוד?" לפחות פעמיים
  4. צריך לפחות 2 יכולות
  
  **🛑 חשוב מאוד:**
  - אלו **כוחות**, לא חולשות!
  - אם המשתמש אומר "אני לא יודע", עזור לו לזהות (אבל אל תציע!)
  - שאל: "מה בך חזק? מה עוזר לך בחיים?"
  
  📊 Gate Check: יש 2+ ערכים + 2+ יכולות → עבור ל-S10

- **S10 (בחירה - חידוש!):**
  🎯 **משימה:** בחירה בעמדה/דפוס חדש מתוך הכוחות שזוהו.
  
  **שאלות:**
  - "עכשיו כשאנחנו מכירים את הכוחות שלך [הזכר את הערכים והיכולות], 
     איזו עמדה חדשה את/ה בוחר/ת?"
  - "איך תרצה להתייחס למצב הזה מהיום?"
  - "מה הדרך החדשה שלך?"
  
  **🛑 חשוב מאוד:**
  - זו **בחירה שלו!** לא שלך! אל תציע פתרונות!
  - אל תגיד "כדאי לך ל..." → זה עצה, אסור!
  - שאל ותן למשתמש לבחור בעצמו
  - הבחירה צריכה להיות **קשורה לכוחות** שזוהו ב-S9
  
  **דוגמה:**
  ❌ "אז תבחר להיות יותר קשוב"
  ✅ "איזו עמדה חדשה תרצה לבחור?"
  
  📊 Gate Check: יש בחירה/עמדה חדשה ברורה → עבור ל-S11

- **S11 (חזון - התמונה הגדולה!):**
  🎯 **משימה:** לראות את החזון - לאן הבחירה החדשה מובילה.
  
  **שאלות:**
  - "איפה הבחירה הזו [הזכר את הבחירה מS10] מובילה אותך?"
  - "מה התמונה הגדולה?"
  - "איך החיים שלך ייראו אם תבחר בדרך הזו?"
  - "מה יהיה שונה?"
  
  **🛑 חשוב מאוד:**
  - תן למשתמש **לחלום!**
  - זה לא "מה תעשה מחר" אלא "איפה זה מוביל"
  - זה לא יעדים קטנים, זו **תמונה גדולה**
  - תן לו זמן לדמיין
  
  **דוגמה:**
  ❌ "אז תשב יותר עם אשתך"
  ✅ "איפה הדרך הזו מובילה אותך? מה יהיה שונה בחיים שלך?"
  
  📊 Gate Check: יש חזון ברור ומעורר השראה → עבור ל-S12

- **S12 (מחויבות - פעולה קונקרטית!):**
  🎯 **משימה:** מחויבות לפעולה **ספציפית וקונקרטית** הבאה.
  
  **שאלות:**
  1. "מה תעשה/י אחרת בפעם הבאה שהמצב הזה יקרה?"
  2. אם המשתמש נותן תשובה כללית: "תן/י לי דוגמה קונקרטית"
  3. "מתי זה יכול לקרות?"
  4. "איך תדע/י שאתה מתחיל/ה לעשות את זה?"
  
  **🛑 חשוב מאוד:** 
  חייבת להיות פעולה **ספציפית**, לא כללית!
  
  ❌ דוגמאות לתשובות לא מספיקות:
  - "אנסה יותר" → כללי מדי!
  - "אהיה יותר קשוב" → לא ספציפי!
  - "אעבוד על זה" → מה זה אומר?
  
  ✅ דוגמאות לתשובות מצוינות:
  - "בפעם הבאה שאשתי תדבר, אניח את הטלפון הצידה ואסתכל לה בעיניים"
  - "כשאני מרגיש שאני מתחיל לגלול בטלפון, אעצור ואשאל אותה 'מה את רוצה לספר לי?'"
  - "בערבים בשעה 8, אכבה את הטלפון ל-30 דקות כדי לשבת איתה"
  
  אם המשתמש נותן תשובה כללית, שאל:
  "זה נשמע טוב. תן/י לי דוגמה **קונקרטית** - מה **בדיוק** תעשה?"
  
  📊 Gate Check: יש מחויבות קונקרטית וספציפית → 🎉 **סיום התהליך!**
  
  **סיום:**
  אחרי המחויבות, סכם את כל המסע:
  "תודה על המסע הזה. התחלנו מ[נושא], עברנו דרך [רגשות], [מחשבות], זיהינו את [הפער], 
   וגילינו את הכוחות שלך [ערכים + יכולות]. עכשיו יש לך דרך חדשה [בחירה] שמובילה ל[חזון], 
   ואתה מתחייב ל[פעולה קונקרטית]. איך זה מרגיש?"

# פלט (Structured Output)
עליך להחזיר תמיד אובייקט JSON הכולל:
```json
{
  "response": "הטקסט האמפתי למשתמש (עברית טבעית)",
  "internal_state": {
    "current_step": "S1",
    "collected_data": {
      "topic": "זוגיות",
      "emotions": ["כעס", "עצב"],
      ...
    },
    "saturation_score": 0.7,
    "reflection": "המשתמש עדיין לא מוכן לעבור ל-S2, צריך עוד שהייה"
  }
}
```

⚠️ CRITICAL: 
- אל תכתוב טקסט רגיל! רק JSON!
- ה-"response" חייב להיות טבעי, חם, אנושי
- אל תזכיר "שלב" או מונחים טכניים למשתמש
- אל תבקש רשימות ("תן לי 4 רגשות") - שאל "מה עוד?"
"""

SYSTEM_PROMPT_EN = """# Identity and Role
You are "Beni", a warm, patient, and empathetic BSD coach ("Return Process").
Your role is not to "solve" problems, but to "hold space" where the coachee discovers answers themselves.

# Core Principle: Shehiya (Staying Power) vs. Haste
**Very Important:** Language models tend to be too efficient. In BSD, efficiency is an obstacle.
- Never ask for lists (e.g., "give me 4 emotions").
- If you identified one emotion, don't move on. Ask "what else?" or "where do you feel it in your body?".
- Create "intentional friction" to prevent the user from escaping to quick solutions.

# Internal Thought Protocol (not shown to user)
Before each response, perform this analysis internally:
1. **Current Stage:** Which stage (S0-S12) am I in based on history?
2. **Saturation Metric:** Has the user truly "stayed" long enough in the current stage? (response length, emotional depth).
3. **Gate Validation:** Have I collected enough data (e.g., 4 emotions in S3) without explicitly asking for it?
4. **Escape Detection:** Is the user trying to jump to solutions? If so, gently return them to observation.

# Conversation Rules
1. **Clean Mirroring:** Repeat user's exact words. If they said "anxiety like a dark cloud", don't interpret as "depression". Ask about the "dark cloud".
2. **No Advice:** Never use "you should", "I suggest" or "try to...". Only ask enabling questions.
3. **Soft Injection:** Use precise questions from the methodology only when user is emotionally ready.
4. **Frustration Detection:** If user expresses confusion, step out of role, explain the value of staying, and ask permission again.

# Stage Structure (for internal enforcement only)
- **S0 (Contract):** Get explicit permission.
- **S1 (Release):** Warm listening to general topic. Don't rush to ask for "specific topic" - let user share at their pace.
- **S2 (Event):** Get one specific moment - **MUST be external interaction with people!**
  
  🚨 **CRITICAL:** Event must be external interaction (conversation, meeting, conflict), NOT internal process (thought, feeling, consideration).
  
  ✅ Correct: "conversation with spouse", "meeting with boss", "argument with friend"
  ❌ Wrong: "I thought about...", "I felt...", "I was considering..."
  
  If user describes internal thought → redirect: "I hear you thought about [X]. Now take me to an external moment - a conversation with someone - where this came up. Who did you talk to?"
  
  Don't accept "I always..." - ask for "one time recently **with someone**".

- **S3 (Emotion):** Identify 4 emotions. Don't move to S4 until they emerge naturally. Don't ask "what emotions?" - ask "how did you feel?" then "what else?".
- **S4 (Thought):** "What went through your mind at that moment?"
- **S5 (Action):** "What did you do?" then "How would you want to act?"
- **S6 (Gap):** Give personal name to gap and rate intensity.
- **S7 (Pattern):** "Does this happen in other places too?"
- **S8 (Stance):** "What do you gain from this stance? What do you lose?"
- **S9 (Forces):** Identify values (source) and abilities (nature).
- **S10 (Choice):** "What new stance do you choose?"
- **S11 (Vision):** "Where does this lead you?"
- **S12 (Commitment):** "What will you do differently next time?"

# Output (Structured Output)
Always return a JSON object with:
```json
{
  "response": "Empathetic text to user (natural language)",
  "internal_state": {
    "current_step": "S1",
    "collected_data": {
      "topic": "relationships",
      "emotions": ["anger", "sadness"],
      ...
    },
    "saturation_score": 0.7,
    "reflection": "User not ready for S2 yet, needs more staying"
  }
}
```

⚠️ CRITICAL:
- Don't write regular text! Only JSON!
- "response" must be natural, warm, human
- Don't mention "stage" or technical terms to user
- Don't ask for lists - ask "what else?"
"""


# ══════════════════════════════════════════════════════════════════════════════
# SAFETY NETS - Minimal validation to prevent premature transitions
# ══════════════════════════════════════════════════════════════════════════════

def count_turns_in_step(state: Dict[str, Any], step: str) -> int:
    """
    Count how many coach-user exchanges happened in a specific step.
    
    Returns:
        Number of turns (coach messages) in that step
    """
    count = 0
    for msg in state.get("messages", []):
        if msg.get("role") == "assistant" and msg.get("metadata", {}).get("internal_state", {}).get("current_step") == step:
            count += 1
    return count


def detect_stage_question_mismatch(coach_message: str, current_step: str, language: str = "he") -> Optional[str]:
    """
    Detect if coach asked a question from a different stage than current_step.
    This happens when LLM moves forward in content but forgets to update current_step in JSON.
    
    Returns:
        The correct stage if mismatch detected, None otherwise
    """
    if language == "he":
        stage_indicators = {
            "S2": ["מה קרה", "מתי זה היה", "מי היה שם", "מי עוד היה"],
            "S3": ["מה הרגשת", "איזה רגש", "איפה הרגשת", "מה עבר בך"],
            "S4": ["מה עבר לך בראש", "מה חשבת", "מה אמרת לעצמך"],
            "S5": ["מה עשית", "מה היית רוצה לעשות"],
            "S6": ["איך תקרא לפער", "בסולם", "כמה חזק הפער"],
            "S7": ["איפה עוד", "מאיפה עוד", "האם אתה מזהה", "האם זה קורה"],
            "S8": ["מה אתה מרוויח", "מה אתה מפסיד", "מה ההפסד", "מה הרווח"],
            "S9": ["איזה ערך", "איזו יכולת", "מה חשוב לך"],
            "S10": ["איזו עמדה", "מה אתה בוחר", "איזו בחירה"]
        }
    else:
        stage_indicators = {
            "S2": ["what happened", "when was", "who was there"],
            "S3": ["what did you feel", "what emotion", "where did you feel"],
            "S4": ["what went through", "what did you think", "what did you tell yourself"],
            "S5": ["what did you do", "what would you want to do"],
            "S6": ["what would you call", "on a scale", "how strong"],
            "S7": ["where else", "do you recognize", "does this happen"],
            "S8": ["what do you gain", "what do you lose"],
            "S9": ["what value", "what ability", "what's important"],
            "S10": ["what stance", "what do you choose"]
        }
    
    coach_lower = coach_message.lower()
    
    # Check each stage's indicators
    for stage, indicators in stage_indicators.items():
        if any(ind in coach_lower for ind in indicators):
            if stage != current_step:
                logger.error(f"[Stage Mismatch!] Coach asked {stage} question but current_step={current_step}")
                logger.error(f"[Stage Mismatch!] Question: {coach_message[:100]}")
                return stage  # Return the correct stage
    
    return None  # No mismatch detected


def has_clear_topic_for_s2(state: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Check if we have a clear enough topic in S1 to move to S2.
    
    Returns:
        (has_clear_topic, reason_if_not)
    """
    messages = state.get("messages", [])
    
    # Get user messages in S1 (approximate - look at recent messages)
    recent_user_msgs = [
        msg.get("content", "")
        for msg in messages[-8:]  # Look at last 8 messages
        if msg.get("sender") == "user" and msg.get("content")
    ]
    
    if len(recent_user_msgs) < 2:
        return False, "need_more_clarification"
    
    # Check total length (not just "על שמחה")
    total_length = sum(len(msg) for msg in recent_user_msgs)
    if total_length < 25:
        return False, "too_vague"
    
    # Check for specific topic indicators
    topic_indicators_he = [
        # Goal/desire words
        "רוצה ל", "להתאמן על", "כדי ש", "שאוכל", "שאדע", "להיות",
        # Problem/challenge words
        "פחד", "קושי", "בעיה", "לא מצליח", "מתקשה", "נאבק",
        # Ability/skill words
        "יכולת", "כישור", "לדבר", "להגיד", "לבטא", "לעשות",
        # Context words
        "עם", "כש", "במצבים", "בזמן", "לפני", "אחרי", "כל", "מול"
    ]
    topic_indicators_en = [
        # Goal/desire words
        "want to", "work on", "so that", "able to", "know how", "to be",
        # Problem/challenge words
        "fear", "difficulty", "problem", "can't", "struggling", "hard to",
        # Ability/skill words
        "ability", "skill", "to speak", "to say", "to express", "to do",
        # Context words
        "with", "when", "in situations", "during", "before", "after", "every", "in front"
    ]
    
    all_text = " ".join(recent_user_msgs)
    
    # Count how many indicators present
    indicator_count = sum(1 for word in topic_indicators_he if word in all_text)
    indicator_count += sum(1 for word in topic_indicators_en if word in all_text.lower())
    
    # Need at least 2 indicators for a clear topic
    if indicator_count < 2:
        return False, "missing_context"
    
    return True, ""


def get_s1_explanation_for_missing_info(reason: str, language: str) -> str:
    """
    Generate explanatory response when user is frustrated in S1 but topic is not clear enough.
    
    User asked "what's missing?" - explain WHY we need more clarity.
    """
    if language == "he":
        explanations = {
            "need_more_clarification": (
                "אני מבין את השאלה. אני שואל עוד כי **צריך שהנושא יהיה מוגדר היטב** לפני שנמשיך. "
                "כדי לזהות את הדפוס שלך, אני צריך להבין במדויק על מה אתה רוצה להתאמן. "
                "מה **בדיוק** בנושא הזה מעסיק אותך? במה אתה מרגיש תקוע?"
            ),
            "too_vague": (
                "אני מבין שאתה רוצה להמשיך. אני שואל עוד כי **הנושא עדיין כללי מדי**. "
                "כדי לעזור לך באמת, אני צריך להבין - באיזה **מצבים ספציפיים** או **הקשרים** "
                "הדבר הזה מעסיק אותך במיוחד?"
            ),
            "missing_context": (
                "אני שומע אותך. אני מבקש עוד הבהרה כי **חסר לי הקשר**. "
                "כדי שנוכל לזהות את הדפוס שלך, חשוב שאבין - "
                "**עם מי** או **באיזה סיטואציות** זה מעסיק אותך במיוחד?"
            )
        }
        return explanations.get(reason, explanations["missing_context"])
    else:
        explanations = {
            "need_more_clarification": (
                "I understand you want to continue. "
                "The reason I'm asking for more clarification is that to identify your pattern, "
                "I need to understand exactly what you want to work on. "
                "Tell me - what specifically concerns you about this topic?"
            ),
            "too_vague": (
                "I understand. "
                "To really help you, I need to understand more deeply - "
                "in what situation or context does this concern you?"
            ),
            "missing_context": (
                "I hear you. "
                "To identify your pattern, it's important I understand - "
                "in what situations or with whom does this particularly concern you?"
            )
        }
        return explanations.get(reason, explanations["missing_context"])


def get_next_step_question(current_step: str, language: str = "he") -> str:
    """
    Get appropriate next question based on current step (for loop prevention).
    
    Instead of always jumping to S4, this returns the right question for progression.
    """
    if language == "he":
        step_questions = {
            "S0": "על מה תרצה להתאמן?",
            "S1": "ספר לי על פעם אחת ספציפית שבו זה קרה - מתי זה היה?",  # Move to S2!
            "S2": "ספר לי על רגע אחד ספציפי שבו זה קרה - מתי זה היה?",
            "S3": "אני מבין. עכשיו אני רוצה לשמוע - מה עבר לך בראש באותו רגע?",
            "S4": "מה עשית באותו רגע?",
            "S5": "איך היית רוצה לפעול באותו רגע?",
            "S6": "איך תקרא לפער הזה? תן לו שם משלך.",
            "S7": "איפה עוד זה קורה?",
            "S8": "מה אתה מרוויח מהדפוס הזה?",
            "S9": "מה חשוב לך בחיים? איזה ערך?",
            "S10": "איזו עמדה חדשה אתה בוחר?",
            "S11": "איפה הבחירה הזו מובילה אותך?",
            "S12": "מה תעשה בפעם הבאה?"
        }
    else:
        step_questions = {
            "S0": "What would you like to work on?",
            "S1": "Tell me about one specific time when this happened - when was it?",  # Move to S2!
            "S2": "Tell me about one specific moment when this happened - when was it?",
            "S3": "I understand. Now I want to hear - what went through your mind in that moment?",
            "S4": "What did you do in that moment?",
            "S5": "How would you have wanted to act in that moment?",
            "S6": "What would you call this gap? Give it a name.",
            "S7": "Where else does this happen?",
            "S8": "What do you gain from this pattern?",
            "S9": "What's important to you in life? What value?",
            "S10": "What new stance do you choose?",
            "S11": "Where does this choice lead you?",
            "S12": "What will you do next time?"
        }
    
    return step_questions.get(current_step, "בוא נמשיך הלאה." if language == "he" else "Let's continue.")


def check_repeated_question(coach_message: str, history: list, current_step: str, language: str = "he") -> Optional[str]:
    """
    Check if coach is repeating a question that was already answered or sent recently.
    
    Returns:
        Correction message if repeating, None otherwise
    """
    # Get recent messages
    recent_coach_messages = [
        msg.get("content", "") for msg in history[-6:]
        if msg.get("sender") in ["coach", "assistant"]
    ]
    
    recent_user_messages = [
        msg.get("content", "").lower() for msg in history[-4:]
        if msg.get("sender") == "user"
    ]
    
    if language == "he":
        # === CRITICAL: Check if user said they're done ===
        import re
        
        # Phrases (can appear anywhere)
        completion_phrases = [
            "זה מסכם", "זה הכל", "כל הרגשות", "זה כל הרגשות",
            "די לי", "כבר כתבתי", "אמרתי את כל", "זה מספיק", 
            "סיימתי", "זה מה שיש", "אין יותר", "אין עוד",
            # NEW: From infinite loop bug analysis
            "לא קרה כלום", "לא קרה שום דבר", "לא היה כלום",
            "כתבתי לך", "אמרתי לך", "עניתי כבר", "עניתי על זה",
            "מה עכשיו", "אולי נמשיך", "בוא נמשיך"
        ]
        
        # Short words (need word boundaries)
        completion_words = ["זהו", "די", "מספיק", "הכל"]
        
        user_said_done = any(
            any(phrase in msg for phrase in completion_phrases) or
            any(re.search(rf'\b{word}\b', msg) for word in completion_words)
            for msg in recent_user_messages
        )
        
        # === Check for "מה עוד?" variants (most common loop) ===
        asking_what_else = any(
            pattern in coach_message.lower()
            for pattern in ["מה עוד", "עוד משהו", "מה נוסף"]
        )
        
        # Count how many "מה עוד?" questions in recent history
        what_else_count = sum(
            1 for msg in recent_coach_messages
            if any(pattern in msg for pattern in ["מה עוד", "עוד משהו"])
        )
        
        # If user said done + coach asking "what else?" again = LOOP!
        if user_said_done and asking_what_else:
            logger.warning(f"[Safety Net] User said done, but coach asking 'מה עוד?' - BLOCKING")
            return get_next_step_question(current_step, language)
        
        # If "מה עוד?" asked 3+ times = LOOP!
        if what_else_count >= 3:
            logger.warning(f"[Safety Net] 'מה עוד?' asked {what_else_count} times - BLOCKING")
            return get_next_step_question(current_step, language)
        
        # === Check if coach is sending the EXACT same message again ===
        if coach_message in recent_coach_messages[-2:]:
            logger.warning(f"[Safety Net] Detected EXACT repeated message")
            return get_next_step_question(current_step, language)
        
        # === Generic patterns (less critical) ===
        generic_patterns = [
            "ספר לי עוד על הרגע הזה",
            "מה בדיוק קרה",
            "ספר לי יותר על"
        ]
        
        generic_count = sum(
            1 for msg_content in recent_coach_messages
            if any(pattern in msg_content for pattern in generic_patterns)
        )
        
        if generic_count >= 3:
            logger.warning(f"[Safety Net] Too many generic questions ({generic_count})")
            return "אני מבין. עכשיו אני רוצה להתעמק ברגשות. מה הרגשת באותו רגע?"
    
    else:  # English
        # Check if user said they're done
        completion_keywords = [
            "that's all", "that's it", "all the", "i'm done",
            "that's everything", "nothing else", "no more",
            # NEW: From infinite loop bug analysis
            "nothing happened", "nothing else happened",
            "i told you", "already told", "already answered",
            "what now", "let's continue", "let's move on"
        ]
        
        user_said_done = any(
            keyword in msg for msg in recent_user_messages
            for keyword in completion_keywords
        )
        
        asking_what_else = any(
            pattern in coach_message.lower()
            for pattern in ["what else", "anything else", "what more"]
        )
        
        what_else_count = sum(
            1 for msg in recent_coach_messages
            if "what else" in msg.lower() or "anything else" in msg.lower()
        )
        
        if user_said_done and asking_what_else:
            logger.warning(f"[Safety Net] User said done, but coach asking 'what else?' - BLOCKING")
            return get_next_step_question(current_step, language)
        
        if what_else_count >= 3:
            logger.warning(f"[Safety Net] 'What else?' asked {what_else_count} times - BLOCKING")
            return get_next_step_question(current_step, language)
        
        if coach_message in recent_coach_messages[-2:]:
            logger.warning(f"[Safety Net] Detected EXACT repeated message")
            return get_next_step_question(current_step, language)
    
    return None


async def user_already_gave_emotions_llm(state: Dict[str, Any], llm, language: str = "he") -> bool:
    """
    Use LLM to detect if user already shared emotions (smart detection).
    More accurate than keyword list - detects "רע", "חנוק", "לא טבעי", etc.
    """
    messages = state.get("messages", [])
    recent_user_messages = [
        msg.get("content", "")
        for msg in messages[-6:]
        if msg.get("sender") == "user" and msg.get("content")
    ]
    
    if not recent_user_messages:
        return False
    
    if language == "he":
        prompt = f"""האם במסרים הבאים המשתמש שיתף רגשות?

רגשות = כעס, עצב, שמחה, פחד, קנאה, תסכול, רע, טוב, חנוק, נזהר, חסום, וכו'

מסרים:
{chr(10).join(f"- {msg}" for msg in recent_user_messages)}

ענה רק: כן או לא"""
    else:
        prompt = f"""Did the user share emotions in the following messages?

Emotions = anger, sadness, joy, fear, jealousy, frustration, bad, good, stuck, scared, etc.

Messages:
{chr(10).join(f"- {msg}" for msg in recent_user_messages)}

Answer only: yes or no"""
    
    try:
        detection_messages = [
            SystemMessage(content="You detect emotions in text." if language == "en" else "אתה מזהה רגשות בטקסט."),
            HumanMessage(content=prompt)
        ]
        
        response = await llm.ainvoke(detection_messages)
        answer = response.content.strip().lower()
        
        has_emotions = "כן" in answer or "yes" in answer
        logger.info(f"[Emotion Detection] LLM detected emotions: {has_emotions}")
        return has_emotions
        
    except Exception as e:
        logger.error(f"[Emotion Detection] LLM call failed: {e}")
        # Fallback to simple keyword check
        return user_already_gave_emotions_simple(state)


def user_already_gave_emotions_simple(state: Dict[str, Any], last_turns: int = 3) -> bool:
    """
    Fallback: Simple keyword-based emotion detection.
    Used if LLM detection fails.
    """
    emotion_keywords_he = [
        "קנאה", "כעס", "עצב", "שמחה", "פחד", "תסכול", "אכזבה",
        "גאווה", "בושה", "אשם", "מבוכה", "עלבון", "ניצול",
        # Extended list
        "רע", "טוב", "חנוק", "נזהר", "לא טבעי", "מתוח", "לחוץ",
        "מבולבל", "מופתע", "נעלב", "מוטרד", "דאוג",
        "הרגשתי", "מרגיש"
    ]
    emotion_keywords_en = [
        "jealous", "anger", "sad", "happy", "fear", "frustrat",
        "disappoint", "proud", "shame", "guilt", "embarrass",
        "bad", "good", "stuck", "scared", "nervous", "worried",
        "felt", "feeling"
    ]
    
    messages = state.get("messages", [])
    recent_user_messages = [
        msg.get("content", "").lower() 
        for msg in messages[-last_turns * 2:] 
        if msg.get("sender") == "user" and msg.get("content")
    ]
    
    for msg in recent_user_messages:
        if any(emotion in msg for emotion in emotion_keywords_he):
            return True
        if any(emotion in msg for emotion in emotion_keywords_en):
            return True
    
    return False


def user_already_gave_emotions(state: Dict[str, Any], last_turns: int = 3) -> bool:
    """
    Synchronous wrapper for backwards compatibility.
    Uses simple keyword detection.
    
    For better detection, use user_already_gave_emotions_llm() in async context.
    """
    return user_already_gave_emotions_simple(state, last_turns)


def detect_stuck_loop(state: Dict[str, Any], last_n: int = 4) -> bool:
    """
    Detect if coach is stuck repeating the same question.
    """
    messages = state.get("messages", [])
    recent_coach = [
        msg.get("content", "")
        for msg in messages[-last_n:]
        if msg.get("sender") == "coach" and msg.get("content")
    ]
    
    if len(recent_coach) < 2:
        return False
    
    # Check exact repetition
    if recent_coach[-1] == recent_coach[-2]:
        logger.warning(f"[Loop Detection] Exact repetition detected!")
        return True
    
    # Check similar questions
    key_phrases = ["מה עוד קרה", "מה הרגשת", "what else happened", "what did you feel"]
    for phrase in key_phrases:
        count = sum(1 for msg in recent_coach if phrase in msg)
        if count >= 2:
            logger.warning(f"[Loop Detection] Repeated question detected: '{phrase}' x{count}")
            return True
    
    return False


def count_pattern_examples_in_s7(state: Dict[str, Any]) -> int:
    """
    Count how many pattern examples user gave in S7 (by content, not just turns).
    """
    messages = state.get("messages", [])
    
    # Get user messages (approximate S7 by looking at recent messages)
    user_msgs = [
        msg.get("content", "")
        for msg in messages[-12:]
        if msg.get("sender") == "user" and msg.get("content")
    ]
    
    if not user_msgs:
        return 0
    
    all_text = " ".join(user_msgs)
    example_count = 0
    
    # Method 1: Count explicit example markers
    example_count += all_text.count("למשל")
    example_count += all_text.count("גם")
    example_count += all_text.count("וגם")
    
    # Method 2: Count location/context indicators
    # "עם חברים", "בעבודה", "עם בן הזוג"
    context_patterns = [
        "עם חברים", "עם משפחה", "עם בן הזוג", "עם אישתי", "עם בעלי",
        "בעבודה", "בבית", "במשרד", "בפגישה",
        "with friends", "with family", "at work", "at home"
    ]
    
    for pattern in context_patterns:
        if pattern in all_text:
            example_count += 1
    
    # Method 3: Check if user explicitly said multiple places
    multiple_indicators = [
        "בהרבה מקומות", "בכל מקום", "בהמון", "בכמה",
        "in many places", "everywhere", "in multiple"
    ]
    
    if any(ind in all_text for ind in multiple_indicators):
        example_count += 2  # "many places" = at least 2 examples
    
    logger.info(f"[Pattern Examples] Counted {example_count} examples in S7")
    return example_count


def user_said_already_gave_examples(user_message: str) -> bool:
    """Check if user explicitly said they already gave examples"""
    phrases_he = [
        "אמרתי כבר", "כבר אמרתי", "כבר נתתי",
        "זה מופיע ב", "זה קורה ב",
        "אמרתי לך"
    ]
    phrases_en = [
        "i already said", "already told", "already gave",
        "it happens in", "it occurs in"
    ]
    
    msg_lower = user_message.lower()
    return any(p in msg_lower for p in phrases_he + phrases_en)


async def validate_situation_quality(state: Dict[str, Any], llm, language: str = "he") -> Tuple[bool, Optional[str]]:
    """
    Validate that the situation (S2) meets basic criteria using FAST rule-based checks.
    We rely on the LLM's prompt instructions for detailed validation to avoid double LLM calls.
    
    This function only performs lightweight checks to catch obvious issues.
    
    Returns:
        (is_valid, guidance_message_if_invalid)
    """
    messages = state.get("messages", [])
    
    # Get user messages from S2
    user_msgs_s2 = [
        msg.get("content", "")
        for msg in messages[-20:]
        if msg.get("sender") == "user" and msg.get("content")
    ]
    
    if len(user_msgs_s2) < 2:
        # Not enough data yet
        return True, None
    
    situation_text = "\n".join(user_msgs_s2[-5:])  # Last 5 user messages
    situation_lower = situation_text.lower()
    
    # FAST rule-based checks (no LLM call!)
    
    # Check 1: Basic length (too short = not enough details)
    if len(situation_text) < 50:
        logger.info(f"[Situation Validation] Too short ({len(situation_text)} chars)")
        return True, None  # Let LLM handle it
    
    # Check 2: "I was alone" = no interpersonal arena
    alone_indicators = ["הייתי לבד", "הייתי בבית לבד", "לבד בבית", "i was alone", "by myself", "all alone"]
    if any(ind in situation_lower for ind in alone_indicators):
        logger.info(f"[Situation Validation] Detected 'alone' situation - needs interpersonal")
        if language == "he":
            return False, """אני מבין את החוויה שתיארת. כדי לזהות דפוס אנחנו מחפשים אירוע שהיו מעורבים בו אנשים נוספים מלבדיך.

בוא ננסה משהו אחר - ספר לי על **אירוע מהחיים שלך** (יכול להיות מהעבודה, עם חברים, עם משפחה, בכל מצב) שבו היו אנשים אחרים וחווית סערה רגשית.

**חשוב:** האירוע לא חייב להיות קשור לנושא האימון - הדפוס שלך מתגלה בכל תחומי החיים, ולפעמים דווקא באירוע מתחום אחר לגמרי."""
        else:
            return False, "I understand the experience you described. To identify a pattern we're looking for an event where other people were involved besides you. Let's try something else - tell me about **an event from your life** (can be from work, with friends, with family, any situation) where other people were present and you experienced emotional turmoil. **Important:** The event doesn't have to be related to the coaching topic - your pattern shows up in all areas of life, sometimes most clearly in a completely different area."
    
    # All basic checks passed - let the LLM prompt handle detailed validation
    logger.info(f"[Situation Validation] Basic checks passed (fast mode, no LLM call)")
    return True, None


def user_questions_unrelated_event(user_message: str) -> bool:
    """
    Check if user is asking why the event doesn't have to be related to coaching topic.
    """
    questions_he = [
        "למה לא", "למה אירוע", "למה סיטואציה", "למה דווקא",
        "מה הקשר", "צריך להיות קשור", "לא קשור",
        "אירוע אחר", "אירוע שלא", "למה לא קשור"
    ]
    questions_en = [
        "why not", "why event", "why situation",
        "what's the connection", "needs to be related", "not related",
        "different event", "unrelated event"
    ]
    
    msg_lower = user_message.lower()
    return any(q in msg_lower for q in questions_he + questions_en)


def user_wants_to_continue(user_message: str) -> bool:
    """
    Check if user is signaling they want to move forward.
    Indicators: "already told you", "let's continue", "nothing happened"
    
    NOTE: This is just an INDICATOR. Don't automatically allow transition!
    Check if we have sufficient info first, then explain if not.
    """
    continue_signals = [
        # Hebrew
        "כתבתי לך", "אמרתי לך", "עניתי", "כבר אמרתי",
        "לא קרה כלום", "לא קרה שום דבר", "לא היה",
        "אולי נמשיך", "בוא נמשיך", "מה עכשיו",
        "זהו", "די", "אין עוד",
        
        # English
        "i told you", "already said", "already answered",
        "nothing happened", "nothing else",
        "let's continue", "let's move on", "what now"
    ]
    
    msg_lower = user_message.lower()
    return any(signal in msg_lower for signal in continue_signals)


def has_sufficient_event_details(state: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Check if we have enough event details in S2 to move to S3 (emotions).
    
    Returns:
        (has_sufficient, reason_if_not)
    """
    messages = state.get("messages", [])
    
    # Get user messages in current stage (rough approximation)
    recent_user_messages = [
        msg.get("content", "")
        for msg in messages[-10:]  # Look at last 10 messages
        if msg.get("sender") == "user" and msg.get("content")
    ]
    
    if len(recent_user_messages) < 2:
        return False, "need_more_responses"
    
    # Check total length (not just "כן" / "לא")
    total_length = sum(len(msg) for msg in recent_user_messages)
    if total_length < 40:
        return False, "responses_too_short"
    
    # Check for detail indicators
    detail_words_he = ["מי", "איפה", "אמר", "עשה", "הגיב", "קרה", "היה"]
    detail_words_en = ["who", "where", "said", "did", "happened", "was", "were"]
    
    all_text = " ".join(recent_user_messages).lower()
    has_he_details = any(word in all_text for word in detail_words_he)
    has_en_details = any(word in all_text for word in detail_words_en)
    
    if not (has_he_details or has_en_details):
        return False, "missing_details"
    
    return True, ""


def get_explanatory_response_for_missing_details(reason: str, language: str) -> str:
    """
    Generate an explanatory response when user is frustrated but we need more info.
    """
    if language == "he":
        explanations = {
            "need_more_responses": (
                "אני מבין שאתה רוצה להמשיך. "
                "כדי שנוכל לזהות את הדפוס שלך בצורה מדויקת, אני צריך עוד קצת פרטים על האירוע הספציפי. "
                "ספר לי - מה בדיוק קרה שם?"
            ),
            "responses_too_short": (
                "אני שומע שאתה רוצה להמשיך. "
                "הסיבה שאני שואל על פרטים היא שכדי לזהות את הדפוס שלך, אני צריך להבין את המצב המלא. "
                "תוכל לספר לי עוד קצת על מה שקרה? מי היה שם? מה בדיוק נאמר?"
            ),
            "missing_details": (
                "אני מבין. הסיבה שאני צריך פרטים נוספים היא שהדפוס שלך מתגלה דרך המצבים הספציפיים. "
                "ספר לי בבקשה - מי עוד היה במצב הזה? מה בדיוק נאמר או קרה?"
            )
        }
        return explanations.get(reason, explanations["missing_details"])
    else:
        explanations = {
            "need_more_responses": (
                "I understand you want to continue. "
                "To accurately identify your pattern, I need a few more details about the specific event. "
                "Tell me - what exactly happened there?"
            ),
            "responses_too_short": (
                "I hear you want to move forward. "
                "The reason I'm asking for details is that to identify your pattern, I need to understand the full situation. "
                "Can you tell me more about what happened? Who was there? What exactly was said?"
            ),
            "missing_details": (
                "I understand. The reason I need more details is that your pattern reveals itself through specific situations. "
                "Please tell me - who else was in this situation? What exactly was said or happened?"
            )
        }
        return explanations.get(reason, explanations["missing_details"])


def validate_stage_transition(
    old_step: str,
    new_step: str,
    state: Dict[str, Any],
    language: str,
    coach_message: str = ""
) -> Tuple[bool, Optional[str]]:
    """
    Safety net: validate if stage transition is premature.
    
    Args:
        old_step: Current step before transition
        new_step: Proposed new step
        state: Current conversation state
        language: "he" or "en"
        coach_message: The LLM's proposed message (to check if already in new stage)
    
    Returns:
        (is_valid, correction_message)
        - If is_valid=True, allow the transition
        - If is_valid=False, return correction message to override LLM response
    """
    # GENERIC SOLUTION: Check if user wants to move on
    recent_user_messages = [
        msg.get("content", "").lower() for msg in state.get("messages", [])[-3:]
        if msg.get("sender") == "user"
    ]
    
    if language == "he":
        move_on_keywords = [
            "מסכם", "זה הכל", "נתקדם", "הלאה", "די", "די לי",
            "כל הרגשות", "כבר כתבתי", "בוא נתקדם", "מה הלאה",
            "אמרתי כבר", "כבר אמרתי", "עניתי", "זה מספיק"
        ]
    else:
        move_on_keywords = [
            "that's all", "let's move", "move on", "enough", "that's it",
            "i already said", "already told", "move forward", "what's next"
        ]
    
    user_wants_to_move_on = any(
        keyword in msg for msg in recent_user_messages
        for keyword in move_on_keywords
    )
    
    # If user explicitly wants to move on, ALWAYS allow transition
    if user_wants_to_move_on:
        logger.info(f"[Safety Net] User wants to move on - allowing {old_step}→{new_step}")
        return True, None
    
    # Otherwise, check minimum turns for critical transitions
    
    # 🚨 CRITICAL: S1→S2 - Must have clear topic!
    if old_step == "S1" and new_step == "S2":
        has_topic, reason = has_clear_topic_for_s2(state)
        
        if not has_topic:
            logger.warning(f"[Safety Net] Blocking S1→S2: topic not clear ({reason})")
            if language == "he":
                return False, "אני מבין שאתה רוצה להמשיך. אבל **לפני שניקח אירוע ספציפי, אני צריך להבין בדיוק על מה אתה רוצה להתאמן**. ספר לי - מה מעסיק אותך?"
            else:
                return False, "I understand you want to continue. But **before we take a specific event, I need to understand exactly what you want to work on**. Tell me - what's on your mind?"
    
    # 🚨 CRITICAL: Block S1→S3 (can't skip S2 event!)
    if old_step == "S1" and new_step == "S3":
        logger.error(f"[Safety Net] 🚫 BLOCKED S1→S3: Cannot skip S2 (event)!")
        if language == "he":
            return False, "רגע, לפני שנדבר על רגשות - בוא ניקח **אירוע ספציפי אחד** שקרה לאחרונה. ספר לי על פעם אחת ש[נושא] - מתי זה היה? עם מי?"
        else:
            return False, "Wait, before we talk about emotions - let's take **one specific event** that happened recently. Tell me about one time when [topic] - when was it? Who was there?"
    
    # 🚨 CRITICAL: Block S1→S4, S1→S5, etc. (can't skip multiple stages!)
    if old_step == "S1" and new_idx > 2:
        logger.error(f"[Safety Net] 🚫 BLOCKED S1→{new_step}: Cannot skip S2!")
        if language == "he":
            return False, "רגע, בוא קודם ניקח אירוע ספציפי אחד. ספר לי על פעם אחת לאחרונה - מתי זה היה?"
        else:
            return False, "Wait, let's first take one specific event. Tell me about one time recently - when was it?"
    
    # 🚨 CRITICAL: Block S2→S4 (can't skip S3 emotions!)
    if old_step == "S2" and new_step == "S4":
        logger.error(f"[Safety Net] 🚫 BLOCKED S2→S4: Cannot skip S3 (emotions)!")
        if language == "he":
            return False, "רגע, לפני שנדבר על מחשבות - ספר לי קודם **מה הרגשת** באותו רגע?"
        else:
            return False, "Wait, before we talk about thoughts - tell me first **what did you feel** in that moment?"
    
    # 🚨 CRITICAL: Block backwards transitions (can't go backwards!)
    stage_order = ["S0", "S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8", "S9", "S10", "S11", "S12"]
    try:
        old_idx = stage_order.index(old_step) if old_step in stage_order else -1
        new_idx = stage_order.index(new_step) if new_step in stage_order else -1
        
        # Don't allow going backwards (except to S0/S1 which are resets)
        if old_idx >= 2 and new_idx >= 2 and new_idx < old_idx:
            logger.error(f"[Safety Net] 🚫 BLOCKED backwards transition {old_step}→{new_step}")
            if language == "he":
                return False, "בוא נמשיך הלאה במקום לחזור אחורה."
            else:
                return False, "Let's move forward instead of going backwards."
    except (ValueError, AttributeError):
        pass  # Stage not in list, continue
    
    # S2→S3: Need detailed event (at least 3 turns in S2)
    if old_step == "S2" and new_step == "S3":
        s2_turns = count_turns_in_step(state, "S2")
        
        # 🚨 CRITICAL: Check if stuck in loop
        if detect_stuck_loop(state):
            logger.error(f"[Safety Net] 🔄 LOOP DETECTED! Forcing progression to S3")
            return True, None  # Force progression!
        
        # 🚨 CRITICAL: Check if user already gave emotions (wrong stage!)
        if user_already_gave_emotions(state):
            logger.info(f"[Safety Net] ✅ User already gave emotions, allowing S2→S3 transition")
            return True, None  # Allow transition
        
        # 🚨 NEW LOGIC: Check if user is frustrated
        user_msg = state.get("messages", [])[-1].get("content", "") if state.get("messages") else ""
        if user_wants_to_continue(user_msg):
            logger.warning(f"[Safety Net] 🤔 User frustrated - checking if we have sufficient info...")
            
            # Check if we actually have enough event details
            has_info, reason = has_sufficient_event_details(state)
            
            if has_info:
                # Good to go - user is frustrated but we have enough info
                logger.info(f"[Safety Net] ✅ User frustrated BUT has sufficient details → allowing S2→S3")
                return True, None
            else:
                # Need more info - EXPLAIN why instead of just asking again
                logger.warning(f"[Safety Net] ⚠️ User frustrated BUT missing details ({reason}) → explaining")
                explanation = get_explanatory_response_for_missing_details(reason, language)
                return False, explanation
        
        # 🎯 Check if LLM already asked an S3 question (emotions)
        # If yes, allow the transition even if s2_turns < 3
        # This prevents overriding good LLM responses
        if language == "he":
            s3_indicators = ["מה הרגשת", "איזה רגש", "מה עבר בך", "מה נגע בך", "התעמק ברגשות"]
        else:
            s3_indicators = ["what did you feel", "what emotion", "how did you feel", "feelings", "emotions"]
        
        llm_already_in_s3 = any(indicator in coach_message.lower() for indicator in s3_indicators)
        
        if llm_already_in_s3:
            logger.info(f"[Safety Net] LLM already asked S3 question, allowing transition despite {s2_turns} turns")
            return True, None  # Allow transition
        
        # If LLM hasn't moved to S3 yet, check turns count
        if s2_turns < 3:
            logger.warning(f"[Safety Net] Blocked S2→S3: only {s2_turns} turns in S2, need 3+")
            if language == "he":
                # GENERIC: Start with general questions, then specific (not dialogue-first)
                followup_questions = [
                    "מה עוד קרה באותו רגע? ספר לי יותר פרטים.",
                    "איך זה התפתח? מה קרה **אחרי** זה?",
                    "מי עוד היה שם? איך **הם** הגיבו?",
                    "אם היה דיאלוג, מה **בדיוק** נאמר?"
                ]
                question = followup_questions[min(s2_turns, len(followup_questions) - 1)]
                return False, question
            else:
                followup_questions = [
                    "What else happened in that moment? Tell me more details.",
                    "How did it develop? What happened **after** that?",
                    "Who else was there? How did **they** react?",
                    "If there was dialogue, what **exactly** was said?"
                ]
                question = followup_questions[min(s2_turns, len(followup_questions) - 1)]
                return False, question
    
    # S3→S4: Need emotions (at least 3 turns in S3)
    if old_step == "S3" and new_step == "S4":
        s3_turns = count_turns_in_step(state, "S3")
        
        # 🚨 CRITICAL: Check if stuck in loop
        if detect_stuck_loop(state):
            logger.error(f"[Safety Net] 🔄 LOOP DETECTED! Forcing progression to S4")
            return True, None  # Force progression!
        
        # 🚨 NEW LOGIC: Check if user is frustrated
        user_msg = state.get("messages", [])[-1].get("content", "") if state.get("messages") else ""
        if user_wants_to_continue(user_msg):
            logger.warning(f"[Safety Net] 🤔 User frustrated in S3 - checking if we have sufficient emotions...")
            
            # For S3, if user already gave emotions, that's usually enough
            # Check if we have at least some emotion words
            if user_already_gave_emotions(state):
                logger.info(f"[Safety Net] ✅ User frustrated BUT has emotions → allowing S3→S4")
                return True, None
            else:
                # Missing emotions - explain why we need them
                logger.warning(f"[Safety Net] ⚠️ User frustrated BUT no emotions yet → explaining")
                if language == "he":
                    explanation = (
                        "אני מבין שאתה רוצה להמשיך. "
                        "הסיבה שאני צריך לשמוע על הרגשות שלך היא שהן חלק מרכזי בדפוס - "
                        "הדפוס הוא השילוב של המצב, הרגש והמחשבה שחוזרים. "
                        "מה הרגשת באותו רגע?"
                    )
                else:
                    explanation = (
                        "I understand you want to continue. "
                        "The reason I need to hear about your emotions is that they're a central part of the pattern - "
                        "the pattern is the combination of situation, emotion, and thought that repeats. "
                        "What did you feel in that moment?"
                    )
                return False, explanation
        
        # 🎯 Check if LLM already asked an S4 question (thoughts)
        # If yes, allow the transition even if s3_turns < 3
        if language == "he":
            s4_indicators = ["מה עבר לך בראש", "מה חשבת", "מה אמרת לעצמך", "איזה משפט", "מחשב"]
        else:
            s4_indicators = ["what went through your mind", "what did you think", "what did you tell yourself", "thought"]
        
        llm_already_in_s4 = any(indicator in coach_message.lower() for indicator in s4_indicators)
        
        if llm_already_in_s4:
            logger.info(f"[Safety Net] LLM already asked S4 question, allowing transition despite {s3_turns} turns")
            return True, None  # Allow transition
        
        # If LLM hasn't moved to S4 yet, check turns count
        if s3_turns < 3:
            logger.warning(f"[Safety Net] Blocked S3→S4: only {s3_turns} turns in S3")
            if language == "he":
                return False, "מה עוד הרגשת באותו רגע?"
            else:
                return False, "What else did you feel in that moment?"
    
    # S7→S8: Need pattern confirmation
    if old_step == "S7" and new_step == "S8":
        # Check if user explicitly said they don't understand the pattern
        if language == "he":
            confusion_keywords = ["לא יודע מה הדפוס", "לא מבין מה הדפוס", "מה הדפוס", "איזה דפוס"]
        else:
            confusion_keywords = ["don't know the pattern", "what pattern", "which pattern", "what is the pattern"]
        
        user_confused = any(
            keyword in msg for msg in recent_user_messages
            for keyword in confusion_keywords
        )
        
        if user_confused:
            logger.warning(f"[Safety Net] Blocked S7→S8: user doesn't understand the pattern yet")
            if language == "he":
                # Need to explicitly summarize the pattern
                return False, "אני מבין. בוא נסכם: הדפוס הוא שאתה מגיב בדרך מסוימת במצבים שונים. מה התגובה שלך שחוזרת? מה משותף בין המצבים שתיארת?"
            else:
                return False, "I understand. Let's summarize: the pattern is that you respond in a certain way in different situations. What's your response that repeats? What's common between the situations you described?"
        
        # 🚨 NEW: Check if user already gave examples and said so
        user_msg = state.get("messages", [])[-1].get("content", "") if state.get("messages") else ""
        example_count = count_pattern_examples_in_s7(state)
        
        if example_count >= 2 and user_said_already_gave_examples(user_msg):
            logger.info(f"[Safety Net] User gave {example_count} examples + said 'already told' → allowing S7→S8")
            return True, None
        
        # 🚨 NEW: Check if stuck in loop asking "where else?"
        if detect_stuck_loop(state) and example_count >= 2:
            logger.error(f"[Safety Net] LOOP in S7 with {example_count} examples → forcing S8")
            return True, None
        
        # Check if we have sufficient examples (content-based, not just turns)
        s7_turns = count_turns_in_step(state, "S7")
        
        if example_count >= 2 and s7_turns >= 3:
            # Has enough examples and turns → allow transition
            logger.info(f"[Safety Net] S7 has {example_count} examples + {s7_turns} turns → allowing S7→S8")
            return True, None
        
        if s7_turns < 3:
            logger.warning(f"[Safety Net] Blocked S7→S8: only {s7_turns} turns and {example_count} examples")
            if language == "he":
                # GENERIC: Varied questions to explore pattern depth
                pattern_questions = [
                    "איפה עוד אתה מזהה את התגובה הזו שלך?",
                    "האם זה קורה רק במצבים מסוימים, או גם במקומות אחרים?",
                    "מה משותף לכל המצבים שתיארת? מה **אתה** עושה שחוזר?"
                ]
                question = pattern_questions[min(s7_turns, len(pattern_questions) - 1)]
                return False, question
            else:
                pattern_questions = [
                    "Where else do you recognize this response of yours?",
                    "Does this happen only in certain situations, or in other places too?",
                    "What's common to all the situations you described? What do **you** do that repeats?"
                ]
                question = pattern_questions[min(s7_turns, len(pattern_questions) - 1)]
                return False, question
    
    # All other transitions: trust the LLM
    return True, None


# ══════════════════════════════════════════════════════════════════════════════
# CONTEXT BUILDER
# ══════════════════════════════════════════════════════════════════════════════

def build_conversation_context(
    state: Dict[str, Any],
    user_message: str,
    language: str
) -> str:
    """
    Build rich context for LLM.
    
    Includes:
    - Current state (step, collected data)
    - Recent conversation history
    - User's new message
    
    Args:
        state: Current conversation state
        user_message: User's new message
        language: "he" or "en"
    
    Returns:
        Context string for LLM
    """
    # Get recent history (last 12 messages to ensure full context)
    history = get_conversation_history(state, last_n=12)
    logger.info(f"[BSD V2 CONTEXT] Found {len(history)} messages in history")
    
    # Build context
    context_parts = []
    
    # Current state
    context_parts.append("# מצב נוכחי" if language == "he" else "# Current State")
    context_parts.append(f"שלב: {state['current_step']}" if language == "he" else f"Stage: {state['current_step']}")
    context_parts.append(f"Saturation Score: {state['saturation_score']:.1f}")
    
    # Collected data (non-null only)
    collected = {k: v for k, v in state['collected_data'].items() if v is not None and v != [] and v != {}}
    if collected:
        context_parts.append("\nנתונים שנאספו:" if language == "he" else "\nCollected Data:")
        context_parts.append(json.dumps(collected, ensure_ascii=False, indent=2))
    
    # Extract event details from history for S2 (to prevent repeated questions)
    if state['current_step'] == 'S2' and history:
        event_summary = []
        for msg in history:
            if msg['sender'] == 'user':
                content = msg['content'].lower()
                # Check for location mentions
                if 'בחדר' in content or 'בבית' in content or 'במקום' in content:
                    event_summary.append(f"✓ מקום כבר נאמר: {msg['content'][:80]}...")
                # Check for time mentions
                if 'אתמול' in content or 'שישי' in content or 'שבוע' in content or 'חודש' in content:
                    event_summary.append(f"✓ זמן כבר נאמר: {msg['content'][:80]}...")
                # Check for people mentions
                if 'אשתי' in content or 'בת זוג' in content or 'ילדים' in content:
                    event_summary.append(f"✓ מי כבר נאמר: {msg['content'][:80]}...")
        
        if event_summary:
            context_parts.append("\n🚨 חשוב - פרטים שכבר נאמרו על האירוע:" if language == "he" else "\n🚨 Important - Event details already mentioned:")
            context_parts.extend(event_summary)
            if language == "he":
                context_parts.append("⚠️ אל תשאל שוב על פרטים שכבר נאמרו!")
            else:
                context_parts.append("⚠️ Don't ask again about details already mentioned!")
    
    # Conversation history with EMPHASIS
    if history:
        context_parts.append("\n# היסטוריה אחרונה - קרא בעיון!" if language == "he" else "\n# Recent History - Read Carefully!")
        if language == "he":
            context_parts.append("🚨 חשוב: אל תשאל שאלות שהמשתמש כבר ענה עליהן בהיסטוריה!")
        else:
            context_parts.append("🚨 Important: Don't ask questions the user already answered in the history!")
        
        for msg in history:
            sender_value = msg.get("sender", "unknown")
            content_value = msg.get("content", "")
            if not content_value:  # Skip empty messages
                continue
            sender = "משתמש" if sender_value == "user" else "מאמן"
            if language == "en":
                sender = "User" if sender_value == "user" else "Coach"
            context_parts.append(f"{sender}: {content_value}")
    
    # New message
    context_parts.append("\n# הודעה חדשה" if language == "he" else "\n# New Message")
    context_parts.append(f"משתמש: {user_message}" if language == "he" else f"User: {user_message}")
    
    return "\n".join(context_parts)


# ══════════════════════════════════════════════════════════════════════════════
# MAIN HANDLER
# ══════════════════════════════════════════════════════════════════════════════

async def handle_conversation(
    user_message: str,
    state: Dict[str, Any],
    language: str = "he"
) -> Tuple[str, Dict[str, Any]]:
    """
    Handle single conversation turn in V2.
    
    Flow:
    1. Build context from state + history + new message
    2. Call LLM with system prompt
    3. Parse JSON response
    4. Extract coach message and internal state
    5. Update state
    6. Return (coach_message, updated_state)
    
    Args:
        user_message: User's message
        state: Current conversation state
        language: "he" or "en"
    
    Returns:
        (coach_message, updated_state)
    """
    logger.info(f"[BSD V2] Handling message: '{user_message[:50]}...'")
    logger.info(f"[BSD V2] Current step: {state['current_step']}, saturation: {state['saturation_score']:.2f}")
    logger.info(f"[BSD V2] Message count in state: {len(state.get('messages', []))}")
    
    # 🚨 CRITICAL: Check if user is asking about unrelated event
    if state["current_step"] == "S2" and user_questions_unrelated_event(user_message):
        logger.info(f"[Safety Net] User asking about unrelated event - explaining directly")
        if language == "he":
            explanation = """שאלה מעולה! הסיטואציה **לא חייבת** להיות קשורה לנושא האימון.

למה? כי **הדפוס שלך הולך איתך לכל מקום** - לבית, לעבודה, לחברים, לכל תחום בחיים.

לפעמים דווקא באירוע מתחום **אחר לגמרי** (למשל: שיחה עם חבר, מצב בעבודה, אינטראקציה עם בן משפחה) הדפוס מתגלה בצורה הכי **נקייה וברורה** - בלי הרבה "רעש" סביב.

אז תרגיש חופשי לשתף אירוע מכל תחום שבו היית באינטראקציה עם אנשים והרגשת סערה רגשית. מה עולה לך?"""
        else:
            explanation = """Great question! The situation **doesn't have to** be related to the coaching topic.

Why? Because **your pattern goes with you everywhere** - home, work, friends, every area of life.

Sometimes a situation from a **completely different area** (e.g., conversation with a friend, situation at work, interaction with family) reveals the pattern most **clearly** - without a lot of "noise" around it.

So feel free to share an event from any area where you interacted with people and felt emotional turmoil. What comes to mind?"""
        
        # Add this as a coach response directly, no need for LLM
        internal_state = {
            "current_step": state["current_step"],  # Stay in same stage
            "saturation_score": state.get("saturation_score", 0.3),
            "reflection": "Explained why event doesn't need to be related to topic"
        }
        state = add_message(state, "user", user_message)
        state = add_message(state, "coach", explanation, internal_state)
        return explanation, state
    
    # Check if user is frustrated - Use EXPLICIT phrases only (no single words)
    # This avoids false positives like "לא חש מספיק טוב" while catching real frustration
    
    user_frustrated = False
    if language == "he":
        user_msg_lower = user_message.lower()
        
        # ONLY very explicit frustration phrases (2+ words)
        # Do NOT use single words like "די", "מספיק", "זהו" alone
        explicit_frustration_phrases = [
            "אמרתי כבר", "אמרתי לך", "כבר אמרתי", "כבר סיפרתי",
            "חזרת על עצמך", "אתה חוזר", "עניתי כבר", "עניתי לך",
            "די כבר", "די די", "מספיק כבר", "די לי כבר"
        ]
        
        user_frustrated = any(phrase in user_msg_lower for phrase in explicit_frustration_phrases)
    else:
        explicit_frustration_phrases = [
            "i already said", "i told you", "already told you", 
            "you're repeating", "i already answered", "stop repeating"
        ]
        user_frustrated = any(phrase in user_message.lower() for phrase in explicit_frustration_phrases)
    
    if user_frustrated:
        logger.warning(f"[Safety Net] User is frustrated ('{user_message}') - checking if can progress")
        current_step = state['current_step']
        
        # Add user message first
        state = add_message(state, "user", user_message)
        
        # 🎯 SPECIAL HANDLING FOR S1 - check if topic is clear before progressing
        if current_step == "S1":
            has_topic, reason = has_clear_topic_for_s2(state)
            
            if has_topic:
                # ✅ Topic is clear - can progress to S2
                logger.info(f"[Safety Net] User frustrated in S1, but topic is clear → moving to S2")
                if language == "he":
                    apology_message = f"אני מבין. {get_next_step_question(current_step, language)}"
                else:
                    apology_message = f"I understand. {get_next_step_question(current_step, language)}"
                
                next_step = "S2"
            else:
                # ⚠️ Topic not clear - EXPLAIN why we need more info
                logger.warning(f"[Safety Net] User frustrated in S1, but topic not clear ({reason}) → explaining")
                apology_message = get_s1_explanation_for_missing_info(reason, language)
                next_step = "S1"  # Stay in S1 but with explanation
        else:
            # For other stages, use standard progression
            if language == "he":
                apology_message = f"מצטער על החזרה! {get_next_step_question(current_step, language)}"
            else:
                apology_message = f"Sorry for repeating! {get_next_step_question(current_step, language)}"
            
            # Determine next step
            step_progression = {
                "S0": "S1", "S1": "S2", "S2": "S3", "S3": "S4",
                "S4": "S5", "S5": "S6", "S6": "S7", "S7": "S8",
                "S8": "S9", "S9": "S10", "S10": "S11", "S11": "S12"
            }
            next_step = step_progression.get(current_step, current_step)
        
        # Add coach response
        internal_state = {
            "current_step": next_step,
            "saturation_score": 0.3,
            "reflection": f"User frustrated - moving from {current_step} to {next_step}"
        }
        state = add_message(state, "coach", apology_message, internal_state)
        
        return apology_message, state
    
    try:
        start_time = time.time()
        
        # 1. Build context
        t1 = time.time()
        context = build_conversation_context(state, user_message, language)
        t2 = time.time()
        logger.info(f"[PERF] Build context: {(t2-t1)*1000:.0f}ms ({len(context)} chars)")
        
        # 2. Prepare messages (use DYNAMIC assembly for speed!)
        # Assemble only the relevant prompt for current stage
        current_stage = state.get("current_step", "S1")
        system_prompt = assemble_system_prompt(current_stage)
        
        logger.info(f"[PERF] Assembled prompt for {current_stage}: ~{len(system_prompt)} chars")
        
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=context)
        ]
        
        # 3. Call LLM
        t3 = time.time()
        llm = get_azure_chat_llm(purpose="talker")  # Higher temperature for natural conversation
        response = await llm.ainvoke(messages)
        t4 = time.time()
        
        response_text = response.content.strip()
        
        logger.info(f"[PERF] LLM call: {(t4-t3)*1000:.0f}ms")
        logger.info(f"[BSD V2] LLM response ({len(response_text)} chars)")
        logger.info(f"[BSD V2] LLM response preview: {response_text[:500]}...")
        
        # 4. Parse JSON response
        t5 = time.time()
        try:
            # Clean markdown code blocks if present
            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]
                response_text = response_text.strip()
            
            parsed = json.loads(response_text)
            
            # Try both field names for backwards compatibility
            coach_message = parsed.get("coach_message", "") or parsed.get("response", "")
            internal_state = parsed.get("internal_state", {})
            
        except json.JSONDecodeError as e:
            logger.error(f"[BSD V2] Failed to parse JSON: {e}")
            logger.error(f"[BSD V2] Response text: {response_text}")
            
            # Fallback: treat entire response as coach message
            coach_message = response_text
            internal_state = {
                "current_step": state["current_step"],
                "saturation_score": state["saturation_score"],
                "reflection": "Failed to parse structured output"
            }
        t6 = time.time()
        logger.info(f"[PERF] Parse JSON: {(t6-t5)*1000:.0f}ms")
        
        # 5. Safety Net: Check for repeated questions
        t7 = time.time()
        history_for_check = get_conversation_history(state, last_n=10)
        repeated_check = check_repeated_question(coach_message, history_for_check, state['current_step'], language)
        t8 = time.time()
        logger.info(f"[PERF] Repeated check: {(t8-t7)*1000:.0f}ms")
        
        if repeated_check:
            logger.warning(f"[Safety Net] Overriding repeated question")
            coach_message = repeated_check
            # Force move to S3
            internal_state["current_step"] = "S3"
            internal_state["saturation_score"] = 0.3
        
        # 6. Safety Net: Check for stage/question mismatch
        t9 = time.time()
        mismatch_stage = detect_stage_question_mismatch(coach_message, state["current_step"], language)
        t10 = time.time()
        logger.info(f"[PERF] Stage mismatch check: {(t10-t9)*1000:.0f}ms")
        
        if mismatch_stage:
            logger.warning(f"[Safety Net] Auto-correcting stage mismatch: {state['current_step']} → {mismatch_stage}")
            internal_state["current_step"] = mismatch_stage
        
        # 6.5. Safety Net: Validate situation quality (S2→S3 only)
        old_step = state["current_step"]
        new_step = internal_state.get("current_step", old_step)
        
        t11 = time.time()
        if old_step == "S2" and new_step == "S3":
            # Check if situation meets all 4 criteria
            logger.info(f"[Safety Net] Validating S2 situation quality before S2→S3...")
            situation_valid, guidance = await validate_situation_quality(state, llm, language)
            logger.info(f"[Safety Net] Validation result: valid={situation_valid}")
            if not situation_valid and guidance:
                logger.warning(f"[Safety Net] Situation doesn't meet criteria, blocking S2→S3")
                coach_message = guidance
                internal_state["current_step"] = "S2"  # Stay in S2
        t12 = time.time()
        if old_step == "S2" and new_step == "S3":
            logger.info(f"[PERF] S2 validation: {(t12-t11)*1000:.0f}ms")
        
        # 7. Safety Net: Validate stage transition
        t13 = time.time()
        is_valid, correction = validate_stage_transition(old_step, new_step, state, language, coach_message)
        t14 = time.time()
        logger.info(f"[PERF] Stage transition validation: {(t14-t13)*1000:.0f}ms")
        
        if not is_valid and correction:
            # Override LLM response with correction
            logger.warning(f"[Safety Net] Overriding transition {old_step}→{new_step}")
            coach_message = correction
            # Keep current step (don't advance)
            internal_state["current_step"] = old_step
        
        # 7. Update state
        logger.info(f"[BSD V2] Parsed coach_message: {coach_message[:100]}...")
        logger.info(f"[BSD V2] Parsed internal_state: {json.dumps(internal_state, ensure_ascii=False)[:200]}...")
        
        # Add user message
        state = add_message(state, "user", user_message)
        
        # Add coach message with internal state
        state = add_message(state, "coach", coach_message, internal_state)
        
        end_time = time.time()
        total_ms = (end_time - start_time) * 1000
        
        logger.info(f"[BSD V2] Updated to step: {state['current_step']}, saturation: {state['saturation_score']:.2f}")
        logger.info(f"[BSD V2] Total messages now: {len(state['messages'])}")
        logger.info(f"[PERF] ⏱️  TOTAL TIME: {total_ms:.0f}ms ({total_ms/1000:.1f}s)")
        
        return coach_message, state
        
    except Exception as e:
        logger.error(f"[BSD V2] Error handling conversation: {e}")
        import traceback
        traceback.print_exc()
        
        # Fallback response
        if language == "he":
            fallback = "מצטער, היתה בעיה טכנית. האם נוכל לנסות שוב?"
        else:
            fallback = "Sorry, there was a technical issue. Can we try again?"
        
        return fallback, state
