#!/usr/bin/env python3
"""
Test script for coaching flow improvements.
Tests:
1. Meta-discussion detection
2. S2 specificity gate
3. Vulnerable moment handling
4. S1->S2 transition (topic to event)
5. S5 two-turn stage (actual + desired)
"""

import asyncio
import sys
import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
env_path = Path(__file__).parent / ".env"
if env_path.exists():
    load_dotenv(env_path)
    print(f"✅ Loaded .env from {env_path}")
else:
    print(f"⚠️  No .env file found at {env_path}")

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent))

from app.bsd.reasoner import decide, classify_s0_intent
from app.bsd.stage_defs import StageId
from app.bsd.state_schema import BsdState, CognitiveData, EventActual
from app.bsd.talker import generate_coach_message
from app.bsd.router_s1 import route_s1


def print_section(title: str):
    """Print a test section header."""
    print("\n" + "=" * 70)
    print(f"  {title}")
    print("=" * 70)


def print_result(test_name: str, result: dict):
    """Print test result in a readable format."""
    print(f"\n🧪 TEST: {test_name}")
    print(f"   Intent: {result.get('intent', 'N/A')}")
    print(f"   Decision: {result.get('decision', 'N/A')}")
    if result.get('critique'):
        print(f"   Critique: {result.get('critique')}")
    if result.get('reasons'):
        print(f"   Reasons: {result.get('reasons')}")
    if result.get('extracted'):
        print(f"   Extracted: {result.get('extracted')}")
    if result.get('missing'):
        print(f"   Missing: {result.get('missing')}")


async def test_meta_discussion():
    """Test 1: Meta-discussion detection."""
    print_section("TEST 1: Meta-Discussion Detection")
    
    test_cases = [
        ("אנחנו בשלב המצוי?", "S3", "he"),
        ("איפה אנחנו בתהליך?", "S4", "he"),
        ("what stage are we in?", "S3", "en"),
        ("כעס ותסכול", "S3", "he"),  # Regular emotion - should NOT be meta
    ]
    
    for user_msg, stage, lang in test_cases:
        result = await decide(
            stage=stage,
            user_message=user_msg,
            language=lang
        )
        
        print_result(
            f"'{user_msg}' in {stage}",
            {
                "intent": result.intent,
                "decision": result.decision,
                "critique": result.critique,
                "reasons": result.reasons
            }
        )
        
        expected_meta = any(p in user_msg.lower() for p in ["שלב", "stage", "איפה"])
        is_meta = result.intent == "META_DISCUSSION"
        status = "✅" if is_meta == expected_meta else "❌"
        print(f"   {status} Expected meta={expected_meta}, got meta={is_meta}")


async def test_s2_specificity():
    """Test 2: S2 event specificity gate."""
    print_section("TEST 2: S2 Event Specificity Gate")
    
    test_cases = [
        # Not specific enough
        ("יש פרויקט שאני עובד עליו", "S2", "he", False),
        ("I have a project I'm working on", "S2", "en", False),
        
        # Specific enough (has who/when/what)
        ("אתמול בערב ביקשתי מהילד שלי לעשות שיעורים", "S2", "he", True),
        ("Yesterday I asked my son to do homework and he refused", "S2", "en", True),
    ]
    
    for user_msg, stage, lang, should_advance in test_cases:
        result = await decide(
            stage=stage,
            user_message=user_msg,
            language=lang
        )
        
        print_result(
            f"'{user_msg[:40]}...'",
            {
                "intent": result.intent,
                "decision": result.decision,
                "critique": result.critique,
                "missing": result.missing
            }
        )
        
        advanced = result.decision == "advance"
        status = "✅" if advanced == should_advance else "❌"
        print(f"   {status} Expected advance={should_advance}, got advance={advanced}")


async def test_vulnerable_moments():
    """Test 3: Vulnerable moment handling in talker."""
    print_section("TEST 3: Vulnerable Moment Handling")
    
    # Simulate S4->S5 transition with vulnerable thought
    state = BsdState(
        current_state="S5",
        cognitive_data=CognitiveData(
            event_actual=EventActual(
                emotions_list=["כעס", "תסכול", "יאוש", "עצב"],
                thought_content="אני אפסס"  # Vulnerable!
            )
        ),
        last_user_message="פשוט סגרתי את המחשב והלכתי",
        last_extracted={}
    )
    
    # Generate coach message for S5 after S4 with vulnerable thought
    coach_msg, opener = await generate_coach_message(
        stage=StageId.S5,
        user_message="פשוט סגרתי את המחשב והלכתי",
        language="he",
        intent="ANSWER_PARTIAL",
        critique="",
        is_loop=True,
        missing={"action_desired": True},
        cognitive_data=state.cognitive_data.model_dump(),
        user_name="Ishai",
        user_gender="male",
        recent_openers=[]
    )
    
    print(f"\n🧪 TEST: S4->S5 with 'אני אפסס'")
    print(f"   Coach response:\n   {coach_msg[:200]}...")
    
    has_acknowledgment = "שמעתי את המחשבה" in coach_msg or "שמעתי את הרגש" in coach_msg
    status = "✅" if has_acknowledgment else "❌"
    print(f"\n   {status} Has vulnerable acknowledgment: {has_acknowledgment}")


async def test_s1_router():
    """Test 4: S1 router with 'goal achievement' topic."""
    print_section("TEST 4: S1 Router - Topic Classification")
    
    test_cases = [
        ("עמידה ביעדים", "he", "TOPIC_CLEAR"),
        ("achieving big goals", "en", "TOPIC_CLEAR"),
        ("להיות אבא טוב יותר", "he", "GOAL_NOT_TOPIC"),  # Goal, not topic
        ("הורות", "he", "TOO_BROAD"),  # Too broad
    ]
    
    for user_msg, lang, expected_intent in test_cases:
        result = await route_s1(user_message=user_msg, language=lang)
        
        print(f"\n🧪 TEST: '{user_msg}'")
        print(f"   Intent: {result.intent}")
        print(f"   Confidence: {result.confidence:.2f}")
        print(f"   Topic candidate: {result.topic_candidate}")
        print(f"   Rationale: {result.rationale}")
        
        status = "✅" if result.intent == expected_intent else "❌"
        print(f"   {status} Expected: {expected_intent}, Got: {result.intent}")


async def test_s5_two_turns():
    """Test 5: S5 two-turn stage (actual then desired)."""
    print_section("TEST 5: S5 Two-Turn Stage")
    
    # Turn 1: User gives actual action
    print("\n📍 Turn 1: User gives actual action")
    result1 = await decide(
        stage="S5",
        user_message="פשוט סגרתי את המחשב והלכתי",
        language="he",
        cognitive_data={}
    )
    
    print_result(
        "First turn (actual action)",
        {
            "intent": result1.intent,
            "decision": result1.decision,
            "extracted": result1.extracted,
            "missing": result1.missing
        }
    )
    
    has_actual = "action_actual" in result1.extracted
    wants_desired = "action_desired" in result1.missing
    status = "✅" if has_actual and wants_desired else "❌"
    print(f"   {status} Extracted actual: {has_actual}, Missing desired: {wants_desired}")
    
    # Turn 2: User gives desired state
    print("\n📍 Turn 2: User gives desired state")
    
    # Simulate state with actual already present
    cognitive_with_actual = {
        "event_actual": {
            "action_content": "פשוט סגרתי את המחשב והלכתי"
        }
    }
    
    result2 = await decide(
        stage="S5",
        user_message="הייתי רוצה לקחת נשימה עמוקה ולומר לעצמי שזה בסדר",
        language="he",
        cognitive_data=cognitive_with_actual
    )
    
    print_result(
        "Second turn (desired state)",
        {
            "intent": result2.intent,
            "decision": result2.decision,
            "extracted": result2.extracted,
            "missing": result2.missing
        }
    )
    
    has_desired = "action_desired" in result2.extracted
    should_advance = result2.decision == "advance"
    status = "✅" if has_desired and should_advance else "❌"
    print(f"   {status} Extracted desired: {has_desired}, Should advance: {should_advance}")


async def main():
    """Run all tests."""
    print("\n" + "🚀" * 35)
    print("  COACHING FLOW SIMULATOR - Testing Improvements")
    print("🚀" * 35)
    
    try:
        await test_meta_discussion()
        await test_s2_specificity()
        await test_vulnerable_moments()
        await test_s1_router()
        await test_s5_two_turns()
        
        print("\n" + "=" * 70)
        print("  ✅ All tests completed!")
        print("=" * 70 + "\n")
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)

