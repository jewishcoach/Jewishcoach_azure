"""
Test for Generic Critique system structure (no LLM calls)

Tests that the infrastructure is set up correctly without making actual LLM calls.
"""

from app.bsd.generic_critique import (
    CritiqueLabel, 
    RepairIntent, 
    GenericCritique,
    STAGE_REQUIREMENTS,
    get_stage_requirement
)
from app.bsd.router import get_generic_critique_detector
from app.bsd.reasoner import ReasonerDecision
from app.bsd.stage_defs import StageId


def test_enums():
    """Test that enums are properly defined"""
    print("="*70)
    print("🧪 Testing Enums")
    print("="*70)
    
    print("\n📋 CritiqueLabel values:")
    for label in CritiqueLabel:
        print(f"  ✓ {label.value}")
    
    print("\n📋 RepairIntent values:")
    for intent in RepairIntent:
        print(f"  ✓ {intent.value}")
    
    print("\n✅ Enums are properly defined")
    return True


def test_generic_critique_model():
    """Test GenericCritique model"""
    print("\n" + "="*70)
    print("🧪 Testing GenericCritique Model")
    print("="*70)
    
    # Create a sample critique
    critique = GenericCritique(
        label=CritiqueLabel.TOO_VAGUE,
        confidence=0.85,
        repair_intent=RepairIntent.ASK_EXAMPLE,
        reasoning="User answer is too vague"
    )
    
    print(f"\n✓ Created GenericCritique:")
    print(f"  Label: {critique.label.value}")
    print(f"  Confidence: {critique.confidence}")
    print(f"  Repair Intent: {critique.repair_intent.value}")
    print(f"  Reasoning: {critique.reasoning}")
    
    print("\n✅ GenericCritique model works correctly")
    return True


def test_reasoner_decision_fields():
    """Test that ReasonerDecision has new fields"""
    print("\n" + "="*70)
    print("🧪 Testing ReasonerDecision New Fields")
    print("="*70)
    
    # Create a ReasonerDecision with new fields
    decision = ReasonerDecision(
        intent="ANSWER_PARTIAL",
        decision="loop",
        next_stage=None,
        reasons=["Missing info"],
        extracted={},
        missing={"example": True},
        critique="PARTIAL",
        repair_intent="ask_example",
        generic_critique_label="too_vague",
        generic_critique_confidence=0.85
    )
    
    print(f"\n✓ Created ReasonerDecision with new fields:")
    print(f"  Intent: {decision.intent}")
    print(f"  Repair Intent: {decision.repair_intent}")
    print(f"  Generic Critique Label: {decision.generic_critique_label}")
    print(f"  Generic Critique Confidence: {decision.generic_critique_confidence}")
    
    print("\n✅ ReasonerDecision has all required fields")
    return True


def test_stage_requirements():
    """Test stage requirements mapping"""
    print("\n" + "="*70)
    print("🧪 Testing Stage Requirements")
    print("="*70)
    
    print("\n📋 Stage Requirements:")
    for stage in StageId:
        requirement = get_stage_requirement(stage)
        if requirement:
            print(f"  ✓ {stage.value}: {requirement}")
        else:
            print(f"  ⚠️  {stage.value}: (no requirement defined)")
    
    print("\n✅ Stage requirements are defined")
    return True


def test_integration_structure():
    """Test that all components are properly integrated"""
    print("\n" + "="*70)
    print("🧪 Testing Integration Structure")
    print("="*70)
    
    # Check that router has the detector function
    print("\n✓ Checking router integration:")
    print(f"  - get_generic_critique_detector function exists: ✓")
    
    # Check that we can import everything
    print("\n✓ All imports successful:")
    print(f"  - GenericCritique ✓")
    print(f"  - CritiqueLabel ✓")
    print(f"  - RepairIntent ✓")
    print(f"  - ReasonerDecision ✓")
    print(f"  - get_generic_critique_detector ✓")
    
    print("\n✅ Integration structure is correct")
    return True


def test_repair_intent_coverage():
    """Test that we have repair intents for common scenarios"""
    print("\n" + "="*70)
    print("🧪 Testing Repair Intent Coverage")
    print("="*70)
    
    required_intents = {
        "ask_example": "Need concrete example",
        "encourage_try": "User says 'don't know'",
        "ask_one_sentence": "Need single sentence/thought",
        "ask_more_emotions": "Need more emotions",
        "ask_specific_action": "Need concrete action",
        "ask_thought_not_action": "Clarify thought vs action",
        "ask_emotion_not_thought": "Clarify emotion vs thought",
        "refocus": "Bring back to topic",
        "none": "No repair needed"
    }
    
    print("\n📋 Repair Intents Coverage:")
    all_intent_values = {intent.value for intent in RepairIntent}
    
    for intent, description in required_intents.items():
        if intent in all_intent_values:
            print(f"  ✓ {intent}: {description}")
        else:
            print(f"  ❌ {intent}: MISSING - {description}")
    
    missing = set(required_intents.keys()) - all_intent_values
    if missing:
        print(f"\n⚠️  Missing intents: {missing}")
        return False
    else:
        print("\n✅ All required repair intents are defined")
        return True


def test_critique_label_coverage():
    """Test that we have critique labels for common issues"""
    print("\n" + "="*70)
    print("🧪 Testing Critique Label Coverage")
    print("="*70)
    
    required_labels = {
        "too_vague": "Answer is too vague",
        "too_general": "Answer is too general",
        "pattern": "User talks about patterns, not specifics",
        "judgment": "User judges instead of describes",
        "wrong_type": "Wrong type (emotion instead of thought, etc.)",
        "off_topic": "User is off topic",
        "avoidance": "User avoids answering",
        "ok": "Answer is appropriate"
    }
    
    print("\n📋 Critique Labels Coverage:")
    all_label_values = {label.value for label in CritiqueLabel}
    
    for label, description in required_labels.items():
        if label in all_label_values:
            print(f"  ✓ {label}: {description}")
        else:
            print(f"  ❌ {label}: MISSING - {description}")
    
    missing = set(required_labels.keys()) - all_label_values
    if missing:
        print(f"\n⚠️  Missing labels: {missing}")
        return False
    else:
        print("\n✅ All required critique labels are defined")
        return True


def main():
    """Run all structure tests"""
    
    print("\n")
    print("╔═══════════════════════════════════════════════════════════════════╗")
    print("║                                                                   ║")
    print("║     🧪 Generic Critique Structure Test Suite                    ║")
    print("║        (No LLM calls - structure only)                          ║")
    print("║                                                                   ║")
    print("╚═══════════════════════════════════════════════════════════════════╝")
    
    tests = [
        ("Enums", test_enums),
        ("GenericCritique Model", test_generic_critique_model),
        ("ReasonerDecision Fields", test_reasoner_decision_fields),
        ("Stage Requirements", test_stage_requirements),
        ("Integration Structure", test_integration_structure),
        ("Repair Intent Coverage", test_repair_intent_coverage),
        ("Critique Label Coverage", test_critique_label_coverage),
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            if test_func():
                passed += 1
            else:
                failed += 1
                print(f"\n❌ Test '{test_name}' failed")
        except Exception as e:
            failed += 1
            print(f"\n❌ Test '{test_name}' raised exception: {e}")
            import traceback
            traceback.print_exc()
    
    # Final Summary
    print("\n\n")
    print("╔═══════════════════════════════════════════════════════════════════╗")
    print("║                      📊 FINAL RESULTS                             ║")
    print("╚═══════════════════════════════════════════════════════════════════╝")
    print(f"\n  Total Tests Passed: {passed}/{passed+failed}")
    print(f"  Total Tests Failed: {failed}/{passed+failed}")
    
    if failed == 0:
        print(f"\n  🎉 ALL STRUCTURE TESTS PASSED! 🎉")
        print(f"\n  ✅ All enums are properly defined")
        print(f"  ✅ All models have correct fields")
        print(f"  ✅ Integration structure is correct")
        print(f"  ✅ All repair intents are covered")
        print(f"  ✅ All critique labels are covered")
        print(f"\n  💡 Next step: Test with actual LLM calls (requires Azure credentials)")
    else:
        print(f"\n  ⚠️  {failed} test(s) failed. Please review the output above.")
    
    print("\n" + "="*70 + "\n")
    
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    import sys
    exit_code = main()
    sys.exit(exit_code)

