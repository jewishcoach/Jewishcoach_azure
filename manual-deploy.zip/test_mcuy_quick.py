"""
Quick BSD Simulator - 5 Key Scenarios for Mcuy Stages
"""
import asyncio
import sys
sys.path.insert(0, '.')

from test_mcuy_simulator import ConversationSimulator, SCENARIOS
from datetime import datetime

async def main():
    print("\n" + "="*70)
    print("🎯 QUICK BSD SIMULATOR - 5 Key Scenarios")
    print("="*70)
    
    # Select diverse scenarios
    key_scenarios = [
        SCENARIOS[0],  # Regular user
        SCENARIOS[2],  # Doesn't understand emotions
        SCENARIOS[3],  # Gives goals instead of emotions
        SCENARIOS[5],  # Generic/vague answers
        SCENARIOS[9],  # Gives actions instead of thoughts
    ]
    
    simulator = ConversationSimulator()
    results = []
    
    for i, scenario in enumerate(key_scenarios, 1):
        print(f"\n{'#'*70}")
        print(f"# Running Scenario {i}/{len(key_scenarios)}")
        print(f"{'#'*70}")
        
        result = await simulator.run_scenario(scenario)
        results.append(result)
        await asyncio.sleep(0.2)
    
    simulator.close()
    
    # SUMMARY REPORT
    print(f"\n\n{'='*70}")
    print(f"📊 SUMMARY REPORT")
    print(f"{'='*70}\n")
    
    for i, result in enumerate(results, 1):
        status = "✅" if result["success"] else "⚠️ "
        print(f"{status} {i}. {result['scenario']}")
        print(f"   Final Stage: {result['final_stage']}")
        print(f"   Total Turns: {len(result['turns'])}")
        print(f"   Issues: {len(result['issues'])}")
        
        if result['issues']:
            print(f"   Problems:")
            for issue_data in result['issues'][:2]:
                print(f"      - Turn {issue_data['turn']}: {issue_data['issue'][:80]}")
        print()
    
    # Overall stats
    total = len(results)
    successful = sum(1 for r in results if r["success"])
    total_issues = sum(len(r["issues"]) for r in results)
    
    print(f"{'='*70}")
    print(f"Overall: {successful}/{total} scenarios successful")
    print(f"Total issues found: {total_issues}")
    print(f"{'='*70}\n")
    
    # Key findings
    print("🔍 Key Findings:\n")
    
    findings = []
    
    # Check S3 emotion validation
    s3_issues = sum(1 for r in results for issue in r['issues'] if 'S3:' in issue['issue'])
    if s3_issues > 0:
        findings.append(f"- S3 emotion validation needs attention ({s3_issues} issues)")
    else:
        findings.append("- ✅ S3 emotion validation working well")
    
    # Check S4 thought validation
    s4_issues = sum(1 for r in results for issue in r['issues'] if 'S4:' in issue['issue'])
    if s4_issues > 0:
        findings.append(f"- S4 thought validation needs attention ({s4_issues} issues)")
    else:
        findings.append("- ✅ S4 thought validation working well")
    
    # Check stage advancement
    advancement_issues = sum(1 for r in results for issue in r['issues'] if 'Advanced' in issue['issue'] or 'ANSWER_OK' in issue['issue'])
    if advancement_issues > 0:
        findings.append(f"- Stage advancement logic has issues ({advancement_issues} cases)")
    else:
        findings.append("- ✅ Stage advancement logic working correctly")
    
    # Check correction handling
    correction_issues = sum(1 for r in results for issue in r['issues'] if 'correction' in issue['issue'].lower())
    if correction_issues > 0:
        findings.append(f"- User corrections not always acknowledged ({correction_issues} cases)")
    else:
        findings.append("- ✅ User corrections handled well")
    
    for finding in findings:
        print(finding)
    
    print(f"\n{'='*70}")
    print(f"Completed: {datetime.now().strftime('%H:%M:%S')}")
    print(f"{'='*70}\n")

if __name__ == "__main__":
    asyncio.run(main())

