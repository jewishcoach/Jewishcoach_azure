"""
סימולציה מהירה של V2 עם progress tracking
==========================================
"""

import os
import sys
import json
import time
from pathlib import Path

# Setup Azure OpenAI credentials
os.environ["AZURE_OPENAI_API_KEY"] = "2jy7NXTiqGiD2jz0BWMPEWkrS4MO2JmO1sKmsCv0NTlQ9z0Hd6tZJQQJ99CAACYeBjFXJ3w3AAABACOGX9Sf"
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://eastus.api.cognitive.microsoft.com/"
os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = "gpt-4o"
os.environ["AZURE_OPENAI_API_VERSION"] = "2024-08-01-preview"

# Add backend to path
backend_dir = Path(__file__).parent
sys.path.insert(0, str(backend_dir))

print("🔧 Importing modules...", flush=True)
from app.bsd_v2.single_agent_coach import handle_conversation
from app.bsd_v2.state_schema_v2 import create_initial_state
print("✅ Modules imported!", flush=True)

def simulate_conversation():
    """סימולציה מהירה עם tracking"""
    
    print("\n" + "=" * 80, flush=True)
    print("🧪 BSD V2 - Fast Simulation", flush=True)
    print("=" * 80, flush=True)
    
    # Initialize state
    print("\n📝 Creating initial state...", flush=True)
    state = create_initial_state(
        conversation_id="test_fast",
        user_id="test_user"
    )
    print(f"✅ State created: {state['current_step']}", flush=True)
    
    # Conversation flow
    turns = [
        ("זוגיות זה נושא טוב?", "S1: שאלת מיקוד"),
        ("אני לא מרגיש מחובר לאשתי", "S1: הבהרה"),
        ("על החיבור הזוגי", "S1→S2: אירוע"),
        ("אתמול בערב ישבנו ביחד והיא ניסתה לספר לי על היום שלה ואני הייתי בטלפון", "S2→S3: רגשות"),
        ("הרגשתי אשם", "S3: מה עוד? (1/4)"),
        ("גם תסכול", "S3: מה עוד? (2/4)"),
        ("כעס על עצמי", "S3: מה עוד? (3/4)"),
        ("עצב", "S3→S4: מחשבה (4/4 ✅)"),
        ("חשבתי שאני בעל לא טוב", "S4→S5: מעשה"),
        ("המשכתי לגלול בטלפון", "S5: רצוי"),
    ]
    
    # Run conversation
    import asyncio
    
    for i, (user_msg, expected) in enumerate(turns, 1):
        print("\n" + "━" * 80, flush=True)
        print(f"Turn {i}", flush=True)
        print("━" * 80, flush=True)
        print(f"👤 User: {user_msg}", flush=True)
        print(f"📋 Expected: {expected}", flush=True)
        print(f"⏳ Calling LLM...", flush=True)
        
        start = time.time()
        
        try:
            # Get coach response
            coach_message, updated_state = asyncio.run(
                handle_conversation(
                    user_message=user_msg,
                    state=state,
                    language="he"
                )
            )
            
            elapsed = time.time() - start
            print(f"✅ LLM responded in {elapsed:.1f}s", flush=True)
            
            # Update state
            state = updated_state
            
            # Print response
            print(f"\n🤖 Coach:", flush=True)
            print(f"   {coach_message}", flush=True)
            
            # Print state
            print(f"\n📊 State:", flush=True)
            print(f"   Stage: {state['current_step']}", flush=True)
            print(f"   Saturation: {state['saturation_score']:.2f}", flush=True)
            
            # Print emotions if in S3/S4
            emotions = state['collected_data'].get('emotions', [])
            if emotions:
                print(f"   Emotions: {emotions} ({len(emotions)}/4)", flush=True)
            
            # Print thought if in S4/S5
            thought = state['collected_data'].get('thought')
            if thought:
                print(f"   Thought: {thought}", flush=True)
            
            # Validation
            if i == 7:  # After 3rd emotion
                if len(emotions) != 3:
                    print(f"   ⚠️  Expected 3 emotions, got {len(emotions)}", flush=True)
                if state['current_step'] != 'S3':
                    print(f"   ⚠️  Should still be in S3, but in {state['current_step']}", flush=True)
            
            if i == 8:  # After 4th emotion
                if len(emotions) != 4:
                    print(f"   ⚠️  Expected 4 emotions, got {len(emotions)}", flush=True)
                if state['current_step'] not in ['S3', 'S4']:
                    print(f"   ⚠️  Should transition to S4, but in {state['current_step']}", flush=True)
                    
        except Exception as e:
            elapsed = time.time() - start
            print(f"❌ Error after {elapsed:.1f}s: {e}", flush=True)
            import traceback
            traceback.print_exc()
            break
    
    print("\n" + "=" * 80, flush=True)
    print("✅ Simulation Complete", flush=True)
    print("=" * 80, flush=True)
    
    # Summary
    print("\n📊 Final Summary:", flush=True)
    print(f"   Stage: {state['current_step']}", flush=True)
    print(f"   Emotions collected: {len(state['collected_data'].get('emotions', []))}", flush=True)
    print(f"   Saturation: {state['saturation_score']:.2f}", flush=True)

if __name__ == "__main__":
    print("🚀 Starting simulation...", flush=True)
    simulate_conversation()
    print("🏁 Done!", flush=True)
