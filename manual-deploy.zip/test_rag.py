#!/usr/bin/env python3
"""
Quick test for RAG service integration

Tests:
1. RAG service initialization
2. Methodology question detection
3. Answer generation (if Azure Search configured)
"""

import asyncio
import sys
import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent))

from app.bsd.router import _is_methodology_question, _detect_clarification
from app.bsd.knowledge_rag import get_rag_service


async def main():
    print("=" * 80)
    print("BSD RAG Service - Quick Test")
    print("=" * 80)
    print()
    
    # Test 1: Methodology question detection
    print("📋 Test 1: Methodology Question Detection")
    print("-" * 80)
    
    test_cases = [
        ("מה זה תהליך השיבה?", True, "About Shiva process"),
        ("מי יסד את השיטה?", True, "About founder"),
        ("מה זה הפער?", True, "About the gap"),
        ("למה אתה שואל את זה?", False, "About current process"),
        ("מה אתה רוצה ממני?", False, "About current task"),
        ("איך עובד המסך הרגשי?", True, "About emotion screen"),
    ]
    
    for text, expected, desc in test_cases:
        is_clarify = _detect_clarification(text, "he")
        is_methodology = _is_methodology_question(text, "he")
        
        status = "✅" if (is_clarify and is_methodology == expected) else "❌"
        print(f"{status} '{text}'")
        print(f"   Description: {desc}")
        print(f"   CLARIFY: {is_clarify}, METHODOLOGY: {is_methodology} (expected: {expected})")
        print()
    
    # Test 2: RAG Service Availability
    print()
    print("📋 Test 2: RAG Service Availability")
    print("-" * 80)
    
    # Force reload singleton to pick up latest env vars
    import app.bsd.knowledge_rag as rag_module
    rag_module._rag_service = None
    
    rag_service = get_rag_service()
    
    if rag_service.is_available:
        print("✅ RAG service is available!")
        print(f"   Search endpoint: {rag_service.search_endpoint}")
        print(f"   Index name: {rag_service.index_name}")
        print()
        
        # Test 3: Try answering a question
        print("📋 Test 3: Answer Generation")
        print("-" * 80)
        
        test_question = "מה זה תהליך השיבה?"
        print(f"Question: {test_question}")
        print()
        
        try:
            answer = await rag_service.answer_question(test_question, "he")
            
            if answer:
                print("✅ RAG answer generated:")
                print()
                print(answer)
                print()
            else:
                print("⚠️  No answer found (no relevant context in index)")
                print()
        
        except Exception as e:
            print(f"❌ Error generating answer: {e}")
            print()
    
    else:
        print("⚠️  RAG service is NOT available")
        print()
        print("Possible reasons:")
        print("- Azure Search credentials not configured in .env")
        print("- Index not created yet")
        print()
        print("To enable RAG:")
        print("1. Set up Azure AI Search (see AZURE_SEARCH_SETUP.md)")
        print("2. Add credentials to .env:")
        print("   AZURE_SEARCH_SERVICE_ENDPOINT=...")
        print("   AZURE_SEARCH_INDEX_NAME=...")
        print("   AZURE_SEARCH_ADMIN_KEY=...")
        print("3. Run: python upload_to_azure.py")
        print()
    
    print("=" * 80)
    print("Test Complete!")
    print("=" * 80)


if __name__ == "__main__":
    asyncio.run(main())

