"""
סימולציה מתקדמת של V2 - S5→S6→S7
===================================

בודק:
- S5: סיכום המצוי
- S6: שם לפער + ציון
- S7: דפוס חוזר
"""

import os
import sys
import time
from pathlib import Path

# Setup Azure OpenAI credentials
os.environ["AZURE_OPENAI_API_KEY"] = "2jy7NXTiqGiD2jz0BWMPEWkrS4MO2JmO1sKmsCv0NTlQ9z0Hd6tZJQQJ99CAACYeBjFXJ3w3AAABACOGX9Sf"
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://eastus.api.cognitive.microsoft.com/"
os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = "gpt-4o"
os.environ["AZURE_OPENAI_API_VERSION"] = "2024-08-01-preview"

backend_dir = Path(__file__).parent
sys.path.insert(0, str(backend_dir))

print("🔧 Importing...", flush=True)
from app.bsd_v2.single_agent_coach import handle_conversation
from app.bsd_v2.state_schema_v2 import create_initial_state
print("✅ Ready!", flush=True)

def simulate_advanced():
    print("\n" + "=" * 80, flush=True)
    print("🧪 BSD V2 - Advanced Simulation (S5→S6→S7)", flush=True)
    print("=" * 80, flush=True)
    
    # Pre-fill state with S4 data
    state = create_initial_state("test_adv", "test_user")
    state["current_step"] = "S5"
    state["collected_data"]["topic"] = "חוסר חיבור בזוגיות"
    state["collected_data"]["event"] = "אתמול בערב ישבנו ביחד והיא ניסתה לספר לי על היום שלה ואני הייתי בטלפון"
    state["collected_data"]["emotions"] = ["אשם", "תסכול", "כעס", "עצב"]
    state["collected_data"]["thought"] = "אני בעל לא טוב"
    state["saturation_score"] = 0.4
    
    turns = [
        ("המשכתי לגלול בטלפון וענייתי לה בקיצור", "S5: רצוי"),
        ("הייתי רוצה להניח את הטלפון ולהקשיב לה באמת", "S5: סיכום המצוי (event+emotions+thought+action)"),
        ("כן, זה נכון", "S5→S6: שם לפער"),
        ("הפער בין כוונה למעשה", "S6: ציון 1-10"),
        ("8", "S6→S7: דפוס חוזר"),
        ("כן, זה קורה לי גם בעבודה ועם החברים", "S7: המשך"),
    ]
    
    import asyncio
    
    for i, (user_msg, expected) in enumerate(turns, 1):
        print(f"\n{'━' * 80}", flush=True)
        print(f"Turn {i}", flush=True)
        print(f"{'━' * 80}", flush=True)
        print(f"👤 User: {user_msg}", flush=True)
        print(f"📋 Expected: {expected}", flush=True)
        print(f"⏳ Calling LLM...", flush=True)
        
        start = time.time()
        
        try:
            coach_message, updated_state = asyncio.run(
                handle_conversation(
                    user_message=user_msg,
                    state=state,
                    language="he"
                )
            )
            
            elapsed = time.time() - start
            print(f"✅ LLM responded in {elapsed:.1f}s", flush=True)
            
            state = updated_state
            
            print(f"\n🤖 Coach:", flush=True)
            print(f"   {coach_message}", flush=True)
            
            print(f"\n📊 State:", flush=True)
            print(f"   Stage: {state['current_step']}", flush=True)
            print(f"   Saturation: {state['saturation_score']:.2f}", flush=True)
            
            # Check specific fields
            if state['collected_data'].get('action_actual'):
                print(f"   Action (actual): {state['collected_data']['action_actual']}", flush=True)
            if state['collected_data'].get('action_desired'):
                print(f"   Action (desired): {state['collected_data']['action_desired']}", flush=True)
            if state['collected_data'].get('gap_name'):
                print(f"   Gap name: {state['collected_data']['gap_name']}", flush=True)
            if state['collected_data'].get('gap_score'):
                print(f"   Gap score: {state['collected_data']['gap_score']}", flush=True)
            
            # Validation
            if i == 2:  # After action_desired
                if not state['collected_data'].get('action_desired'):
                    print(f"   ⚠️  Expected action_desired to be filled", flush=True)
                if "סיכום" not in coach_message.lower() and "תמונה" not in coach_message.lower():
                    print(f"   ⚠️  Expected summary of Mitzui (event+emotions+thought+action)", flush=True)
            
            if i == 3:  # After confirmation
                if state['current_step'] not in ['S5', 'S6']:
                    print(f"   ⚠️  Should transition to S6", flush=True)
                    
        except Exception as e:
            elapsed = time.time() - start
            print(f"❌ Error after {elapsed:.1f}s: {e}", flush=True)
            import traceback
            traceback.print_exc()
            break
    
    print("\n" + "=" * 80, flush=True)
    print("✅ Simulation Complete", flush=True)
    print("=" * 80, flush=True)
    
    print("\n📊 Final Summary:", flush=True)
    print(f"   Stage: {state['current_step']}", flush=True)
    print(f"   Gap name: {state['collected_data'].get('gap_name', 'N/A')}", flush=True)
    print(f"   Gap score: {state['collected_data'].get('gap_score', 'N/A')}", flush=True)
    print(f"   Saturation: {state['saturation_score']:.2f}", flush=True)

if __name__ == "__main__":
    print("🚀 Starting advanced simulation...", flush=True)
    simulate_advanced()
    print("🏁 Done!", flush=True)
