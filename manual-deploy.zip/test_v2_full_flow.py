"""
סימולציה מלאה של V2 - בדיקת כל השלבים
===========================================

בודק:
- S1: פריקה ושאלת מיקוד
- S2: איסוף אירוע ספציפי
- S3: איסוף 4 רגשות (אחד אחד!)
- S4: משפט מחשבה מילולי
- S5: מעשה בפועל + רצוי + סיכום מצוי
- S6: שם לפער + ציון
"""

import os
import sys
import json
from pathlib import Path

# Setup Azure OpenAI credentials
print("\n🔑 Setting up Azure OpenAI credentials...")
os.environ["AZURE_OPENAI_API_KEY"] = "2jy7NXTiqGiD2jz0BWMPEWkrS4MO2JmO1sKmsCv0NTlQ9z0Hd6tZJQQJ99CAACYeBjFXJ3w3AAABACOGX9Sf"
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://eastus.api.cognitive.microsoft.com/"
os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = "gpt-4o"
os.environ["AZURE_OPENAI_API_VERSION"] = "2024-08-01-preview"

# Add backend to path
backend_dir = Path(__file__).parent
sys.path.insert(0, str(backend_dir))

from app.bsd_v2.single_agent_coach import handle_conversation
from app.bsd_v2.state_schema_v2 import create_initial_state, add_message

def print_separator():
    print("\n" + "━" * 80)

def simulate_full_conversation():
    """סימולציה של שיחה מלאה S1→S6"""
    
    print("\n" + "=" * 80)
    print("🧪 BSD V2 - Full Flow Simulation (S1→S6)")
    print("=" * 80)
    
    # Initialize state
    state = create_initial_state(
        conversation_id="test_full_flow",
        user_id="test_user"
    )
    
    # Conversation flow
    conversation_flow = [
        # S1: Topic
        {
            "user_msg": "זוגיות זה נושא טוב?",
            "expected_stage": "S1",
            "check": "שאלת מיקוד (לא 'ספר על רגע')"
        },
        {
            "user_msg": "אני לא מרגיש מחובר לאשתי",
            "expected_stage": "S1",
            "check": "שאלת הבהרה (על מה תרצה להתאמן?)"
        },
        {
            "user_msg": "על החיבור הזוגי",
            "expected_stage": "S1→S2",
            "check": "מעבר ל-S2: בקשה לאירוע ספציפי"
        },
        
        # S2: Event
        {
            "user_msg": "אתמול בערב ישבנו ביחד והיא ניסתה לספר לי על היום שלה ואני הייתי בטלפון",
            "expected_stage": "S2→S3",
            "check": "מעבר ל-S3: שאלה על רגשות"
        },
        
        # S3: Emotions (אחד אחד! צריך 4 רגשות!)
        {
            "user_msg": "הרגשתי אשם",
            "expected_stage": "S3",
            "check": "שואל 'מה עוד?' (לא עובר ל-S4!)"
        },
        {
            "user_msg": "גם תסכול",
            "expected_stage": "S3",
            "check": "שואל 'מה עוד?' שוב (2/4 רגשות)"
        },
        {
            "user_msg": "כעס על עצמי",
            "expected_stage": "S3",
            "check": "שואל 'מה עוד?' פעם שלישית (3/4 רגשות) - 🛑 לא עובר ל-S4!"
        },
        {
            "user_msg": "עצב",
            "expected_stage": "S3→S4",
            "check": "4 רגשות! ✅ עכשיו מעבר ל-S4: שאלה על מחשבה"
        },
        
        # S4: Thought
        {
            "user_msg": "חשבתי שאני בעל לא טוב",
            "expected_stage": "S4→S5",
            "check": "מעבר ל-S5: שאלה על מעשה בפועל"
        },
        
        # S5: Action (actual + desired + summary!)
        {
            "user_msg": "המשכתי לגלול בטלפון וענייתי לה בקיצור",
            "expected_stage": "S5",
            "check": "שואל על מעשה רצוי"
        },
        {
            "user_msg": "הייתי רוצה להניח את הטלפון ולהקשיב לה באמת",
            "expected_stage": "S5",
            "check": "🛑 סיכום המצוי המלא לפני מעבר ל-S6 (event+emotions+thought+action)"
        },
        {
            "user_msg": "כן, זה נכון",
            "expected_stage": "S5→S6",
            "check": "✅ אישור סיכום → מעבר ל-S6: שאלה על שם לפער"
        },
        
        # S6: Gap naming + score
        {
            "user_msg": "אקרא לזה 'הפער בין כוונה למעשה'",
            "expected_stage": "S6",
            "check": "קיבל שם לפער → שואל על ציון 1-10"
        },
        {
            "user_msg": "8",
            "expected_stage": "S6→S7",
            "check": "קיבל ציון → מעבר ל-S7: שאלה על דפוס חוזר"
        },
    ]
    
    # Run conversation
    for i, turn in enumerate(conversation_flow, 1):
        print_separator()
        print(f"Turn {i}")
        print_separator()
        print(f"👤 User: {turn['user_msg']}")
        print(f"📋 Expected: {turn['check']}")
        
        # Get coach response (async function needs to be awaited)
        import asyncio
        coach_message, updated_state = asyncio.run(
            handle_conversation(
                user_message=turn['user_msg'],
                state=state,
                language="he"
            )
        )
        
        # Update state
        state = updated_state
        
        # Print response
        print(f"\n🤖 Coach (V2):")
        print(f"   {coach_message}")
        
        # Print internal state
        print(f"\n📊 Internal State:")
        print(f"   Stage: {state['current_step']}")
        print(f"   Saturation: {state['saturation_score']:.2f}")
        
        if state['collected_data']:
            non_empty_data = {k: v for k, v in state['collected_data'].items() if v is not None and v != [] and v != {}}
            if non_empty_data:
                print(f"   Collected Data: {json.dumps(non_empty_data, ensure_ascii=False, indent=2)}")
    
    print("\n" + "=" * 80)
    print("✅ Simulation Complete")
    print("=" * 80)
    
    print("\n📝 Analysis:")
    print("   - Check if S3 collected 4 emotions one by one (not as a list)")
    print("   - Check if S5 summarized the full 'Mitzui' before moving to S6")
    print("   - Check if gates were enforced (no premature transitions)")
    print("   - Check if language is natural and empathetic")

if __name__ == "__main__":
    simulate_full_conversation()
