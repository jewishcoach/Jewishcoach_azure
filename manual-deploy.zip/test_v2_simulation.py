#!/usr/bin/env python3
"""
Simulate conversation with BSD V2 Single-Agent Coach

Test the natural conversation flow with Shehiya (staying power) principles.
"""

import asyncio
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.bsd_v2.single_agent_coach import handle_conversation
from app.bsd_v2.state_schema_v2 import create_initial_state


async def simulate_conversation():
    """
    Simulate a full conversation testing V2's natural flow.
    
    Scenario:
    1. User: "זוגיות זה נושא טוב?"
    2. Coach should ask focus question (not jump to event!)
    3. User: "אני לא מרגיש מחובר לאשתי..."
    4. Coach should clarify topic, not jump to event
    5. Test natural flow vs. V1's rigid gates
    """
    
    print("\n" + "="*80)
    print("🧪 BSD V2 - Single-Agent Conversational Coach Simulation")
    print("="*80)
    print("\nTesting: Natural conversation vs. rigid gates")
    print("Philosophy: Trust the LLM + Shehiya (staying power)\n")
    
    # Create initial state
    state = create_initial_state(
        conversation_id="sim_001",
        user_id="test_user",
        language="he"
    )
    
    # Conversation turns
    turns = [
        ("זוגיות זה נושא טוב?", "Expected: Focus question, not 'tell me about a moment'"),
        ("אני לא מרגיש מחובר לאשתי, היא גם מרגישה את זה, היא טוענת שאני לא מתיחס אליה כמו שצריך", 
         "Expected: Clarify the topic, not jump to event or explain methodology"),
        ("על החיבור הזוגי", "Expected: Accept topic, explain process, ask for event"),
    ]
    
    for turn_num, (user_msg, expected) in enumerate(turns, 1):
        print(f"{'━'*80}")
        print(f"Turn {turn_num}")
        print(f"{'━'*80}")
        print(f"👤 User: {user_msg}")
        print(f"📋 Expected: {expected}")
        print()
        
        try:
            # Call V2 handler
            coach_msg, state = await handle_conversation(
                user_message=user_msg,
                state=state,
                language="he"
            )
            
            print(f"🤖 Coach (V2):")
            print(f"   {coach_msg}")
            print()
            print(f"📊 Internal State:")
            print(f"   Stage: {state['current_step']}")
            print(f"   Saturation: {state['saturation_score']:.2f}")
            if state['collected_data']['topic']:
                print(f"   Topic: {state['collected_data']['topic']}")
            print()
            
        except Exception as e:
            print(f"❌ ERROR: {e}")
            import traceback
            traceback.print_exc()
            break
    
    print("="*80)
    print("✅ Simulation Complete")
    print("="*80)
    print("\n📝 Analysis:")
    print("   - Check if coach asks focus questions naturally")
    print("   - Check if coach doesn't jump to 'tell me about a moment' too early")
    print("   - Check if coach clarifies topic before explaining methodology")
    print("   - Compare to V1's rigid: 'זה תחום רחב!' or 'ספר על רגע ספציפי'")


if __name__ == "__main__":
    print("\n🔑 Setting up Azure OpenAI credentials...")
    os.environ['AZURE_OPENAI_API_KEY'] = "2jy7NXTiqGiD2jz0BWMPEWkrS4MO2JmO1sKmsCv0NTlQ9z0Hd6tZJQQJ99CAACYeBjFXJ3w3AAABACOGX9Sf"
    os.environ['AZURE_OPENAI_ENDPOINT'] = "https://eastus.api.cognitive.microsoft.com/"
    
    asyncio.run(simulate_conversation())
