#!/usr/bin/env python3
"""
Test S3→S4 Transition: Emotion Depth Check
==========================================

This script simulates a conversation to check if the coach properly
explores emotions in S3 before moving to S4 (thoughts).

Expected behavior:
- Coach should NOT accept just names of emotions
- Should explore each emotion: "ספר לי יותר על ה-X", "איפה הרגשת את ה-X?"
- Should collect 3-4 emotions with depth (not just a list!)
- Should NOT move to S4 until emotions are explored in depth
"""

import asyncio
import json
import sys
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent))

from app.bsd_v2.single_agent_coach import handle_conversation
from app.bsd_v2.state_schema_v2 import create_initial_state


def print_turn(turn_num: int, user_msg: str, coach_msg: str, step: str, saturation: float):
    """Pretty print a conversation turn"""
    print(f"\n{'='*80}")
    print(f"Turn {turn_num} | Step: {step} | Saturation: {saturation:.2f}")
    print(f"{'='*80}")
    print(f"💬 משתמש: {user_msg}")
    print(f"🎓 מאמן: {coach_msg}")


async def test_s3_depth():
    """Test S3 depth - should explore each emotion, not just collect names"""
    
    print("\n" + "="*80)
    print("🧪 TEST: S3→S4 Transition (Emotion Depth)")
    print("="*80)
    print("Goal: Coach should explore each emotion in depth, not just collect names")
    print()
    
    # Initialize state and fast-forward to S3
    state = create_initial_state(
        conversation_id="test_s3_depth",
        user_id="test_user",
        language="he"
    )
    
    # Fast-forward through S1 and S2
    print("🚀 Fast-forwarding to S3...")
    
    # S1
    _, state = await handle_conversation("זוגיות", state, "he")
    _, state = await handle_conversation("להיות יותר רגיש", state, "he")
    
    # S2 - give detailed event
    _, state = await handle_conversation("ביום שישי חזרתי הביתה ולא הבאתי פרחים", state, "he")
    _, state = await handle_conversation("בכניסה לבית, היא חיכתה לי בסלון", state, "he")
    _, state = await handle_conversation("ראיתי את המבט שלה, היא שאלה 'הכל בסדר?'", state, "he")
    
    print(f"\n✓ Current step: {state['current_step']}")
    print(f"✓ Ready to test S3")
    
    # Now we're in S3 (or about to be)
    # Test shallow emotion collection (BAD)
    print("\n" + "="*80)
    print("🧪 TEST SCENARIO 1: Shallow emotion collection (should be blocked!)")
    print("="*80)
    
    turn_num = 1
    
    # Coach asks: "מה הרגשת?"
    # Test if coach accepts shallow answers
    
    # Turn 1: First emotion
    user_msg = "הרגשתי עצוב"
    coach_msg, state = await handle_conversation(user_msg, state, "he")
    print_turn(turn_num, user_msg, coach_msg, state["current_step"], state["saturation_score"])
    turn_num += 1
    
    # Check: Did coach explore "עצוב" or just ask "מה עוד?"
    if "ספר לי" in coach_msg or "איפה" in coach_msg:
        print("\n✅ GOOD: Coach is exploring the emotion 'עצוב'")
        
        # Provide depth
        user_msg = "זה עצב כבד, בחזה"
        coach_msg, state = await handle_conversation(user_msg, state, "he")
        print_turn(turn_num, user_msg, coach_msg, state["current_step"], state["saturation_score"])
        turn_num += 1
    else:
        print("\n⚠️  WARNING: Coach didn't explore 'עצוב' - asked 'מה עוד?' too fast")
    
    # Turn 2: Second emotion
    user_msg = "גם מפוקס"
    coach_msg, state = await handle_conversation(user_msg, state, "he")
    print_turn(turn_num, user_msg, coach_msg, state["current_step"], state["saturation_score"])
    turn_num += 1
    
    # Check: Did coach explore "מפוקס"?
    if "ספר לי" in coach_msg or "איפה" in coach_msg or "מפוקס" in coach_msg:
        print("\n✅ GOOD: Coach is exploring the emotion 'מפוקס'")
        
        # Provide depth
        user_msg = "בראש, לא יכולתי לחשוב"
        coach_msg, state = await handle_conversation(user_msg, state, "he")
        print_turn(turn_num, user_msg, coach_msg, state["current_step"], state["saturation_score"])
        turn_num += 1
    else:
        print("\n⚠️  WARNING: Coach didn't explore 'מפוקס'")
    
    # Turn 3: Third emotion
    user_msg = "גם כעס על עצמי"
    coach_msg, state = await handle_conversation(user_msg, state, "he")
    print_turn(turn_num, user_msg, coach_msg, state["current_step"], state["saturation_score"])
    turn_num += 1
    
    # Check: Did coach explore "כעס"?
    if "ספר לי" in coach_msg or "איפה" in coach_msg or "כעס" in coach_msg:
        print("\n✅ GOOD: Coach is exploring the emotion 'כעס'")
        
        # Provide depth
        user_msg = "כעס שאני שוב לא זוכר דברים חשובים"
        coach_msg, state = await handle_conversation(user_msg, state, "he")
        print_turn(turn_num, user_msg, coach_msg, state["current_step"], state["saturation_score"])
        turn_num += 1
    else:
        print("\n⚠️  WARNING: Coach didn't explore 'כעס'")
    
    # Turn 4: Fourth emotion
    user_msg = "גם אשמה"
    coach_msg, state = await handle_conversation(user_msg, state, "he")
    print_turn(turn_num, user_msg, coach_msg, state["current_step"], state["saturation_score"])
    turn_num += 1
    
    # Check: Did coach explore "אשמה"?
    if "ספר לי" in coach_msg or "איפה" in coach_msg or "אשמה" in coach_msg:
        print("\n✅ GOOD: Coach is exploring the emotion 'אשמה'")
        
        # Provide depth
        user_msg = "אשמה כבדה שאני פוגע בה"
        coach_msg, state = await handle_conversation(user_msg, state, "he")
        print_turn(turn_num, user_msg, coach_msg, state["current_step"], state["saturation_score"])
        turn_num += 1
    else:
        print("\n⚠️  WARNING: Coach didn't explore 'אשמה'")
    
    # Now check: Are we still in S3 or did we move to S4?
    user_msg = "לא, זה מה שהיה"
    coach_msg, state = await handle_conversation(user_msg, state, "he")
    print_turn(turn_num, user_msg, coach_msg, state["current_step"], state["saturation_score"])
    
    if state["current_step"] == "S4" or "מה עבר לך בראש" in coach_msg or "מה חשבת" in coach_msg:
        print("\n✅ PASS: Coach explored emotions in depth (8-10 exchanges) before moving to S4!")
        print(f"   Total turns in test: {turn_num}")
        return True
    else:
        print(f"\n⚠️  WARNING: Still in {state['current_step']}, not moved to S4 yet")
        print("   This might be okay - coach is being extra careful")
        return True


async def main():
    """Run the test"""
    try:
        success = await test_s3_depth()
        
        print("\n" + "="*80)
        if success:
            print("✅ TEST PASSED: S3 depth is properly validated")
        else:
            print("❌ TEST FAILED: Coach moves to thoughts too quickly")
        print("="*80)
        
        sys.exit(0 if success else 1)
        
    except Exception as e:
        print(f"\n❌ Error running test: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
