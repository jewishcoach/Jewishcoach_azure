#!/usr/bin/env python3
"""
Test stage-specific context injection
"""

import asyncio
from dotenv import load_dotenv
from app.bsd.stage_context_builder import build_stage_context
from app.bsd.stage_defs import StageId

load_dotenv()

async def main():
    print("=" * 80)
    print("בדיקת Stage-Specific Context Injection")
    print("=" * 80)
    print()
    
    # Test a few key stages
    test_stages = [
        StageId.S1,   # Topic
        StageId.S3,   # Emotions
        StageId.S8,   # Stance (Profit & Loss)
    ]
    
    for stage in test_stages:
        print(f"\n{'='*80}")
        print(f"🔍 Testing Stage: {stage.value}")
        print(f"{'='*80}\n")
        
        try:
            context = await build_stage_context(stage, "he")
            
            if context:
                print("✅ Context generated:")
                print(context)
            else:
                print("⚠️  No context generated (might be normal if RAG is empty)")
        
        except Exception as e:
            print(f"❌ Error: {e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "=" * 80)
    print("✅ Test Complete!")
    print("=" * 80)

if __name__ == "__main__":
    asyncio.run(main())

