from __future__ import annotations

import os
from functools import lru_cache

from langchain_openai import AzureChatOpenAI

"""
LLM configuration for BSD coaching system.

Supports both Azure OpenAI and Google Gemini.
Enterprise-grade: Timeouts, retries, and purpose-specific temperature tuning.
"""


# Temperature mapping per purpose
TEMPERATURE_MAP = {
    "reasoner": 0.1,   # Colder for logical validation (deterministic)
    "talker": 0.35,    # Warmer for empathetic, varied responses (was 0.25)
    "judge": 0.15,     # Cold for quality evaluation
}


@lru_cache(maxsize=8)
def get_azure_chat_llm(*, purpose: str) -> AzureChatOpenAI:
    """
    Get an Azure OpenAI LLM client configured for a specific purpose.
    
    Args:
        purpose: One of "reasoner", "talker", "judge"
    
    Returns:
        Configured AzureChatOpenAI instance
    
    Raises:
        RuntimeError: If Azure OpenAI credentials are missing
    
    Environment Variables:
        Required:
        - AZURE_OPENAI_API_KEY: Azure OpenAI API key
        - AZURE_OPENAI_ENDPOINT: Azure endpoint URL
        
        Optional:
        - AZURE_OPENAI_API_VERSION: API version (default: 2024-08-01-preview)
        - AZURE_OPENAI_DEPLOYMENT_NAME: Default deployment (default: gpt-4o)
        - AZURE_OPENAI_DEPLOYMENT_NAME_REASONER: Override for reasoner
        - AZURE_OPENAI_DEPLOYMENT_NAME_TALKER: Override for talker
        - AZURE_OPENAI_DEPLOYMENT_NAME_JUDGE: Override for judge
    
    Temperature Settings:
        - reasoner: 0.1 (deterministic, logical)
        - talker: 0.35 (creative, empathetic, varied)
        - judge: 0.15 (consistent evaluation)
    
    Examples:
        >>> llm = get_azure_chat_llm(purpose="talker")
        >>> llm.temperature
        0.35
    """
    # Load configuration
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION", "2024-08-01-preview")
    default_deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")

    # Validate required config
    if not api_key or not endpoint:
        raise RuntimeError(
            "Missing Azure OpenAI configuration. "
            "Set AZURE_OPENAI_API_KEY and AZURE_OPENAI_ENDPOINT."
        )

    # Check for purpose-specific deployment override
    per_purpose_key = f"AZURE_OPENAI_DEPLOYMENT_NAME_{purpose.upper()}"
    deployment = os.getenv(per_purpose_key, default_deployment)

    # Get temperature for this purpose (default to reasoner temp if unknown)
    temperature = TEMPERATURE_MAP.get(purpose.lower(), 0.1)

    return AzureChatOpenAI(
        azure_endpoint=endpoint,
        api_key=api_key,
        api_version=api_version,
        azure_deployment=deployment,
        temperature=temperature,
        request_timeout=30,  # 30 seconds (enterprise: don't wait forever)
        max_retries=2,       # Retry on transient failures
    )


# Google Gemini support removed - Azure OpenAI only
# @lru_cache(maxsize=8)
# def get_gemini_chat_llm(*, purpose: str) -> ChatGoogleGenerativeAI:
#     ...


def get_chat_llm(*, purpose: str) -> AzureChatOpenAI:
    """
    Get an LLM client configured for a specific purpose.
    
    Uses Azure OpenAI only.
    
    Args:
        purpose: One of "reasoner", "talker", "judge"
    
    Returns:
        Configured Azure OpenAI LLM instance
    
    Examples:
        >>> llm = get_chat_llm(purpose="talker")
    """
    return get_azure_chat_llm(purpose=purpose)


# Public API
__all__ = ["get_azure_chat_llm", "get_chat_llm"]
