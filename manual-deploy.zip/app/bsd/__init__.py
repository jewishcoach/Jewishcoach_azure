"""
BSD Core package (per the BSD report).

This package will contain:
- stage definitions + hard-coded scripts
- state schema (structured cognitive data)
- Reasoner (Gatekeeper) and Talker (Visible coach)
- LangGraph orchestration
"""




