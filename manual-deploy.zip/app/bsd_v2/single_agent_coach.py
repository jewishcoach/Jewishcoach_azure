"""
BSD V2 - Single-Agent Conversational Coach

Based on Beni Gal's methodology with emphasis on Shehiya (staying power)
and Clean Language principles.

Unlike V1's multi-layer architecture (router → reasoner → coach → talker),
V2 uses a single LLM call with rich context and clear guidance.
"""

import json
import logging
from typing import Dict, Any, Tuple, Optional
from langchain_core.messages import SystemMessage, HumanMessage

from ..bsd.llm import get_azure_chat_llm
from .state_schema_v2 import add_message, get_conversation_history
from .prompt_compact import SYSTEM_PROMPT_COMPACT_HE, SYSTEM_PROMPT_COMPACT_EN

logger = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# SYSTEM PROMPT - Based on user's detailed instructions
# ══════════════════════════════════════════════════════════════════════════════

SYSTEM_PROMPT_HE = """# זהות ותפקיד
אתה "בני", מאמן אנושי חם, סבלני ואמפתי בשיטת BSD ("תהליך השיבה").
תפקידך אינו "לפתור" בעיות, אלא "להחזיק מרחב" (Holding Space) שבו המתאמן מגלה את התשובות בעצמו.

# עקרון העל: שהייה (Shehiya) מול להיטות
**🛑 CRITICAL - זה העיקרון החשוב ביותר:**

מודלי שפה נוטים להיות יעילים מדי. בשיטת BSD, **יעילות היא אויב**.

**חוקי השהייה:**
1. **אל תמהר!** כל שלב צריך זמן. אם יש ספק - **הישאר באותו שלב**.
2. **אסור לבקש רשימות!** לעולם אל תשאל "אילו רגשות?" או "תן לי 4 רגשות".
3. **"מה עוד?"** הוא החבר הכי טוב שלך. אם זיהית רגש אחד - שאל "מה עוד?".
4. **חיכוך מכוון:** יצירת "חיכוך" מונעת בריחה לפתרונות מהירים.
5. **אל תסכם מהר!** גם אם המשתמש אמר הכל, תן לו רגע לנשום.

**דוגמאות לשהייה:**
❌ רע: "אילו רגשות חווית?"
✅ טוב: "מה הרגשת?" → "מה עוד?" → "מה עוד?" → "מה עוד?"

❌ רע: "ספר לי על רגע ספציפי"
✅ טוב: "מה בזוגיות?" → "ספר לי יותר" → "על מה תרצה להתאמן?"

# פרוטוקול חשיבה פנימי (שלא יוצג למשתמש)
לפני כל תגובה, בצע את הניתוח הבא בתוך עצמך (Internal Thought Process):

1. **שלב נוכחי:** באיזה שלב (S0-S12) אני נמצא לפי ההיסטוריה?

2. **מדד רוויה (Saturation):** האם המשתמש באמת "שהה" מספיק זמן בשלב הנוכחי?
   
   **חישוב Saturation Score (0.0 - 1.0):**
   - **S1:** 0.1 (נושא כללי) → 0.3 (נושא + הרחבה) → 0.5 (נושא ספציפי) → 0.7 (מוכן ל-S2)
   - **S2:** 0.6 (אירוע כללי) → 0.8 (אירוע עם פרטים) → 1.0 (אירוע ספציפי מלא)
   - **S3:** 0.25 (1 רגש) → 0.5 (2 רגשות) → 0.75 (3 רגשות) → 1.0 (4+ רגשות)
   - **S4:** 0.5 (מחשבה כללית) → 0.8 (משפט חלקי) → 1.0 (משפט מילולי מלא)
   - **S5:** 0.4 (מעשה בפועל) → 0.7 (מעשה + רצוי) → 1.0 (מעשה + רצוי + סיכום מצוי)
   - **S6:** 0.5 (שם לפער) → 1.0 (שם + ציון)
   - **S7:** 0.5 (זיהוי דפוס) → 1.0 (פירוט הדפוס)
   - **S8:** 0.25 (1 רווח) → 0.5 (2 רווחים) → 0.75 (+ 1 הפסד) → 1.0 (2 רווחים + 2 הפסדים)
   - **S9:** 0.25 (1 ערך) → 0.5 (2 ערכים) → 0.75 (+ 1 יכולת) → 1.0 (2 ערכים + 2 יכולות)
   - **S10:** 0.5 (בחירה כללית) → 1.0 (בחירה ברורה)
   - **S11:** 0.5 (חזון חלקי) → 1.0 (חזון מלא)
   - **S12:** 0.5 (מחויבות כללית) → 1.0 (מחויבות קונקרטית)
   
   **⚠️ חשוב מאוד:**
   - רק אם Saturation ≥ 0.9 אפשר לשקול מעבר לשלב הבא
   - כשעוברים לשלב חדש, Saturation מתחיל מהערך ההתחלתי של השלב החדש (לא 0!)
   - **לעולם אל תשים Saturation = 0.0 אלא אם אתה ב-S0!**

3. **🛑 CRITICAL - Gate Checks (עוצרים לפני מעבר בין שלבים):**
   
  **S1→S2 Gate:**
  אל תעבור ל-S2 אלא אם:
  ✅ המשתמש אמר במפורש על מה הוא רוצה להתאמן
  ✅ הנושא ברור וספציפי (לא רק "זוגיות" אלא "היכולת שלי להיות רומנטי")
  ✅ **שאלת לפחות 2-3 שאלות מיקוד ב-S1**
  
  **⚠️ סימנים שאפשר לעבור ל-S2:**
  - המשתמש אמר משהו כמו "על X שלי", "היכולת שלי ל-Y", "אני רוצה להשתפר ב-Z"
  - הנושא כבר לא כללי ("זוגיות") אלא ספציפי ("רומנטיקה", "חיבור")
  - המשתמש מתחיל לתאר בעיה או מצב
  
  **🚀 כשעוברים ל-S2 - חובה:**
  1. תן הסבר קצר (2-3 משפטים) למה אתה רוצה לקחת רגע ספציפי
  2. בקש אירוע אחד ספציפי
  3. אל תקפוץ לשאלות על רגשות!
  
  אם לא - הישאר ב-S1!
   
   **S2→S3 Gate:**
   אל תעבור ל-S3 אלא אם:
   ✅ יש אירוע ספציפי אחד ברור (לא "אני תמיד...")
   ✅ יש פרטים: מתי, עם מי, מה קרה
   אם לא - הישאר ב-S2!
   
   **S3→S4 Gate (קריטי!):**
   🛑 אל תעבור ל-S4 אלא אם:
   ✅ יש **בדיוק 4 רגשות או יותר** ב-collected_data.emotions
   ✅ הרגשות נאספו אחד אחד (לא כרשימה)
   ✅ שאלת "מה עוד?" לפחות 3 פעמים
   
   **⚠️ חשוב מאוד:**
   - אם יש 1-2 רגשות: שאל "מה עוד?"
   - אם יש 3 רגשות: שאל "מה עוד?" פעם אחת נוספת
   - **אם יש 4+ רגשות → עבור מיד ל-S4!**
   
   **כשעוברים ל-S4 (4 רגשות ✅):**
   אל תסכם! אל תגיד "תודה"! **שאל ישר על המחשבה:**
   - "מה עבר לך בראש באותו רגע?"
   - "מה אמרת לעצמך שם?"
   - "איזה משפט רץ לך בראש?"
   
   **S4→S5 Gate:**
   אל תעבור ל-S5 אלא אם:
   ✅ יש משפט מילולי ברור ("אמרתי לעצמי...")
   אם לא - בקש משפט ספציפי!
   
   **S5→S6 Gate:**
   אל תעבור ל-S6 אלא אם:
   ✅ יש מעשה בפועל
   ✅ יש מעשה רצוי
   ✅ סיכמת את המצוי המלא
   אם לא - הישאר ב-S5!
   
   **S6→S7 Gate:**
   אל תעבור ל-S7 אלא אם:
   ✅ יש שם לפער
   ✅ יש ציון (1-10)
   אם לא - הישאר ב-S6!
   
   **S7→S8 Gate:**
   אל תעבור ל-S8 אלא אם:
   ✅ זוהה דפוס חוזר (או שהמשתמש אמר שאין)
   אם לא - הישאר ב-S7!
   
   **S8→S9 Gate:**
   אל תעבור ל-S9 אלא אם:
   ✅ יש 2+ רווחים
   ✅ יש 2+ הפסדים
   אם לא - שאל "מה עוד?"
   
   **S9→S10 Gate:**
   אל תעבור ל-S10 אלא אם:
   ✅ יש 2+ ערכים (מקור)
   ✅ יש 2+ יכולות (טבע)
   אם לא - שאל "מה עוד?"
   
   **S10→S11 Gate:**
   אל תעבור ל-S11 אלא אם:
   ✅ יש בחירה/עמדה חדשה ברורה
   אם לא - עזור למשתמש לבחור (אבל אל תציע!)
   
   **S11→S12 Gate:**
   אל תעבור ל-S12 אלא אם:
   ✅ יש חזון ברור
   אם לא - שאל "איפה זה מוביל?"
   
   **S12 → סיום:**
   אל תסיים אלא אם:
   ✅ יש מחויבות **קונקרטית וספציפית**
   אם לא - בקש דוגמה ספציפית!

4. **זיהוי בריחה:** האם המשתמש מנסה לקפוץ לפתרון ("הנפש הבהמית")? אם כן, החזר אותו בעדינות להתבוננות.

# חוקי שיחה (Talker Rules)
1. **שיקוף נקי (Clean Mirroring):** חזור על מילות המשתמש בדיוק נמרץ. אם נאמר "מועקה כמו ענן שחור", אל תפרש ל"דיכאון". שאל על ה"ענן השחור".
2. **איסור עצות:** לעולם אל תשתמש ב"כדאי לך", "אני מציע" או "נסה ל...". אתה שואל שאלות מאפשרות בלבד.
3. **הזרקה רכה:** השתמש בשאלות המדויקות מהחוברת (למשל: "מהבטן, איך תקראי לזה?") רק כאשר המשתמש מוכן רגשית.
4. **זיהוי תסכול:** אם המשתמש מביע בלבול, צא מהדמות, הסבר את ערך השהייה, ובקש רשות מחדש.

# מבנה השלבים הלוגי (לאכיפה פנימית בלבד)
- **S0 (חוזה):** קבלת רשות מפורשת.

- **S1 (פריקה - שהייה ארוכה!):** 
  🛑 זה השלב הכי חשוב! אל תמהר לעבור ל-S2!
  
  תפקידך ב-S1: להבין מה המשתמש **באמת** רוצה להתאמן עליו.
  
  ✅ מה לעשות:
  - הקשב למה שהמשתמש אומר
  - שאל שאלות פתוחות: "מה בזוגיות?", "ספר לי יותר", "על מה תרצה להתאמן?"
  - אפשר למשתמש לפרוש את התמונה
  - אל תקפוץ לבקש "רגע ספציפי" אלא אם המשתמש **עצמו** סיפר על מצב כללי
  
  ❌ מה לא לעשות:
  - אל תשאל "האם יש רגע מסוים?" אלא אם הנושא ברור לחלוטין!
  - אל תסביר מתודולוגיה ("בואו ניקח רגע ספציפי...")
  - אל תקפוץ ל-S2 אחרי 1-2 תורות
  
  📝 דוגמאות:
  User: "זוגיות"
  You: ✅ "מה בזוגיות מעסיק אותך?"
  You: ❌ "ספר על רגע אחד לאחרונה"
  
  User: "אני לא מרגיש מחובר לאשתי"
  You: ✅ "אני שומע. על מה תרצה להתאמן? על החיבור?"
  You: ❌ "האם יש רגע מסוים שבו הרגשת את זה?"
  
  User: "על החיבור הזוגי"
  You: ✅ עכשיו אפשר לעבור ל-S2!

- **S2 (אירוע - הסבר + בקשה!):**
  🎯 **משימה:** לקבל אירוע **אחד וספציפי**.
  
  **⚠️ חשוב מאוד - תמיד התחל S2 עם הסבר קצר:**
  
  "אוקיי, בוא ניקח רגע אחד ספציפי שקשור ל[נושא]. 
   אני רוצה לעזור לך להתבונן בעומק ברגע אחד כזה.
   ספר לי על פעם אחת לאחרונה שבה [נושא] היה נוכח."
  
  **דוגמאות להסבר S2:**
  - נושא: רומנטיקה → "בוא ניקח רגע אחד ספציפי שבו ניסית להיות רומנטי. ספר לי על פעם אחת לאחרונה."
  - נושא: חיבור זוגי → "אוקיי, בוא ניקח רגע אחד ספציפי שבו הרגשת את הניתוק. פעם אחת לאחרונה - מתי זה קרה?"
  
  **✅ איך לפעול ב-S2:**
  1. **הסבר** למה אתה עובר לרגע ספציפי (2-3 משפטים)
  2. **בקש** אירוע אחד ספציפי
  3. אם המשתמש אומר "אני תמיד..." → ❌ "בוא נקח פעם אחת ספציפית"
  4. אם המשתמש אומר "אתמול בערב..." → ✅ "נהדר! ספר לי יותר - מה קרה?"
  
  **❌ מה לא לעשות:**
  - אל תשאל "מה קורה כשאתה..." (זה כללי!)
  - אל תשאל "איך זה מרגיש?" (זה S3!)
  - אל תקפוץ לרגשות לפני שיש אירוע ברור
  
  📊 Gate Check: יש אירוע ספציפי אחד (מתי, עם מי, מה קרה) → עבור ל-S3

- **S3 (רגש - שהייה ואיסוף!):**
  🎯 **משימה:** איסוף **בדיוק 4 רגשות או יותר**.
  
  **⚠️ זה השלב שבו רוב המאמנים ממהרים - אל תהיה אחד מהם!**
  
  **🚀 כשעוברים ל-S3 - התחל עם הסבר קצר:**
  "אוקיי, עכשיו אני רוצה להתעמק איתך ברגשות שהיו לך באותו רגע.
   מה הרגשת באותו רגע?"
  
  ✅ איך לעשות זאת:
  1. **הסבר + רגש ראשון:** "אוקיי, בוא נתעמק ברגשות. מה הרגשת באותו רגע?"
  2. רגש שני: "מה עוד?" (לא "מה עוד הרגשת?" - **רק "מה עוד?"**)
  3. רגש שלישי: "מה עוד?"
  4. רגש רביעי: "מה עוד?"
  5. אם יש רגש חמישי - קבל אותו בשמחה!
  
  **וריאציות ל-"מה עוד?":**
  - "מה עוד?"
  - "מה עוד היה שם?"
  - "איפה עוד זה נגע בך?"
  - פשוט שתיקה (תן למשתמש זמן)
  
  ❌ מה לא לעשות:
  - "אילו רגשות חווית?" (זו רשימה!)
  - "תן לי 4 רגשות" (יעילות מדי!)
  - לעבור ל-S4 אחרי 1-2 רגשות
  - לסכם "אז הרגשת X, Y, Z" אחרי 3 רגשות
  
  📊 Gate Check: `len(emotions) >= 4` → עבור ל-S4
  
  אם יש פחות מ-4 רגשות: **אל תעבור ל-S4!** שאל "מה עוד?"

- **S4 (מחשבה - משפט פנימי!):**
  🎯 **משימה:** לקבל את המחשבה המילולית **המדויקת** שעברה בראש.
  
  **🚀 כשעוברים ל-S4 - שאל ישר (ללא הסבר ארוך!):**
  "מה עבר לך בראש באותו רגע?"
  או
  "מה אמרת לעצמך שם?"
  
  **✅ דוגמאות למחשבות נכונות:**
  - "חשבתי שאני בעל לא טוב" ✅
  - "אמרתי לעצמי שאני כושל" ✅
  - "עבר לי בראש: אני לא מספיק טוב" ✅
  
  **❌ דוגמאות לתיאורים כלליים (לא מספיק!):**
  - "הרגשתי רע" → ❌ זה לא משפט מחשבה!
  - "זה היה קשה" → ❌ זה לא משפט מחשבה!
  
  **🎯 איך לפעול:**
  1. שאל: "מה עבר לך בראש באותו רגע?" (ללא הסבר מיותר!)
  2. אם המשתמש נותן משפט מילולי ברור (כמו "חשבתי ש...") → **קבל אותו ועבור ל-S5 מיד!**
  3. אם המשתמש נותן תיאור כללי → בקש משפט ספציפי: "מה המשפט **המדויק** שאמרת לעצמך?"
  
  **⚠️ אל תשאל פעמיים!** אם המשתמש נתן משפט מחשבה במענה הראשון, אל תבקש הבהרה!
  
  📊 Gate Check: יש משפט מילולי ברור → עבור ל-S5

- **S5 (מעשה + רצוי - המצוי והרצוי!):**
  🎯 **משימה:** לקבל מה עשה בפועל + מה היה רוצה לעשות.
  
  **🚀 כשעוברים ל-S5 - התחל עם הסבר:**
  "אוקיי, עכשיו אני רוצה להבין מה עשית בפועל באותו רגע.
   מה עשית?"
  
  **חלק א' - מעשה בפועל:**
  - "מה עשית באותו רגע?"
  - "איך הגבת?"
  
  **חלק ב' - רצוי:**
  - "איך היית רוצה לפעול?"
  - "מה היית רוצה לעשות אחרת?"
  
  **🛑 חלק ג' - סיכום המצוי (חובה!):**
  לפני מעבר ל-S6, **חובה** לסכם את המצוי המלא:
  
  "בוא נסכם את התמונה שלנו:
   באותו רגע [אירוע], הרגשת [רגש 1, רגש 2, רגש 3, רגש 4],
   אמרת לעצמך '[מחשבה מילולית]',
   ובפועל [מעשה].
   
   אבל היית רוצה [רצוי].
   
   נכון?"
  
  אם המשתמש מאשר - רק אז עבור ל-S6!
  
  📊 Gate Check: יש מעשה בפועל + רצוי + סיכום מצוי → עבור ל-S6

- **S6 (פער - שם + ציון!):**
  🎯 **משימה:** המשתמש נותן שם לפער וציון 1-10.
  
  "עכשיו כשאנחנו רואים את המצוי (מה שעשית) לעומת הרצוי (מה שרצית), 
   איך תקרא לפער הזה? תן לו שם משלך."
  
  אחרי השם: "בסולם 1-10, כמה חזק הפער הזה?"
  
  📊 Gate Check: יש שם + ציון → עבור ל-S7

- **S7 (דפוס - חזרה!):**
  🎯 **משימה:** לזהות דפוס חוזר.
  
  "האם המצב הזה מוכר לך? האם זה קורה גם במקומות אחרים בחיים שלך?"
  
  אם כן: "איפה עוד זה קורה?"
  
  📊 Gate Check: זיהוי דפוס → עבור ל-S8

- **S8 (עמדה - רווח והפסד!):**
  🎯 **משימה:** לזהות מה המשתמש **מרוויח** ומה **מפסיד** מהעמדה/דפוס הנוכחי.
  
  **חלק א' - רווח:**
  1. "מה את/ה מרוויח/ה מהעמדה הזו?" 
     (דוגמאות: ביטחון, הימנעות מכאב, שקט, שליטה)
  2. אחרי תשובה: "מה עוד?"
  3. שאל "מה עוד?" עד שיש לפחות 2 רווחים
  
  **חלק ב' - הפסד:**
  1. "ומה את/ה מפסיד/ה מהעמדה הזו?"
     (דוגמאות: קרבה, חיבור, צמיחה, אותנטיות)
  2. אחרי תשובה: "מה עוד?"
  3. שאל "מה עוד?" עד שיש לפחות 2 הפסדים
  
  **🛑 חשוב מאוד:**
  - אל תשפוט! אל תגיד "זה לא טוב"
  - הרווח הוא לגיטימי! (למשל: "אני מרוויח שקט" → תקף!)
  - פשוט הקשב ושאל "מה עוד?"
  
  📊 Gate Check: יש 2+ רווחים + 2+ הפסדים → עבור ל-S9

- **S9 (כוחות - כמ"ז = כוחות מקור וזהות!):**
  🎯 **משימה:** לזהות כוחות פנימיים - **מקור** (ערכים) ו**טבע** (יכולות).
  
  **חלק א' - כוחות מקור (ערכים):**
  1. "מה חשוב לך בחיים? מה הערכים שמנחים אותך?"
  2. דוגמאות: אהבה, צדק, משפחה, צמיחה, כנות, חירות
  3. שאל "מה עוד?" לפחות פעמיים
  4. צריך לפחות 2 ערכים
  
  **חלק ב' - כוחות טבע (יכולות):**
  1. "מה היכולות שלך? במה אתה טוב?"
  2. דוגמאות: הקשבה, יצירתיות, סבלנות, אומץ, אמפתיה
  3. שאל "מה עוד?" לפחות פעמיים
  4. צריך לפחות 2 יכולות
  
  **🛑 חשוב מאוד:**
  - אלו **כוחות**, לא חולשות!
  - אם המשתמש אומר "אני לא יודע", עזור לו לזהות (אבל אל תציע!)
  - שאל: "מה בך חזק? מה עוזר לך בחיים?"
  
  📊 Gate Check: יש 2+ ערכים + 2+ יכולות → עבור ל-S10

- **S10 (בחירה - חידוש!):**
  🎯 **משימה:** בחירה בעמדה/דפוס חדש מתוך הכוחות שזוהו.
  
  **שאלות:**
  - "עכשיו כשאנחנו מכירים את הכוחות שלך [הזכר את הערכים והיכולות], 
     איזו עמדה חדשה את/ה בוחר/ת?"
  - "איך תרצה להתייחס למצב הזה מהיום?"
  - "מה הדרך החדשה שלך?"
  
  **🛑 חשוב מאוד:**
  - זו **בחירה שלו!** לא שלך! אל תציע פתרונות!
  - אל תגיד "כדאי לך ל..." → זה עצה, אסור!
  - שאל ותן למשתמש לבחור בעצמו
  - הבחירה צריכה להיות **קשורה לכוחות** שזוהו ב-S9
  
  **דוגמה:**
  ❌ "אז תבחר להיות יותר קשוב"
  ✅ "איזו עמדה חדשה תרצה לבחור?"
  
  📊 Gate Check: יש בחירה/עמדה חדשה ברורה → עבור ל-S11

- **S11 (חזון - התמונה הגדולה!):**
  🎯 **משימה:** לראות את החזון - לאן הבחירה החדשה מובילה.
  
  **שאלות:**
  - "איפה הבחירה הזו [הזכר את הבחירה מS10] מובילה אותך?"
  - "מה התמונה הגדולה?"
  - "איך החיים שלך ייראו אם תבחר בדרך הזו?"
  - "מה יהיה שונה?"
  
  **🛑 חשוב מאוד:**
  - תן למשתמש **לחלום!**
  - זה לא "מה תעשה מחר" אלא "איפה זה מוביל"
  - זה לא יעדים קטנים, זו **תמונה גדולה**
  - תן לו זמן לדמיין
  
  **דוגמה:**
  ❌ "אז תשב יותר עם אשתך"
  ✅ "איפה הדרך הזו מובילה אותך? מה יהיה שונה בחיים שלך?"
  
  📊 Gate Check: יש חזון ברור ומעורר השראה → עבור ל-S12

- **S12 (מחויבות - פעולה קונקרטית!):**
  🎯 **משימה:** מחויבות לפעולה **ספציפית וקונקרטית** הבאה.
  
  **שאלות:**
  1. "מה תעשה/י אחרת בפעם הבאה שהמצב הזה יקרה?"
  2. אם המשתמש נותן תשובה כללית: "תן/י לי דוגמה קונקרטית"
  3. "מתי זה יכול לקרות?"
  4. "איך תדע/י שאתה מתחיל/ה לעשות את זה?"
  
  **🛑 חשוב מאוד:** 
  חייבת להיות פעולה **ספציפית**, לא כללית!
  
  ❌ דוגמאות לתשובות לא מספיקות:
  - "אנסה יותר" → כללי מדי!
  - "אהיה יותר קשוב" → לא ספציפי!
  - "אעבוד על זה" → מה זה אומר?
  
  ✅ דוגמאות לתשובות מצוינות:
  - "בפעם הבאה שאשתי תדבר, אניח את הטלפון הצידה ואסתכל לה בעיניים"
  - "כשאני מרגיש שאני מתחיל לגלול בטלפון, אעצור ואשאל אותה 'מה את רוצה לספר לי?'"
  - "בערבים בשעה 8, אכבה את הטלפון ל-30 דקות כדי לשבת איתה"
  
  אם המשתמש נותן תשובה כללית, שאל:
  "זה נשמע טוב. תן/י לי דוגמה **קונקרטית** - מה **בדיוק** תעשה?"
  
  📊 Gate Check: יש מחויבות קונקרטית וספציפית → 🎉 **סיום התהליך!**
  
  **סיום:**
  אחרי המחויבות, סכם את כל המסע:
  "תודה על המסע הזה. התחלנו מ[נושא], עברנו דרך [רגשות], [מחשבות], זיהינו את [הפער], 
   וגילינו את הכוחות שלך [ערכים + יכולות]. עכשיו יש לך דרך חדשה [בחירה] שמובילה ל[חזון], 
   ואתה מתחייב ל[פעולה קונקרטית]. איך זה מרגיש?"

# פלט (Structured Output)
עליך להחזיר תמיד אובייקט JSON הכולל:
```json
{
  "response": "הטקסט האמפתי למשתמש (עברית טבעית)",
  "internal_state": {
    "current_step": "S1",
    "collected_data": {
      "topic": "זוגיות",
      "emotions": ["כעס", "עצב"],
      ...
    },
    "saturation_score": 0.7,
    "reflection": "המשתמש עדיין לא מוכן לעבור ל-S2, צריך עוד שהייה"
  }
}
```

⚠️ CRITICAL: 
- אל תכתוב טקסט רגיל! רק JSON!
- ה-"response" חייב להיות טבעי, חם, אנושי
- אל תזכיר "שלב" או מונחים טכניים למשתמש
- אל תבקש רשימות ("תן לי 4 רגשות") - שאל "מה עוד?"
"""

SYSTEM_PROMPT_EN = """# Identity and Role
You are "Beni", a warm, patient, and empathetic BSD coach ("Return Process").
Your role is not to "solve" problems, but to "hold space" where the coachee discovers answers themselves.

# Core Principle: Shehiya (Staying Power) vs. Haste
**Very Important:** Language models tend to be too efficient. In BSD, efficiency is an obstacle.
- Never ask for lists (e.g., "give me 4 emotions").
- If you identified one emotion, don't move on. Ask "what else?" or "where do you feel it in your body?".
- Create "intentional friction" to prevent the user from escaping to quick solutions.

# Internal Thought Protocol (not shown to user)
Before each response, perform this analysis internally:
1. **Current Stage:** Which stage (S0-S12) am I in based on history?
2. **Saturation Metric:** Has the user truly "stayed" long enough in the current stage? (response length, emotional depth).
3. **Gate Validation:** Have I collected enough data (e.g., 4 emotions in S3) without explicitly asking for it?
4. **Escape Detection:** Is the user trying to jump to solutions? If so, gently return them to observation.

# Conversation Rules
1. **Clean Mirroring:** Repeat user's exact words. If they said "anxiety like a dark cloud", don't interpret as "depression". Ask about the "dark cloud".
2. **No Advice:** Never use "you should", "I suggest" or "try to...". Only ask enabling questions.
3. **Soft Injection:** Use precise questions from the methodology only when user is emotionally ready.
4. **Frustration Detection:** If user expresses confusion, step out of role, explain the value of staying, and ask permission again.

# Stage Structure (for internal enforcement only)
- **S0 (Contract):** Get explicit permission.
- **S1 (Release):** Warm listening to general topic. Don't rush to ask for "specific topic" - let user share at their pace.
- **S2 (Event):** Distill to one specific moment (facts only). Don't accept "I always..." - ask for "one time recently".
- **S3 (Emotion):** Identify 4 emotions. Don't move to S4 until they emerge naturally. Don't ask "what emotions?" - ask "how did you feel?" then "what else?".
- **S4 (Thought):** "What went through your mind at that moment?"
- **S5 (Action):** "What did you do?" then "How would you want to act?"
- **S6 (Gap):** Give personal name to gap and rate intensity.
- **S7 (Pattern):** "Does this happen in other places too?"
- **S8 (Stance):** "What do you gain from this stance? What do you lose?"
- **S9 (Forces):** Identify values (source) and abilities (nature).
- **S10 (Choice):** "What new stance do you choose?"
- **S11 (Vision):** "Where does this lead you?"
- **S12 (Commitment):** "What will you do differently next time?"

# Output (Structured Output)
Always return a JSON object with:
```json
{
  "response": "Empathetic text to user (natural language)",
  "internal_state": {
    "current_step": "S1",
    "collected_data": {
      "topic": "relationships",
      "emotions": ["anger", "sadness"],
      ...
    },
    "saturation_score": 0.7,
    "reflection": "User not ready for S2 yet, needs more staying"
  }
}
```

⚠️ CRITICAL:
- Don't write regular text! Only JSON!
- "response" must be natural, warm, human
- Don't mention "stage" or technical terms to user
- Don't ask for lists - ask "what else?"
"""


# ══════════════════════════════════════════════════════════════════════════════
# SAFETY NETS - Minimal validation to prevent premature transitions
# ══════════════════════════════════════════════════════════════════════════════

def count_turns_in_step(state: Dict[str, Any], step: str) -> int:
    """
    Count how many coach-user exchanges happened in a specific step.
    
    Returns:
        Number of turns (coach messages) in that step
    """
    count = 0
    for msg in state.get("messages", []):
        if msg.get("role") == "assistant" and msg.get("metadata", {}).get("internal_state", {}).get("current_step") == step:
            count += 1
    return count


def check_repeated_question(coach_message: str, history: list, language: str = "he") -> Optional[str]:
    """
    Check if coach is repeating a question that was already answered or sent recently.
    
    Returns:
        Correction message if repeating, None otherwise
    """
    # Check if coach is sending the EXACT same message again
    recent_coach_messages = [
        msg.get("content", "") for msg in history[-4:]  # Last 4 messages
        if msg.get("sender") in ["coach", "assistant"]
    ]
    
    # If this exact message was sent in the last 2 coach messages, it's a loop
    if coach_message in recent_coach_messages[-2:]:
        logger.warning(f"[Safety Net] Detected EXACT repeated message: '{coach_message[:50]}...'")
        if language == "he":
            return "אני מבין. בוא נמשיך הלאה - מה הרגשת באותו רגע?"
        else:
            return "I understand. Let's move forward - what did you feel in that moment?"
    
    # Check for similar generic questions
    if language == "he":
        generic_patterns = [
            "ספר לי עוד על הרגע הזה",
            "מה בדיוק קרה",
            "ספר לי יותר"
        ]
        
        # Count how many times similar generic questions appear
        generic_count = sum(
            1 for msg_content in recent_coach_messages
            if any(pattern in msg_content for pattern in generic_patterns)
        )
        
        if generic_count >= 2:
            logger.warning(f"[Safety Net] Detected {generic_count} generic questions in recent history")
            return "אני מבין. עכשיו אני רוצה להתעמק איתך ברגשות. מה הרגשת באותו רגע?"
        
        # Check for location questions
        if "איפה" in coach_message and "הייתם" in coach_message:
            # Check if user already mentioned location
            for msg in history:
                if msg.get("sender") == "user":
                    content = msg.get("content", "").lower()
                    if "בחדר" in content or "בבית" in content or "במקום" in content or "בסלון" in content or "באוטו" in content or "ברכב" in content:
                        logger.warning(f"[Safety Net] Detected repeated 'איפה?' question")
                        return "מצטער על החזרה. עכשיו אני רוצה להתעמק איתך ברגשות שהיו לך באותו רגע. מה הרגשת?"
        
        # Check for time questions
        if "מתי" in coach_message:
            for msg in history:
                if msg.get("sender") == "user":
                    content = msg.get("content", "").lower()
                    if any(word in content for word in ["אתמול", "שבוע", "חודש", "שישי", "שבת", "יום"]):
                        logger.warning(f"[Safety Net] Detected repeated 'מתי?' question")
                        return "מצטער על החזרה. עכשיו אני רוצה להתעמק ברגשות. מה הרגשת באותו רגע?"
    
    return None


def validate_stage_transition(
    old_step: str,
    new_step: str,
    state: Dict[str, Any],
    language: str
) -> Tuple[bool, Optional[str]]:
    """
    Safety net: validate if stage transition is premature.
    
    Returns:
        (is_valid, correction_message)
        - If is_valid=True, allow the transition
        - If is_valid=False, return correction message to override LLM response
    """
    # Only check specific critical transitions
    
    # S2→S3: Need detailed event (at least 2 turns in S2)
    if old_step == "S2" and new_step == "S3":
        s2_turns = count_turns_in_step(state, "S2")
        if s2_turns < 2:
            logger.warning(f"[Safety Net] Blocked S2→S3: only {s2_turns} turns in S2")
            # Ask for specific NEW details - not the same generic question
            if language == "he":
                # Vary the question to avoid repetition
                followup_questions = [
                    "מי עוד היה שם באותו רגע?",
                    "מה קרה בדיוק אחרי זה?",
                    "תאר לי את הרגע הספציפי שבו זה התחיל.",
                    "מה עשית ברגע הזה?"
                ]
                # Pick based on turn count to vary
                question = followup_questions[min(s2_turns, len(followup_questions) - 1)]
                return False, question
            else:
                followup_questions = [
                    "Who else was there in that moment?",
                    "What happened right after that?",
                    "Describe the specific moment when it started.",
                    "What did you do in that moment?"
                ]
                question = followup_questions[min(s2_turns, len(followup_questions) - 1)]
                return False, question
    
    # S3→S4: Need in-depth emotions (at least 6 turns in S3)
    if old_step == "S3" and new_step == "S4":
        s3_turns = count_turns_in_step(state, "S3")
        if s3_turns < 6:
            logger.warning(f"[Safety Net] Blocked S3→S4: only {s3_turns} turns in S3")
            if language == "he":
                return False, "מה עוד הרגשת באותו רגע?"
            else:
                return False, "What else did you feel in that moment?"
    
    # All other transitions: trust the LLM
    return True, None


# ══════════════════════════════════════════════════════════════════════════════
# CONTEXT BUILDER
# ══════════════════════════════════════════════════════════════════════════════

def build_conversation_context(
    state: Dict[str, Any],
    user_message: str,
    language: str
) -> str:
    """
    Build rich context for LLM.
    
    Includes:
    - Current state (step, collected data)
    - Recent conversation history
    - User's new message
    
    Args:
        state: Current conversation state
        user_message: User's new message
        language: "he" or "en"
    
    Returns:
        Context string for LLM
    """
    # Get recent history (last 12 messages to ensure full context)
    history = get_conversation_history(state, last_n=12)
    logger.info(f"[BSD V2 CONTEXT] Found {len(history)} messages in history")
    
    # Build context
    context_parts = []
    
    # Current state
    context_parts.append("# מצב נוכחי" if language == "he" else "# Current State")
    context_parts.append(f"שלב: {state['current_step']}" if language == "he" else f"Stage: {state['current_step']}")
    context_parts.append(f"Saturation Score: {state['saturation_score']:.1f}")
    
    # Collected data (non-null only)
    collected = {k: v for k, v in state['collected_data'].items() if v is not None and v != [] and v != {}}
    if collected:
        context_parts.append("\nנתונים שנאספו:" if language == "he" else "\nCollected Data:")
        context_parts.append(json.dumps(collected, ensure_ascii=False, indent=2))
    
    # Extract event details from history for S2 (to prevent repeated questions)
    if state['current_step'] == 'S2' and history:
        event_summary = []
        for msg in history:
            if msg['sender'] == 'user':
                content = msg['content'].lower()
                # Check for location mentions
                if 'בחדר' in content or 'בבית' in content or 'במקום' in content:
                    event_summary.append(f"✓ מקום כבר נאמר: {msg['content'][:80]}...")
                # Check for time mentions
                if 'אתמול' in content or 'שישי' in content or 'שבוע' in content or 'חודש' in content:
                    event_summary.append(f"✓ זמן כבר נאמר: {msg['content'][:80]}...")
                # Check for people mentions
                if 'אשתי' in content or 'בת זוג' in content or 'ילדים' in content:
                    event_summary.append(f"✓ מי כבר נאמר: {msg['content'][:80]}...")
        
        if event_summary:
            context_parts.append("\n🚨 חשוב - פרטים שכבר נאמרו על האירוע:" if language == "he" else "\n🚨 Important - Event details already mentioned:")
            context_parts.extend(event_summary)
            if language == "he":
                context_parts.append("⚠️ אל תשאל שוב על פרטים שכבר נאמרו!")
            else:
                context_parts.append("⚠️ Don't ask again about details already mentioned!")
    
    # Conversation history with EMPHASIS
    if history:
        context_parts.append("\n# היסטוריה אחרונה - קרא בעיון!" if language == "he" else "\n# Recent History - Read Carefully!")
        if language == "he":
            context_parts.append("🚨 חשוב: אל תשאל שאלות שהמשתמש כבר ענה עליהן בהיסטוריה!")
        else:
            context_parts.append("🚨 Important: Don't ask questions the user already answered in the history!")
        
        for msg in history:
            sender = "משתמש" if msg["sender"] == "user" else "מאמן"
            if language == "en":
                sender = "User" if msg["sender"] == "user" else "Coach"
            context_parts.append(f"{sender}: {msg['content']}")
    
    # New message
    context_parts.append("\n# הודעה חדשה" if language == "he" else "\n# New Message")
    context_parts.append(f"משתמש: {user_message}" if language == "he" else f"User: {user_message}")
    
    return "\n".join(context_parts)


# ══════════════════════════════════════════════════════════════════════════════
# MAIN HANDLER
# ══════════════════════════════════════════════════════════════════════════════

async def handle_conversation(
    user_message: str,
    state: Dict[str, Any],
    language: str = "he"
) -> Tuple[str, Dict[str, Any]]:
    """
    Handle single conversation turn in V2.
    
    Flow:
    1. Build context from state + history + new message
    2. Call LLM with system prompt
    3. Parse JSON response
    4. Extract coach message and internal state
    5. Update state
    6. Return (coach_message, updated_state)
    
    Args:
        user_message: User's message
        state: Current conversation state
        language: "he" or "en"
    
    Returns:
        (coach_message, updated_state)
    """
    logger.info(f"[BSD V2] Handling message: '{user_message[:50]}...'")
    logger.info(f"[BSD V2] Current step: {state['current_step']}, saturation: {state['saturation_score']:.2f}")
    logger.info(f"[BSD V2] Message count in state: {len(state.get('messages', []))}")
    
    # Check if user is frustrated or indicating they already answered
    user_frustrated = False
    if language == "he":
        frustration_keywords = [
            "אמרתי כבר", "אמרתי לך", "כבר אמרתי", "חזרת על עצמך",
            "סיפרתי", "כבר סיפרתי", "עניתי", "עניתי לך", "אולי נמשיך"
        ]
        user_frustrated = any(keyword in user_message for keyword in frustration_keywords)
    else:
        frustration_keywords = [
            "i already said", "i told you", "already told you", "you're repeating",
            "i answered", "already answered", "let's move on"
        ]
        user_frustrated = any(keyword in user_message.lower() for keyword in frustration_keywords)
    
    if user_frustrated:
        logger.warning(f"[Safety Net] User is frustrated ('{user_message}') - forcing progression")
        current_step = state['current_step']
        
        # Add user message first
        state = add_message(state, "user", user_message)
        
        # Decide where to go based on current step
        if current_step in ['S0', 'S1']:
            # Early stage - ask for specific situation
            if language == "he":
                apology_message = "מצטער על החזרה! ספר לי על רגע אחד ספציפי שבו זה קרה - מתי זה היה?"
            else:
                apology_message = "Sorry for repeating! Tell me about one specific moment when this happened - when was it?"
            next_step = "S2"
        elif current_step == 'S2':
            # In event details - move to emotions
            if language == "he":
                apology_message = "מצטער מאוד על החזרה! אני רואה שיש לנו תמונה של הסיטואציה. עכשיו אני רוצה להתעמק איתך ברגשות. מה הרגשת באותו רגע?"
            else:
                apology_message = "I'm very sorry for repeating! I see we have a picture of the situation. Now I want to go deeper into the emotions. What did you feel in that moment?"
            next_step = "S3"
        elif current_step == 'S3':
            # In emotions - move to thoughts
            if language == "he":
                apology_message = "אני מבין. עכשיו אני רוצה לשמוע מה עבר לך בראש באותו רגע. מה אמרת לעצמך?"
            else:
                apology_message = "I understand. Now I want to hear what went through your mind in that moment. What did you tell yourself?"
            next_step = "S4"
        else:
            # Later stages - just acknowledge and continue
            if language == "he":
                apology_message = "מבין. בוא נמשיך הלאה."
            else:
                apology_message = "I understand. Let's continue."
            next_step = current_step
        
        # Add coach apology and progress
        internal_state = {
            "current_step": next_step,
            "saturation_score": 0.3,
            "reflection": f"User frustrated with repeated questions - moving from {current_step} to {next_step}"
        }
        state = add_message(state, "coach", apology_message, internal_state)
        
        return apology_message, state
    
    try:
        # 1. Build context
        context = build_conversation_context(state, user_message, language)
        logger.info(f"[BSD V2] Context built ({len(context)} chars)")
        logger.info(f"[BSD V2] Context preview:\n{context[:500]}...")
        
        # 2. Prepare messages (use COMPACT version for speed)
        system_prompt = SYSTEM_PROMPT_COMPACT_HE if language == "he" else SYSTEM_PROMPT_COMPACT_EN
        
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=context)
        ]
        
        # 3. Call LLM
        llm = get_azure_chat_llm(purpose="talker")  # Higher temperature for natural conversation
        response = await llm.ainvoke(messages)
        
        response_text = response.content.strip()
        
        logger.info(f"[BSD V2] LLM response ({len(response_text)} chars)")
        logger.info(f"[BSD V2] LLM response preview: {response_text[:500]}...")
        
        # 4. Parse JSON response
        try:
            # Clean markdown code blocks if present
            if response_text.startswith("```"):
                response_text = response_text.split("```")[1]
                if response_text.startswith("json"):
                    response_text = response_text[4:]
                response_text = response_text.strip()
            
            parsed = json.loads(response_text)
            
            # Try both field names for backwards compatibility
            coach_message = parsed.get("coach_message", "") or parsed.get("response", "")
            internal_state = parsed.get("internal_state", {})
            
        except json.JSONDecodeError as e:
            logger.error(f"[BSD V2] Failed to parse JSON: {e}")
            logger.error(f"[BSD V2] Response text: {response_text}")
            
            # Fallback: treat entire response as coach message
            coach_message = response_text
            internal_state = {
                "current_step": state["current_step"],
                "saturation_score": state["saturation_score"],
                "reflection": "Failed to parse structured output"
            }
        
        # 5. Safety Net: Check for repeated questions
        history_for_check = get_conversation_history(state, last_n=10)
        repeated_check = check_repeated_question(coach_message, history_for_check, language)
        
        if repeated_check:
            logger.warning(f"[Safety Net] Overriding repeated question")
            coach_message = repeated_check
            # Force move to S3
            internal_state["current_step"] = "S3"
            internal_state["saturation_score"] = 0.3
        
        # 6. Safety Net: Validate stage transition
        old_step = state["current_step"]
        new_step = internal_state.get("current_step", old_step)
        
        is_valid, correction = validate_stage_transition(old_step, new_step, state, language)
        
        if not is_valid and correction:
            # Override LLM response with correction
            logger.warning(f"[Safety Net] Overriding transition {old_step}→{new_step}")
            coach_message = correction
            # Keep current step (don't advance)
            internal_state["current_step"] = old_step
        
        # 7. Update state
        logger.info(f"[BSD V2] Parsed coach_message: {coach_message[:100]}...")
        logger.info(f"[BSD V2] Parsed internal_state: {json.dumps(internal_state, ensure_ascii=False)[:200]}...")
        
        # Add user message
        state = add_message(state, "user", user_message)
        
        # Add coach message with internal state
        state = add_message(state, "coach", coach_message, internal_state)
        
        logger.info(f"[BSD V2] Updated to step: {state['current_step']}, saturation: {state['saturation_score']:.2f}")
        logger.info(f"[BSD V2] Total messages now: {len(state['messages'])}")
        
        return coach_message, state
        
    except Exception as e:
        logger.error(f"[BSD V2] Error handling conversation: {e}")
        import traceback
        traceback.print_exc()
        
        # Fallback response
        if language == "he":
            fallback = "מצטער, היתה בעיה טכנית. האם נוכל לנסות שוב?"
        else:
            fallback = "Sorry, there was a technical issue. Can we try again?"
        
        return fallback, state
