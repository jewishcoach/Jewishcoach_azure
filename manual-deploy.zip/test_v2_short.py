"""
סימולציה קצרה של V2 - בדיקת S3→S4 transition
==============================================

בודק ספציפית:
- S3: איסוף 4 רגשות
- מעבר ל-S4 רק אחרי 4 רגשות
- S4: משפט מחשבה מילולי
- מעבר ל-S5
"""

import os
import sys
import json
from pathlib import Path

# Setup Azure OpenAI credentials
print("\n🔑 Setting up Azure OpenAI credentials...")
os.environ["AZURE_OPENAI_API_KEY"] = "2jy7NXTiqGiD2jz0BWMPEWkrS4MO2JmO1sKmsCv0NTlQ9z0Hd6tZJQQJ99CAACYeBjFXJ3w3AAABACOGX9Sf"
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://eastus.api.cognitive.microsoft.com/"
os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = "gpt-4o"
os.environ["AZURE_OPENAI_API_VERSION"] = "2024-08-01-preview"

# Add backend to path
backend_dir = Path(__file__).parent
sys.path.insert(0, str(backend_dir))

from app.bsd_v2.single_agent_coach import handle_conversation
from app.bsd_v2.state_schema_v2 import create_initial_state

def print_separator():
    print("\n" + "━" * 80)

def simulate_short_conversation():
    """סימולציה קצרה: S3→S4→S5"""
    
    print("\n" + "=" * 80)
    print("🧪 BSD V2 - Short Simulation (S3→S4→S5)")
    print("=" * 80)
    print("\n🎯 Focus: Testing emotion collection + transition gates")
    
    # Initialize state with pre-filled S2 data
    state = create_initial_state(
        conversation_id="test_short",
        user_id="test_user"
    )
    
    # Pre-fill with S2 data
    state["current_step"] = "S3"
    state["collected_data"]["topic"] = "חוסר חיבור בזוגיות"
    state["collected_data"]["event"] = "אתמול בערב ישבנו ביחד והיא ניסתה לספר לי על היום שלה ואני הייתי בטלפון"
    state["saturation_score"] = 0.0
    
    # Conversation flow - starting from S3
    conversation_flow = [
        # S3: Emotions
        {
            "user_msg": "הרגשתי אשם",
            "expected": "מה עוד? (1/4 רגשות)"
        },
        {
            "user_msg": "גם תסכול",
            "expected": "מה עוד? (2/4 רגשות)"
        },
        {
            "user_msg": "כעס על עצמי",
            "expected": "מה עוד? (3/4 רגשות)"
        },
        {
            "user_msg": "עצב",
            "expected": "4 רגשות! → מעבר ל-S4"
        },
        
        # S4: Thought
        {
            "user_msg": "חשבתי שאני בעל לא טוב",
            "expected": "משפט מחשבה ✅ → מעבר ל-S5"
        },
        
        # S5: Action
        {
            "user_msg": "המשכתי לגלול בטלפון",
            "expected": "מעשה בפועל ✅ → שאלה על רצוי"
        },
        {
            "user_msg": "הייתי רוצה להניח את הטלפון ולהקשיב",
            "expected": "רצוי ✅ → סיכום המצוי"
        },
    ]
    
    # Run conversation
    import asyncio
    for i, turn in enumerate(conversation_flow, 1):
        print_separator()
        print(f"Turn {i}")
        print_separator()
        print(f"👤 User: {turn['user_msg']}")
        print(f"📋 Expected: {turn['expected']}")
        
        try:
            # Get coach response
            coach_message, updated_state = asyncio.run(
                handle_conversation(
                    user_message=turn['user_msg'],
                    state=state,
                    language="he"
                )
            )
            
            # Update state
            state = updated_state
            
            # Print response
            print(f"\n🤖 Coach:")
            print(f"   {coach_message}")
            
            # Print state
            print(f"\n📊 State:")
            print(f"   Stage: {state['current_step']}")
            print(f"   Saturation: {state['saturation_score']:.2f}")
            
            # Print emotions if in S3/S4
            if state['collected_data'].get('emotions'):
                print(f"   Emotions: {state['collected_data']['emotions']} ({len(state['collected_data']['emotions'])}/4)")
            
            # Print thought if in S4/S5
            if state['collected_data'].get('thought'):
                print(f"   Thought: {state['collected_data']['thought']}")
            
            # Print actions if in S5
            if state['collected_data'].get('action_actual'):
                print(f"   Action (actual): {state['collected_data']['action_actual']}")
            if state['collected_data'].get('action_desired'):
                print(f"   Action (desired): {state['collected_data']['action_desired']}")
                
        except Exception as e:
            print(f"\n❌ Error: {e}")
            import traceback
            traceback.print_exc()
            break
    
    print("\n" + "=" * 80)
    print("✅ Simulation Complete")
    print("=" * 80)

if __name__ == "__main__":
    simulate_short_conversation()
