#!/usr/bin/env python3
"""
Test S2→S3 Transition: Event Depth Check
=========================================

This script simulates a conversation to check if the coach properly
explores the event in S2 before moving to S3 (emotions).

Expected behavior:
- Coach should ask 2-3 questions about the event
- Should get details: when, where, who, what happened
- Should NOT jump to emotions too quickly
"""

import asyncio
import json
import sys
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent))

from app.bsd_v2.single_agent_coach import handle_conversation
from app.bsd_v2.state_schema_v2 import create_initial_state


def print_turn(turn_num: int, user_msg: str, coach_msg: str, step: str, saturation: float):
    """Pretty print a conversation turn"""
    print(f"\n{'='*80}")
    print(f"Turn {turn_num} | Step: {step} | Saturation: {saturation:.2f}")
    print(f"{'='*80}")
    print(f"💬 משתמש: {user_msg}")
    print(f"🎓 מאמן: {coach_msg}")


async def test_s2_depth():
    """Test S2 depth - should NOT jump to emotions too quickly"""
    
    print("\n" + "="*80)
    print("🧪 TEST: S2→S3 Transition (Event Depth)")
    print("="*80)
    print("Goal: Coach should explore the event in detail before moving to emotions")
    print()
    
    # Initialize state
    state = create_initial_state(
        conversation_id="test_s2_depth",
        user_id="test_user",
        language="he"
    )
    
    # Conversation simulation
    turns = [
        # S1: Topic clarification
        ("זוגיות", "Expected: Ask 'מה בזוגיות?'"),
        ("להיות יותר רגיש", "Expected: Ask more about sensitivity or move to S2"),
        
        # S2: Event collection - THIS IS WHERE WE TEST
        ("ביום שישי חזרתי הביתה ולא הבאתי פרחים", "Expected: DON'T jump to emotions! Ask for more details about the event!"),
        # The coach should ask: "ספר לי יותר", "איפה הייתם?", "מה ראית?", etc.
    ]
    
    for turn_num, (user_msg, expectation) in enumerate(turns, 1):
        print(f"\n{'─'*80}")
        print(f"Turn {turn_num}: {expectation}")
        print(f"{'─'*80}")
        
        # Get coach response
        coach_msg, state = await handle_conversation(user_msg, state, language="he")
        
        # Print turn
        print_turn(
            turn_num,
            user_msg,
            coach_msg,
            state["current_step"],
            state["saturation_score"]
        )
        
        # Check if coach jumped to S3 too early
        if turn_num == 3:
            if state["current_step"] == "S3":
                print("\n❌ FAIL: Coach jumped to S3 (emotions) too early!")
                print("   The event was described in just 1 sentence - that's too shallow!")
                print("   Expected: Coach should ask for more details about the event")
                return False
            elif state["current_step"] == "S2":
                print("\n✅ GOOD: Coach is still in S2, exploring the event")
                # Continue with more details
                print("\n📝 Providing more details...")
                
                user_msg2 = "בכניסה לבית, היא חיכתה לי בסלון"
                coach_msg2, state = await handle_conversation(user_msg2, state, language="he")
                print_turn(turn_num + 1, user_msg2, coach_msg2, state["current_step"], state["saturation_score"])
                
                user_msg3 = "ראיתי את המבט שלה, שאלה בקול שקט 'הכל בסדר?'"
                coach_msg3, state = await handle_conversation(user_msg3, state, language="he")
                print_turn(turn_num + 2, user_msg3, coach_msg3, state["current_step"], state["saturation_score"])
                
                # Now check if coach moves to S3
                if "מה הרגשת" in coach_msg3.lower() or "רגש" in coach_msg3.lower():
                    print("\n✅ PASS: Coach explored the event in depth (3 exchanges) before moving to emotions!")
                    return True
                else:
                    print("\n⚠️  WARNING: Coach hasn't moved to emotions yet. Let's continue...")
                    return True
    
    print("\n✅ Test completed")
    return True


async def main():
    """Run the test"""
    try:
        success = await test_s2_depth()
        
        print("\n" + "="*80)
        if success:
            print("✅ TEST PASSED: S2 depth is properly validated")
        else:
            print("❌ TEST FAILED: Coach jumps to emotions too quickly")
        print("="*80)
        
        sys.exit(0 if success else 1)
        
    except Exception as e:
        print(f"\n❌ Error running test: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
