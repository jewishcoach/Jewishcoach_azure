"""
סימולציה מלאה של V2 - כל המסע (S7→S12)
==========================================

בודק:
- S7: דפוס חוזר
- S8: רווח והפסד
- S9: כוחות (ערכים + יכולות)
- S10: בחירה
- S11: חזון
- S12: מחויבות קונקרטית
"""

import os
import sys
import time
from pathlib import Path

# Setup Azure OpenAI credentials
os.environ["AZURE_OPENAI_API_KEY"] = "2jy7NXTiqGiD2jz0BWMPEWkrS4MO2JmO1sKmsCv0NTlQ9z0Hd6tZJQQJ99CAACYeBjFXJ3w3AAABACOGX9Sf"
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://eastus.api.cognitive.microsoft.com/"
os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = "gpt-4o"
os.environ["AZURE_OPENAI_API_VERSION"] = "2024-08-01-preview"

backend_dir = Path(__file__).parent
sys.path.insert(0, str(backend_dir))

print("🔧 Importing...", flush=True)
from app.bsd_v2.single_agent_coach import handle_conversation
from app.bsd_v2.state_schema_v2 import create_initial_state
print("✅ Ready!", flush=True)

def simulate_full_journey():
    print("\n" + "=" * 80, flush=True)
    print("🧪 BSD V2 - Full Journey (S7→S12)", flush=True)
    print("=" * 80, flush=True)
    
    # Pre-fill state with S6 data
    state = create_initial_state("test_journey", "test_user")
    state["current_step"] = "S7"
    state["collected_data"]["topic"] = "חוסר חיבור בזוגיות"
    state["collected_data"]["event"] = "אתמול בערב ישבנו ביחד והיא ניסתה לספר לי על היום שלה ואני הייתי בטלפון"
    state["collected_data"]["emotions"] = ["אשם", "תסכול", "כעס", "עצב"]
    state["collected_data"]["thought"] = "אני בעל לא טוב"
    state["collected_data"]["action_actual"] = "המשכתי לגלול בטלפון"
    state["collected_data"]["action_desired"] = "הייתי רוצה להניח את הטלפון ולהקשיב"
    state["collected_data"]["gap_name"] = "הפער בין כוונה למעשה"
    state["collected_data"]["gap_score"] = 8
    state["saturation_score"] = 0.5
    
    turns = [
        ("כן, זה קורה לי גם בעבודה ועם החברים", "S7: דפוס"),
        ("בעבודה אני מתעלם מפגישות, ועם חברים אני לא באמת נוכח", "S7→S8: רווח"),
        
        # S8: Stance - gains
        ("אני מרוויח שקט, לא צריך להתמודד", "S8: מה עוד רווח?"),
        ("גם ביטחון, לא להסתכן", "S8: הפסד?"),
        
        # S8: Stance - losses
        ("אני מפסיד חיבור אמיתי", "S8: מה עוד הפסד?"),
        ("קרבה, אהבה, להרגיש חי", "S8→S9: ערכים"),
        
        # S9: Forces - source (values)
        ("חיבור אמיתי חשוב לי, משפחה", "S9: מה עוד ערך?"),
        ("אהבה, כנות", "S9: יכולות"),
        
        # S9: Forces - nature (abilities)
        ("אני יודע להקשיב כשאני ממוקד", "S9: מה עוד יכולת?"),
        ("אני אמפתי, יודע לתת", "S9→S10: בחירה"),
        
        # S10: Renewal
        ("אני בוחר להיות נוכח, לתת את עצמי באמת", "S10→S11: חזון"),
        
        # S11: Vision
        ("זה מוביל אותי לחיבור עמוק עם אשתי, עם הילדים, להרגיש חי", "S11→S12: מחויבות"),
        
        # S12: Commitment
        ("בפעם הבאה שאשתי תדבר, אכבה את הטלפון ואסתכל לה בעיניים", "S12: בדיקה שזה קונקרטי"),
    ]
    
    import asyncio
    
    for i, (user_msg, expected) in enumerate(turns, 1):
        print(f"\n{'━' * 80}", flush=True)
        print(f"Turn {i}", flush=True)
        print(f"{'━' * 80}", flush=True)
        print(f"👤 User: {user_msg}", flush=True)
        print(f"📋 Expected: {expected}", flush=True)
        print(f"⏳ Calling LLM...", flush=True)
        
        start = time.time()
        
        try:
            coach_message, updated_state = asyncio.run(
                handle_conversation(
                    user_message=user_msg,
                    state=state,
                    language="he"
                )
            )
            
            elapsed = time.time() - start
            print(f"✅ LLM responded in {elapsed:.1f}s", flush=True)
            
            state = updated_state
            
            print(f"\n🤖 Coach:", flush=True)
            print(f"   {coach_message[:200]}...", flush=True)  # Truncate long responses
            
            print(f"\n📊 State:", flush=True)
            print(f"   Stage: {state['current_step']}", flush=True)
            print(f"   Saturation: {state['saturation_score']:.2f}", flush=True)
            
            # Show relevant collected data
            if state['collected_data']['stance']['gains']:
                print(f"   Gains: {state['collected_data']['stance']['gains']}", flush=True)
            if state['collected_data']['stance']['losses']:
                print(f"   Losses: {state['collected_data']['stance']['losses']}", flush=True)
            if state['collected_data']['forces']['source']:
                print(f"   Values: {state['collected_data']['forces']['source']}", flush=True)
            if state['collected_data']['forces']['nature']:
                print(f"   Abilities: {state['collected_data']['forces']['nature']}", flush=True)
            if state['collected_data']['renewal']:
                print(f"   Renewal: {state['collected_data']['renewal']}", flush=True)
            if state['collected_data']['vision']:
                print(f"   Vision: {state['collected_data']['vision'][:100]}...", flush=True)
            if state['collected_data']['commitment']:
                print(f"   Commitment: {state['collected_data']['commitment'][:100]}...", flush=True)
                
        except Exception as e:
            elapsed = time.time() - start
            print(f"❌ Error after {elapsed:.1f}s: {e}", flush=True)
            import traceback
            traceback.print_exc()
            break
    
    print("\n" + "=" * 80, flush=True)
    print("✅ Simulation Complete", flush=True)
    print("=" * 80, flush=True)
    
    print("\n📊 Final Summary:", flush=True)
    print(f"   Stage: {state['current_step']}", flush=True)
    print(f"   Gains: {len(state['collected_data']['stance']['gains'])}", flush=True)
    print(f"   Losses: {len(state['collected_data']['stance']['losses'])}", flush=True)
    print(f"   Values: {len(state['collected_data']['forces']['source'])}", flush=True)
    print(f"   Abilities: {len(state['collected_data']['forces']['nature'])}", flush=True)
    print(f"   Has renewal: {bool(state['collected_data']['renewal'])}", flush=True)
    print(f"   Has vision: {bool(state['collected_data']['vision'])}", flush=True)
    print(f"   Has commitment: {bool(state['collected_data']['commitment'])}", flush=True)

if __name__ == "__main__":
    print("🚀 Starting full journey simulation...", flush=True)
    simulate_full_journey()
    print("🏁 Done!", flush=True)
