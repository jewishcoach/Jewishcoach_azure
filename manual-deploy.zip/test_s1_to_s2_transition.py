"""
בדיקת מעבר S1→S2
==================
סימולציה של השיחה שהמשתמש הראה
"""

import os
import sys
import asyncio
from pathlib import Path

# Setup Azure OpenAI credentials
os.environ["AZURE_OPENAI_API_KEY"] = "ClzxbrMW7mWJpsYxbTcp6D3IppuNnDu2R2nGFyWcHIGjYhVAtmHKJQQJ99CAACYeBjFXJ3w3AAABACOGhPLX"
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://eastus.api.cognitive.microsoft.com/"
os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = "gpt-4o"
os.environ["AZURE_OPENAI_API_VERSION"] = "2024-02-15-preview"

# Add backend to path
backend_dir = Path(__file__).parent
sys.path.insert(0, str(backend_dir))

from app.bsd_v2.single_agent_coach import handle_conversation
from app.bsd_v2.state_schema_v2 import create_initial_state

async def simulate():
    print("\n" + "=" * 80)
    print("🧪 בדיקת מעבר S1→S2")
    print("=" * 80)
    
    state = create_initial_state("test", "user1")
    
    # השיחה שהמשתמש הראה
    turns = [
        ("הייתי רוצה על זוגיות", "S1: נושא כללי"),
        ("אתה יכול להסביר מה כוונתך?", "S1: הבהרה (לא רצוי)"),
        ("להיות רגיש יותר בזוגיות, אני חושב שאני לא טוב בזה", "S2: צריך לעבור למצוי!"),
    ]
    
    for i, (user_msg, expected) in enumerate(turns, 1):
        print("\n" + "━" * 80)
        print(f"Turn {i}")
        print("━" * 80)
        print(f"👤 User: {user_msg}")
        print(f"📋 Expected: {expected}")
        
        # Get coach response
        coach_message, state = await handle_conversation(user_msg, state, "he")
        
        step = state["current_step"]
        saturation = state["saturation_score"]
        
        print(f"\n🤖 Coach ({step}, sat={saturation:.2f}):")
        print(f"   {coach_message}")
        
        # בדיקת התנהגות
        if i == 3:
            if step == "S2":
                print("\n✅ מצוין! עבר ל-S2 כמו שצריך!")
                if "רגע אחד ספציפי" in coach_message or "פעם אחת" in coach_message:
                    print("✅ יש הסבר על מעבר למצוי!")
                else:
                    print("⚠️  חסר הסבר על מעבר למצוי")
            else:
                print(f"\n❌ בעיה! נשאר ב-{step} במקום לעבור ל-S2")
                if "מה ב" in coach_message or "מה הכוונה" in coach_message:
                    print("❌ המערכת חוזרת על עצמה!")
    
    print("\n" + "=" * 80)
    print("סיכום")
    print("=" * 80)
    print(f"שלב סופי: {state['current_step']}")
    print(f"Saturation: {state['saturation_score']:.2f}")
    print(f"הודעות: {len(state['messages'])}")

if __name__ == "__main__":
    asyncio.run(simulate())
