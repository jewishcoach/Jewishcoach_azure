#!/usr/bin/env python3
"""
Simple test: Send actual HTTP requests to the running server.
"""

import requests
import json
import time

BASE_URL = "http://localhost:8000"

def create_session():
    """Create a new coaching session."""
    response = requests.post(
        f"{BASE_URL}/api/bsd/sessions",
        json={"user_name": "ישי", "user_gender": "male"},
        timeout=10
    )
    response.raise_for_status()
    return response.json()["session_id"]

def send_message(session_id, message):
    """Send a message and get coach response."""
    print(f"\n{'='*80}")
    print(f"👤 User: {message}")
    print(f"{'='*80}")
    
    response = requests.post(
        f"{BASE_URL}/api/bsd/sessions/{session_id}/message",
        json={"message": message},
        timeout=30
    )
    response.raise_for_status()
    data = response.json()
    
    print(f"🤖 Coach: {data.get('coach_message', 'NO MESSAGE')}")
    print(f"📊 Stage: {data.get('current_state')}, Loop: {data.get('loop_count', 0)}")
    
    return data

def main():
    print("=" * 80)
    print("🧪 TESTING STUCK-LOOP FIX (Live Server)")
    print("=" * 80)
    
    # Create session
    print("\n🔧 Creating session...")
    session_id = create_session()
    print(f"✅ Session created: {session_id}")
    
    # Conversation flow
    steps = [
        ("כן", "S0 -> S1: Consent"),
        ("הצלחה בזוגיות", "S1 -> S2: Topic"),
        ("הבעיה שאין לי זוגיות", "S2 Loop 1: General statement"),
        ("אני לא מצליח לצאת עם נשים אני מפחד", "S2 Loop 2: Still general"),
        ("יצאתי עם משהי והתרגשתי מאוד דברתי שטויות וכמובן הקשר נגמר :(", "S2 -> S3: Specific event"),
        ("מתי?", "S3 Loop 1: User confused"),
        ("באיזה רגע אתה מדבר?", "S3 Loop 2: User confused"),
        ("באיזה רגע אתה מדבר?", "🚨 S3 Loop 3: SHOULD TRIGGER ADAPTIVE RESPONSE!"),
    ]
    
    for idx, (message, description) in enumerate(steps, 1):
        print(f"\n\n{'#'*80}")
        print(f"# Step {idx}: {description}")
        print(f"{'#'*80}")
        
        response = send_message(session_id, message)
        
        # Check last step for adaptive indicators
        if idx == len(steps):
            print("\n" + "=" * 80)
            print("🔍 CRITICAL TEST: Loop 3 in S3")
            print("=" * 80)
            
            coach_msg = response.get("coach_message", "")
            
            # Check for adaptive indicators
            adaptive_indicators = [
                "אני רואה שלא הצלחתי",
                "בוא אסביר",
                "לדוגמה",
                "אני שואל את זה כי",
                "להבהיר"
            ]
            
            found = [ind for ind in adaptive_indicators if ind in coach_msg]
            
            if found:
                print("✅ SUCCESS! Adaptive response detected!")
                print(f"   Found indicators: {found}")
            else:
                print("⚠️  No clear adaptive indicators found")
            
            # Check if it's NOT hardcoded script
            if "אני מחפש רגשות — תחושות פנימיות" in coach_msg:
                print("❌ FAILURE! Still using hardcoded script!")
            else:
                print("✅ SUCCESS! Not using hardcoded script!")
            
            print(f"\nFull response: {coach_msg}")
        
        time.sleep(0.5)
    
    print("\n" + "=" * 80)
    print("🧪 TEST COMPLETE")
    print("=" * 80)

if __name__ == "__main__":
    try:
        main()
    except requests.exceptions.ConnectionError:
        print("❌ ERROR: Could not connect to server. Is it running on localhost:8000?")
    except Exception as e:
        print(f"❌ ERROR: {e}")
        import traceback
        traceback.print_exc()

