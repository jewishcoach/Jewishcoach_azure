"""
BSD Coaching Simulator - Testing "Mcuy" Stages (S2-S5)
======================================================

Tests the flow through:
- S2: Event (אירוע)
- S3: Emotion Screen (מסך הרגש)
- S4: Thought Screen (מסך המחשבה)  
- S5: Action Screen (מסך המעשה - actual + desired)

With 10 different user personas:
1. Regular user (smooth flow)
2. Confused user (asks clarifying questions)
3. User who doesn't understand emotions
4. User who gives goals instead of emotions
5. User who asks methodology questions
6. User who gives generic answers
7. User who corrects themselves
8. User with minimal answers
9. User who mixes topics
10. User who gives actions instead of thoughts
"""

import asyncio
import sys
from typing import List, Dict, Any
from datetime import datetime
import json

sys.path.insert(0, '.')
from dotenv import load_dotenv
load_dotenv()

from app.bsd.engine import BsdEngine
from app.database import SessionLocal

# ==========================================
# TEST SCENARIOS
# ==========================================

SCENARIOS = [
    {
        "name": "Scenario 1: Regular User (Smooth Flow)",
        "description": "User understands instructions and provides clear answers",
        "user_profile": {"name": "דוד", "gender": "male"},
        "conversation": [
            ("כן", "S0 consent"),
            ("ניהול כעסים", "S1 topic"),
            ("אתמול צעקתי על הילד שלי כשהוא לא הקשיב לי", "S2 event"),
            ("כעס, תסכול, אשמה", "S3 emotions"),
            ("אני אב רע, אני לא טוב מספיק", "S4 thought"),
            ("צעקתי עליו ואמרתי לו ללכת לחדר", "S5 actual"),
            ("הייתי רוצה לנשום עמוק ולדבר איתו בשקט", "S5 desired")
        ]
    },
    
    {
        "name": "Scenario 2: Confused User (Asks Questions)",
        "description": "User asks clarifying questions during the process",
        "user_profile": {"name": "שרה", "gender": "female"},
        "conversation": [
            ("כן בטח", "S0 consent"),
            ("עבודה", "S1 topic - too broad"),
            ("קונפליקט עם הבוס", "S1 clarification"),
            ("מה זאת אומרת רגע ספציפי?", "S2 clarification about event"),
            ("אוקיי, השבוע הבוס ביקר ממני דו\"ח ואני לא הספקתי", "S2 event"),
            ("לחוץ, כעס", "S3 emotions - not enough"),
            ("גם פחד", "S3 more emotions"),
            ("הבוס לא מעריך אותי", "S4 thought"),
            ("אמרתי לו שאני עסוקה ואנסה למחר", "S5 actual"),
            ("הייתי רוצה להגיד שאני צריכה עוד יום ולהציע פתרון", "S5 desired")
        ]
    },
    
    {
        "name": "Scenario 3: Doesn't Understand Emotions",
        "description": "User confuses emotions with actions or thoughts",
        "user_profile": {"name": "משה", "gender": "male"},
        "conversation": [
            ("כן", "S0 consent"),
            ("זוגיות", "S1 topic - too broad"),
            ("ריב עם אשתי", "S1 clarification"),
            ("אשתי אמרה שאני לא עוזר בבית ואני התעצבנתי", "S2 event"),
            ("לא הבנתי", "S3 - doesn't understand"),
            ("כעס", "S3 - one emotion"),
            ("תסכול, עצב", "S3 - more emotions"),
            ("היא לא רואה כמה אני עובד קשה", "S4 thought"),
            ("אמרתי לה שהיא תמיד מתלוננת", "S5 actual"),
            ("הייתי רוצה לשאול אותה איך אני יכול לעזור", "S5 desired")
        ]
    },
    
    {
        "name": "Scenario 4: Gives Goals Instead of Emotions",
        "description": "User tries to give aspirations instead of emotions",
        "user_profile": {"name": "רחל", "gender": "female"},
        "conversation": [
            ("כן", "S0 consent"),
            ("הורות", "S1 topic - too broad"),
            ("להיות אמא יותר טובה", "S1 goal - needs topic"),
            ("בושה עם הילדים", "S1 topic"),
            ("הילדה התבישה מולי כשצעקתי עליה בפני החברות", "S2 event"),
            ("רוצה להיות אמא טובה", "S3 - goal, not emotion!"),
            ("תסכול, בושה, אשמה", "S3 emotions"),
            ("אני פוגעת בה", "S4 thought"),
            ("צעקתי עליה ואמרתי לה ללכת הביתה", "S5 actual"),
            ("הייתי רוצה לחכות שהחברות ילכו ואז לדבר איתה", "S5 desired")
        ]
    },
    
    {
        "name": "Scenario 5: Asks Methodology Questions",
        "description": "User asks about the coaching process itself",
        "user_profile": {"name": "יוסי", "gender": "male"},
        "conversation": [
            ("כן, אבל מה זה תהליך השיבה?", "S0 with methodology question"),
            ("הקשבה לאישה", "S1 topic"),
            ("למה אתה שואל על אירוע? מה זה אמור לעזור?", "S2 methodology question"),
            ("אוקיי, אתמול האישה סיפרה לי על היום שלה ואני הסתכלתי בטלפון", "S2 event"),
            ("אשמה, אי נוחות", "S3 emotions - not enough"),
            ("גם עצב", "S3 more emotions"),
            ("אני לא מספיק טוב בתור בעל", "S4 thought"),
            ("מה אמור לעזור לי לדעת מה חשבתי?", "S4 methodology question"),
            ("המשכתי לגלול בטלפון", "S5 actual"),
            ("הייתי רוצה לשים את הטלפון ולהסתכל עליה", "S5 desired")
        ]
    },
    
    {
        "name": "Scenario 6: Generic/Vague Answers",
        "description": "User gives general answers that need clarification",
        "user_profile": {"name": "אסתר", "gender": "female"},
        "conversation": [
            ("כן", "S0 consent"),
            ("משהו עם הילדים", "S1 unclear"),
            ("הורות", "S1 broad"),
            ("כעסים", "S1 clarification"),
            ("היה משהו עם הבן", "S2 too vague"),
            ("הוא לא שמע", "S2 still vague"),
            ("אתמול ביקשתי ממנו לעשות שיעורים והוא התעלם", "S2 event"),
            ("רע", "S3 - not specific emotion"),
            ("כעס, תסכול, חוסר אונים", "S3 emotions"),
            ("הוא לא מכבד אותי", "S4 thought"),
            ("עשיתי משהו", "S5 vague"),
            ("צעקתי עליו", "S5 actual"),
            ("לדבר איתו ברוגע", "S5 desired")
        ]
    },
    
    {
        "name": "Scenario 7: Corrects Themselves",
        "description": "User makes mistakes and corrects them",
        "user_profile": {"name": "אברהם", "gender": "male"},
        "conversation": [
            ("כן", "S0 consent"),
            ("עבודה", "S1 broad"),
            ("קונפליקט עם עמית", "S1 topic"),
            ("היה ויכוח", "S2 vague"),
            ("רגע טעות, זה היה אתמול", "S2 correction"),
            ("אתמול העמית שלי אמר שאני לא עושה את החלק שלי בפרויקט", "S2 event"),
            ("כעס, תסכול", "S3 not enough"),
            ("טעות, גם בושה", "S3 correction"),
            ("גם פחד", "S3 more emotions"),
            ("אני לא מספיק טוב", "S4 thought"),
            ("אמרתי לו שהוא לא צודק", "S5 actual"),
            ("רגע, למעשה התחלתי לצעוק עליו", "S5 correction actual"),
            ("הייתי רוצה לשאול אותו מה הוא מתכוון", "S5 desired")
        ]
    },
    
    {
        "name": "Scenario 8: Minimal Answers",
        "description": "User gives very short, minimal answers",
        "user_profile": {"name": "לאה", "gender": "female"},
        "conversation": [
            ("כן", "S0 consent"),
            ("עבודה", "S1 broad"),
            ("לחץ", "S1 unclear"),
            ("לחץ בעבודה עם הבוסית", "S1 topic"),
            ("היא צעקה", "S2 too short"),
            ("אתמול הבוסית צעקה עלי בפגישה", "S2 event"),
            ("כעס", "S3 one emotion"),
            ("בושה", "S3 another"),
            ("פחד", "S3 another"),
            ("תסכול", "S3 fourth emotion"),
            ("אני כישלון", "S4 thought"),
            ("שתקתי", "S5 actual"),
            ("לומר משהו", "S5 desired - vague"),
            ("הייתי רוצה להגיד שאני לא מסכימה", "S5 desired clear")
        ]
    },
    
    {
        "name": "Scenario 9: Mixes Topics/Jumps Around",
        "description": "User gives multiple topics or jumps between subjects",
        "user_profile": {"name": "דניאל", "gender": "male"},
        "conversation": [
            ("כן", "S0 consent"),
            ("הורות וגם עבודה", "S1 multiple topics"),
            ("הורות", "S1 broad"),
            ("יש לי בעיה עם הבן אבל גם עם הבת", "S1 multiple issues"),
            ("בן", "S1 narrowing"),
            ("ריב עם הבן על שיעורים", "S1 topic"),
            ("היה ריב, הוא לא רצה לעשות שיעורים, אבל גם באופן כללי הוא לא מכבד", "S2 event mixed"),
            ("תן דוגמה לרגע ספציפי אחד", "S2 clarification"),
            ("אתמול ביקשתי ממנו לעשות שיעורים והוא אמר לא", "S2 event"),
            ("כעס, גם עצב על מה שקורה עם הבת", "S3 mixed topics"),
            ("כעס, תסכול, אכזבה", "S3 emotions focused"),
            ("הוא לא יצליח בחיים", "S4 thought"),
            ("צעקתי עליו ואמרתי לו שהוא עצלן", "S5 actual"),
            ("הייתי רוצה לשאול אותו למה הוא לא רוצה", "S5 desired")
        ]
    },
    
    {
        "name": "Scenario 10: Gives Actions Instead of Thoughts",
        "description": "User confuses S4 (thoughts) with S5 (actions)",
        "user_profile": {"name": "מרים", "gender": "female"},
        "conversation": [
            ("כן", "S0 consent"),
            ("זוגיות", "S1 broad"),
            ("תקשורת עם בעל", "S1 topic"),
            ("הבעל לא מדבר איתי", "S2 not specific"),
            ("אתמול ניסיתי לדבר איתו והוא הלך לחדר", "S2 event"),
            ("עצב, כעס, בדידות", "S3 emotions - good"),
            ("צעקתי עליו", "S4 action, not thought!"),
            ("מה חשבת באותו רגע?", "S4 clarification"),
            ("הוא לא אוהב אותי", "S4 thought"),
            ("צעקתי עליו והלכתי לסלון", "S5 actual"),
            ("הייתי רוצה לומר לו שזה כואב לי", "S5 desired")
        ]
    }
]

# ==========================================
# SIMULATOR ENGINE
# ==========================================

class ConversationSimulator:
    def __init__(self):
        self.db = SessionLocal()
        self.engine = BsdEngine()
        self.results = []
    
    async def run_scenario(self, scenario: Dict[str, Any]) -> Dict[str, Any]:
        """Run a single conversation scenario"""
        print(f"\n{'='*70}")
        print(f"🧪 {scenario['name']}")
        print(f"📝 {scenario['description']}")
        print(f"{'='*70}\n")
        
        user_profile = scenario["user_profile"]
        conversation = scenario["conversation"]
        
        # Create conversation in DB
        from app.models import Conversation, User
        
        # Get or create test user
        test_user = self.db.query(User).filter(User.email == "simulator@test.com").first()
        if not test_user:
            test_user = User(
                clerk_id="test_simulator",
                email="simulator@test.com",
                display_name=user_profile["name"],
                gender=user_profile["gender"]
            )
            self.db.add(test_user)
            self.db.commit()
            self.db.refresh(test_user)
        
        # Create conversation
        conv = Conversation(
            user_id=test_user.id,
            title=scenario['name']
        )
        self.db.add(conv)
        self.db.commit()
        self.db.refresh(conv)
        
        # Track conversation
        turns = []
        issues = []
        current_stage = "S0"
        
        for i, (user_input, expected_context) in enumerate(conversation):
            turn_num = i + 1
            
            print(f"{'─'*70}")
            print(f"Turn {turn_num}: Stage {current_stage}")
            print(f"Expected: {expected_context}")
            print(f"{'─'*70}")
            print(f"👤 User: {user_input}")
            
            try:
                # Run coaching turn
                coach_response, metadata = await self.engine.run_turn(
                    db=self.db,
                    conversation_id=conv.id,
                    user_message=user_input,
                    language="he",
                    user_name=user_profile["name"],
                    user_gender=user_profile["gender"]
                )
                
                # Extract stage and intent
                new_stage = metadata.get("bsd_stage", current_stage)
                intent = metadata.get("intent", "UNKNOWN")
                decision = metadata.get("decision", "UNKNOWN")
                critique = metadata.get("critique", "")
                
                print(f"🤖 Coach: {coach_response[:150]}...")
                print(f"   Stage: {current_stage} → {new_stage}")
                print(f"   Intent: {intent}, Decision: {decision}")
                if critique:
                    print(f"   Critique: {critique}")
                
                # Detect issues
                turn_issues = self._detect_issues(
                    user_input=user_input,
                    coach_response=coach_response,
                    current_stage=current_stage,
                    new_stage=new_stage,
                    intent=intent,
                    decision=decision,
                    critique=critique,
                    expected_context=expected_context
                )
                
                if turn_issues:
                    print(f"⚠️  Issues detected:")
                    for issue in turn_issues:
                        print(f"   - {issue}")
                        issues.append({"turn": turn_num, "issue": issue})
                else:
                    print(f"✅ Turn looks good!")
                
                # Record turn
                turns.append({
                    "turn": turn_num,
                    "stage": current_stage,
                    "user_input": user_input,
                    "coach_response": coach_response[:200],
                    "intent": intent,
                    "decision": decision,
                    "critique": critique,
                    "new_stage": new_stage,
                    "expected": expected_context,
                    "issues": turn_issues
                })
                
                current_stage = new_stage
                
                # Small delay
                await asyncio.sleep(0.1)
                
            except Exception as e:
                error_msg = f"ERROR: {str(e)}"
                print(f"❌ {error_msg}")
                issues.append({"turn": turn_num, "issue": error_msg})
                turns.append({
                    "turn": turn_num,
                    "stage": current_stage,
                    "user_input": user_input,
                    "coach_response": "ERROR",
                    "error": str(e),
                    "expected": expected_context
                })
        
        # Summary
        print(f"\n{'='*70}")
        print(f"📊 SCENARIO SUMMARY: {scenario['name']}")
        print(f"{'='*70}")
        print(f"Total turns: {len(turns)}")
        print(f"Final stage: {current_stage}")
        print(f"Issues found: {len(issues)}")
        
        if issues:
            print(f"\n⚠️  Issues:")
            for issue_data in issues:
                print(f"   Turn {issue_data['turn']}: {issue_data['issue']}")
        else:
            print(f"\n✅ No issues! Perfect flow!")
        
        return {
            "scenario": scenario['name'],
            "description": scenario['description'],
            "turns": turns,
            "issues": issues,
            "final_stage": current_stage,
            "success": len(issues) == 0
        }
    
    def _detect_issues(
        self,
        user_input: str,
        coach_response: str,
        current_stage: str,
        new_stage: str,
        intent: str,
        decision: str,
        critique: str,
        expected_context: str
    ) -> List[str]:
        """Detect potential issues in the turn"""
        issues = []
        
        # Issue 1: Stuck in same stage with ANSWER_OK
        if decision == "advance" and current_stage == new_stage:
            issues.append(f"Decided to ADVANCE but stayed in {current_stage}")
        
        # Issue 2: Advanced without OK
        if new_stage != current_stage and intent != "ANSWER_OK":
            issues.append(f"Advanced from {current_stage} to {new_stage} without ANSWER_OK")
        
        # Issue 3: Generic/robotic response
        robotic_phrases = ["נראה שזו תשובה שלא מתאימה", "בואו ננסה שוב", "שאלה טובה! אשמח"]
        if any(phrase in coach_response for phrase in robotic_phrases):
            # Check if it's actually appropriate
            if "clarification" not in expected_context.lower() and "question" not in expected_context.lower():
                issues.append("Robotic/generic response when expecting specific guidance")
        
        # Issue 4: S3 - Not rejecting invalid emotions
        if current_stage == "S3":
            invalid_emotion_words = ["רוצה", "goal", "want", "להיות", "אעשה"]
            if any(word in user_input for word in invalid_emotion_words):
                if "רגש" not in coach_response and "emotion" not in coach_response.lower():
                    issues.append("S3: User gave non-emotion but coach didn't correct")
        
        # Issue 5: S4 - Not rejecting actions
        if current_stage == "S4":
            action_words = ["צעקתי", "עשיתי", "אמרתי", "הלכתי"]
            if any(word in user_input for word in action_words):
                if "חשבת" not in coach_response and "thought" not in coach_response.lower():
                    issues.append("S4: User gave action but coach didn't ask for thought")
        
        # Issue 6: Not handling methodology questions
        if "מה זה" in user_input or "למה אתה" in user_input or "מה זה אמור" in user_input:
            if intent != "METHODOLOGY_CLARIFY" and "CLARIFY" not in intent:
                issues.append("User asked methodology question but not classified as CLARIFY")
        
        # Issue 7: Not handling corrections
        if "טעות" in user_input or "רגע" in user_input:
            if "correction" not in expected_context.lower():
                if "מצטער" not in coach_response and "sorry" not in coach_response.lower():
                    issues.append("User corrected themselves but coach didn't acknowledge")
        
        return issues
    
    def close(self):
        """Close DB connection"""
        self.db.close()

# ==========================================
# MAIN EXECUTION
# ==========================================

async def main():
    print("\n" + "="*70)
    print("🎯 BSD COACHING SIMULATOR - Mcuy Stages (S2-S5)")
    print("="*70)
    print(f"Testing {len(SCENARIOS)} scenarios")
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    simulator = ConversationSimulator()
    all_results = []
    
    for i, scenario in enumerate(SCENARIOS, 1):
        print(f"\n\n{'#'*70}")
        print(f"# Scenario {i}/{len(SCENARIOS)}")
        print(f"{'#'*70}")
        
        result = await simulator.run_scenario(scenario)
        all_results.append(result)
        
        # Small delay between scenarios
        await asyncio.sleep(0.5)
    
    simulator.close()
    
    # FINAL REPORT
    print(f"\n\n{'='*70}")
    print(f"📊 FINAL REPORT - ALL SCENARIOS")
    print(f"{'='*70}\n")
    
    total_scenarios = len(all_results)
    successful_scenarios = sum(1 for r in all_results if r["success"])
    total_issues = sum(len(r["issues"]) for r in all_results)
    
    print(f"Total Scenarios: {total_scenarios}")
    print(f"Successful: {successful_scenarios}/{total_scenarios} ({successful_scenarios/total_scenarios*100:.1f}%)")
    print(f"Total Issues: {total_issues}")
    
    print(f"\n{'─'*70}")
    print("Scenario Breakdown:")
    print(f"{'─'*70}")
    
    for i, result in enumerate(all_results, 1):
        status = "✅" if result["success"] else "❌"
        print(f"{status} {i}. {result['scenario']}")
        print(f"   Final Stage: {result['final_stage']}, Issues: {len(result['issues'])}")
        if result['issues']:
            for issue_data in result['issues'][:3]:  # Show first 3 issues
                print(f"      - Turn {issue_data['turn']}: {issue_data['issue']}")
    
    # Key findings
    print(f"\n{'─'*70}")
    print("🔍 Key Findings:")
    print(f"{'─'*70}")
    
    # Group issues by type
    issue_types = {}
    for result in all_results:
        for issue_data in result['issues']:
            issue_text = issue_data['issue']
            # Extract issue type
            if ":" in issue_text:
                issue_type = issue_text.split(":")[0]
            else:
                issue_type = issue_text[:50]
            
            issue_types[issue_type] = issue_types.get(issue_type, 0) + 1
    
    if issue_types:
        print("\nMost Common Issues:")
        for issue_type, count in sorted(issue_types.items(), key=lambda x: -x[1])[:5]:
            print(f"   {count}x: {issue_type}")
    else:
        print("\n✅ No issues found! System working perfectly!")
    
    # Recommendations
    print(f"\n{'─'*70}")
    print("💡 Recommendations:")
    print(f"{'─'*70}")
    
    recommendations = []
    
    if any("S3:" in str(r['issues']) for r in all_results):
        recommendations.append("Strengthen S3 emotion validation")
    if any("S4:" in str(r['issues']) for r in all_results):
        recommendations.append("Improve S4 thought vs action distinction")
    if any("methodology" in str(r['issues']).lower() for r in all_results):
        recommendations.append("Enhance methodology question detection")
    if any("correction" in str(r['issues']).lower() for r in all_results):
        recommendations.append("Better handling of user corrections")
    if any("generic" in str(r['issues']).lower() or "robotic" in str(r['issues']).lower() for r in all_results):
        recommendations.append("Reduce generic/robotic responses")
    
    if recommendations:
        for i, rec in enumerate(recommendations, 1):
            print(f"   {i}. {rec}")
    else:
        print("   ✅ System performing well across all scenarios!")
    
    print(f"\n{'='*70}")
    print(f"Completed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*70}\n")

if __name__ == "__main__":
    asyncio.run(main())

