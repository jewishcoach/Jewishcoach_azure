#!/usr/bin/env python3
"""
Test: Don't Repeat Questions
=============================

This script tests that the coach doesn't ask the same questions twice.
Based on the real conversation where the coach kept asking "איפה הייתם?" 
even after the user already said "בחדר שלנו".

Expected behavior:
- Coach should read the history carefully
- Should NOT ask questions that were already answered
- If user says "אמרתי כבר" - apologize and move on
"""

import asyncio
import sys
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent))

from app.bsd_v2.single_agent_coach import handle_conversation
from app.bsd_v2.state_schema_v2 import create_initial_state


def print_turn(turn_num: int, user_msg: str, coach_msg: str, step: str):
    """Pretty print a conversation turn"""
    print(f"\n{'='*80}")
    print(f"Turn {turn_num} | Step: {step}")
    print(f"{'='*80}")
    print(f"💬 משתמש: {user_msg}")
    print(f"🎓 מאמן: {coach_msg}")


async def test_no_repeat_questions():
    """Test that coach doesn't repeat questions"""
    
    print("\n" + "="*80)
    print("🧪 TEST: No Repeated Questions")
    print("="*80)
    print("Simulating the real conversation that failed")
    print()
    
    # Initialize state
    state = create_initial_state(
        conversation_id="test_repeat",
        user_id="test_user",
        language="he"
    )
    
    # The exact conversation from the user's complaint
    turns = [
        # S1
        ("זוגיות", None),
        ("על יכולת רגשית, כלומר לבטא רגש", None),
        ("הייתי רוצה להיות מסוגל לשתף רגשות ולהיות רגיש יותר לבת זוג", None),
        
        # S2 - The problematic part
        ("היה לנו שיחה אינטמית, והיא בעיקר דברה ואני הרגשתי קושי לשתף אותה", None),
        ("היינו בחדר שלנו, דברנו על משהו שקרה ואני התמקדתי בטכני בעוד שאשתי רצתה לדבר על המהות", None),
        ("כן, היא היתה מאוכזבת", None),
        ("היא אמרה בפירוש שהשיחה לא הולכת לכיוון שהיא חושבת עליו", None),
        
        # This is where the coach should NOT repeat questions
        # The coach should have enough info by now and move to S3
    ]
    
    for turn_num, (user_msg, _) in enumerate(turns, 1):
        coach_msg, state = await handle_conversation(user_msg, state, language="he")
        print_turn(turn_num, user_msg, coach_msg, state["current_step"])
        
        # Check for repeated questions
        if turn_num >= 5:  # After detailed event description
            # Check if coach is asking about location again
            if "איפה" in coach_msg and "הייתם" in coach_msg:
                print("\n❌ FAIL: Coach is asking 'איפה הייתם?' again!")
                print("   User already said 'היינו בחדר שלנו' in turn 5")
                return False
            
            # Check if coach is asking "ספר לי עוד" without specific direction
            if turn_num == 7 and "ספר לי עוד" in coach_msg:
                # This is okay if it's asking for more specific details
                # But NOT okay if it's just repeating "מה קרה? איפה?"
                if "מה קרה" in coach_msg and "איפה" in coach_msg:
                    print("\n❌ FAIL: Coach is repeating generic 'מה קרה? איפה?' questions")
                    return False
        
        # After turn 7, coach should have moved to S3
        if turn_num == 7:
            if state["current_step"] == "S3" or "מה הרגשת" in coach_msg:
                print("\n✅ PASS: Coach moved to S3 (emotions) after detailed event")
                print("   Coach has all the info: where (בחדר), what (שיחה), how (מאוכזבת)")
                return True
            elif "אמרתי" not in coach_msg.lower():
                print("\n⚠️  WARNING: Coach hasn't moved to S3 yet")
                print("   But this might be okay if asking for a NEW detail")
                print(f"   Coach asked: {coach_msg[:100]}...")
                
                # Let's continue one more turn
                user_msg2 = "אמרתי לך כבר!"
                coach_msg2, state = await handle_conversation(user_msg2, state, "he")
                print_turn(turn_num + 1, user_msg2, coach_msg2, state["current_step"])
                
                # Coach should apologize and move to S3
                if "מצטער" in coach_msg2 or "סליחה" in coach_msg2:
                    if "מה הרגשת" in coach_msg2 or state["current_step"] == "S3":
                        print("\n✅ PASS: Coach apologized and moved to S3")
                        return True
                    else:
                        print("\n⚠️  Coach apologized but didn't move to S3")
                        return False
                else:
                    print("\n❌ FAIL: User said 'אמרתי כבר' but coach didn't apologize")
                    return False
    
    return True


async def main():
    """Run the test"""
    try:
        success = await test_no_repeat_questions()
        
        print("\n" + "="*80)
        if success:
            print("✅ TEST PASSED: Coach doesn't repeat questions")
        else:
            print("❌ TEST FAILED: Coach repeats questions")
        print("="*80)
        
        sys.exit(0 if success else 1)
        
    except Exception as e:
        print(f"\n❌ Error running test: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
