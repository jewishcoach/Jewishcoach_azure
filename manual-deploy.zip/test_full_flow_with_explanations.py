"""
בדיקת שלב המצוי עם הסברים
==============================
"""

import os
import sys
import asyncio
from pathlib import Path

os.environ["AZURE_OPENAI_API_KEY"] = "ClzxbrMW7mWJpsYxbTcp6D3IppuNnDu2R2nGFyWcHIGjYhVAtmHKJQQJ99CAACYeBjFXJ3w3AAABACOGhPLX"
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://eastus.api.cognitive.microsoft.com/"
os.environ["AZURE_OPENAI_DEPLOYMENT_NAME"] = "gpt-4o"
os.environ["AZURE_OPENAI_API_VERSION"] = "2024-02-15-preview"

backend_dir = Path(__file__).parent
sys.path.insert(0, str(backend_dir))

from app.bsd_v2.single_agent_coach import handle_conversation
from app.bsd_v2.state_schema_v2 import create_initial_state

async def simulate():
    print("\n" + "=" * 80)
    print("🧪 בדיקת המצוי עם הסברים")
    print("=" * 80)
    
    state = create_initial_state("test", "user1")
    
    turns = [
        ("זוגיות", "S1"),
        ("להיות רגיש יותר", "S1→S2"),
        ("אתמול בערב ישבנו ביחד והיא ניסתה לספר לי על היום שלה ואני הייתי בטלפון", "S2→S3"),
        ("הרגשתי אשם", "S3: רגש 1"),
        ("גם תסכול", "S3: רגש 2"),
    ]
    
    for i, (user_msg, expected) in enumerate(turns, 1):
        print("\n" + "━" * 80)
        print(f"Turn {i}")
        print("━" * 80)
        print(f"👤 User: {user_msg}")
        print(f"📋 Expected: {expected}")
        
        coach_message, state = await handle_conversation(user_msg, state, "he")
        
        step = state["current_step"]
        saturation = state["saturation_score"]
        
        print(f"\n🤖 Coach ({step}, sat={saturation:.2f}):")
        print(f"   {coach_message}")
        
        # בדיקות
        if i == 2 and step == "S2":
            if "להעמיק" in coach_message or "נבחן" in coach_message:
                print("\n✅ יש הסבר על שלב המצוי!")
            else:
                print("\n⚠️  חסר הסבר")
        
        if i == 3 and step == "S3":
            if "להתעמק" in coach_message or "ברגשות" in coach_message:
                print("\n✅ יש הסבר על איסוף רגשות!")
            else:
                print("\n⚠️  חסר הסבר")
    
    print("\n" + "=" * 80)
    print(f"שלב סופי: {state['current_step']}")
    print(f"רגשות שנאספו: {state['collected_data'].get('emotions', [])}")
    print("=" * 80)

if __name__ == "__main__":
    asyncio.run(simulate())
